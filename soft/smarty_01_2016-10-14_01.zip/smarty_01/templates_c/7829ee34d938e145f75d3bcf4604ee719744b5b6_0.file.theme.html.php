<?php
/* Smarty version 3.1.29, created on 2016-10-14 19:28:10
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_01\templates\default\theme.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5800c14a9a5ec5_82535251',
  'file_dependency' => 
  array (
    '7829ee34d938e145f75d3bcf4604ee719744b5b6' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_01\\templates\\default\\theme.html',
      1 => 1476444413,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5800c14a9a5ec5_82535251 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $_smarty_tpl->tpl_vars['WEB']->value['title'];?>
</title>
</head>
<body>
	(<?php echo $_smarty_tpl->tpl_vars['WEB']->value['file_name'];?>
)佈景預設樣板
</body>
</html><?php }
}

<?php
#引入smarty物件
require_once WEB_PATH.'/class/smarty/Smarty.class.php';
#實體化
$smarty = new Smarty;
#模板路徑
$smarty->template_dir = WEB_PATH.'/templates/'.$WEB['theme_name']."/";
#編譯路徑
$smarty->compile_dir = WEB_PATH.'/templates_c/';
#設定檔路徑
$smarty->config_dir = WEB_PATH.'/configs/';
#暫存路徑
$smarty->cache_dir = WEB_PATH.'/cache/';
#定義模板URL
$smarty->assign("themeUrl", WEB_URL.'/templates/'.$WEB['theme_name']."/");

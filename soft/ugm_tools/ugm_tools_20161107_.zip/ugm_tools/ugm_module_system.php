<?php
#############################################
#  系統變數列表
#  只撈 enable=1
#############################################
if(!function_exists("ugm_module_system_list")){
function ugm_module_system_list($kind="system",$name="")
{
  global $xoopsDB,$xoopsTpl,$tbl,$kind_arr,$DIRNAME;
  #預設Foreign key=> system
  #---- 防呆
  if(!in_array($kind,array_keys($kind_arr))){
    $kind="system";
  }

  # ----得到Foreign key選單 ----------------------------
  $kind_option="";
  foreach($kind_arr as $key=>$value){
    $selected="";
    if($kind==$key){
      $selected=" selected";
    }
    $kind_option.="<option value='{$key}'{$selected}>{$value['title']}</option>";
  }
  $kind_form="
    <select name='kind' id='kind'class='form-control' onchange=\"location.href='?kind='+this.value\">
      $kind_option
    </select>
  ";
  $xoopsTpl->assign('kind_form',$kind_form);
  $xoopsTpl->assign('kind',$kind);
  #-------------------------------------------

  $sql = "select *
          from ".$xoopsDB->prefix($tbl)." as a
          where kind='{$kind}' and enable='1'
          order by a.sort";//die($sql);
  $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

  $myts = MyTextSanitizer::getInstance();
  $i=1;
  while($DBV=$xoopsDB->fetchArray($result)){
    #---- 過濾讀出的變數值 ----
    #sn name  title value description formtype  valuetype sort  enable  kind
    $DBV['name'] = $myts->htmlSpecialChars($DBV['name']);
    $DBV['kind'] = $myts->htmlSpecialChars($DBV['kind']);
    /*
    「yesno」是否的單選框
    「select」下拉選單
    「select_multi」可複選的下拉選單
    「group」群組下拉選單
    「group_multi」可複選的群組下拉選單
    「textbox」文字框
    「textarea」大量文字框
    「user」已註冊使用者下拉選單
    「user_multi」可複選的已註冊使用者下拉選單
    「timezone」時區下拉選單
    「language」語系下拉選單

     */

    if($DBV['formtype']=="textbox" or $DBV['formtype']=="textarea"){
      #---- 文字框
      $html=0;$br=1;
      $DBV['value']       = $myts->displayTarea($DBV['value'], $html, 1, 0, 1, $br);
    }elseif($DBV['formtype']=="fck"){
      #---- fck編輯器
      $html=1;$br=0;
      $DBV['value']       = $myts->displayTarea($DBV['value'], $html, 1, 0, 1, $br);
    }elseif($DBV['formtype']=="file"){
      if($DBV['valuetype']=="single_img"){
        #---- 單圖
        $multiple=false;
      }elseif($DBV['valuetype']=="multiple_img"){
        #---- 多圖
        $multiple=true;
      }
      $dir_name="/system/".$DBV['kind'];
      $col_name=$DBV['name'];
      $show_del=false;
      $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
      $ugmUpFiles->set_col($col_name,$DBV['sn']);
      $DBV['value'] = $ugmUpFiles->list_show_file_b3($show_del);
    }elseif($DBV['formtype']=="yesno"){
      $DBV['value'] = ($DBV['value'])?_YES:"<span class='text-danger'>"._NO."</span>";
    }

    $DBV['title'] = $myts->htmlSpecialChars(constant($DBV['title']));
    $DBV['description'] = $myts->htmlSpecialChars(constant($DBV['description']));
    $DBV['sort']=$i;
    $i++;
    $list[]=$DBV;
  }
  # ------------------------------------------------------------
  $xoopsTpl->assign("list",$list);
}
}


################################################
#  編輯表單
################################################
if(!function_exists("ugm_module_system_form")){
function ugm_module_system_form($sn="",$kind="system",$name=""){
  global $xoopsDB,$xoopsUser,$tbl,$xoopsTpl,$DIRNAME,$kind_arr;
  //----------------------------------*/
  //抓取預設值
  if(!empty($sn)){
    $DBV=get_ugm_module_tbl($sn,$tbl);
  }elseif(!empty($name)){
    $sql = "select *
            from ".$xoopsDB->prefix($tbl)."
            where name='{$name}' and kind='{$kind}'";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $DBV=$xoopsDB->fetchArray($result);
  }

  $pre=_EDIT;

  #防呆
  if(empty($DBV))redirect_header($_SESSION['return_url'],3, "錯誤！！");

  $DBV['form_title']=$pre.$kind_arr[$kind]['title'];

  //預設值設定 sn  name  title value description formtype  valuetype sort  enable  kind
  //設定「sn」欄位預設值
  $DBV['sn']=(!isset($DBV['sn']))?"":$DBV['sn'];
  //設定「表單名稱」欄位預設值
  $DBV['name']=(!isset($DBV['name']))?"":$DBV['name'];
  //設定「標題」欄位預設值
  $DBV['title']=(!isset($DBV['title']))?"":constant($DBV['title']);
  //設定「值」欄位預設值
  $DBV['value']=(!isset($DBV['value']))?"":$DBV['value'];
  //設定「描述」欄位預設值
  $DBV['description']=(!isset($DBV['description']))?"":constant($DBV['description']);
  //設定「表單型態」欄位預設值
  $DBV['formtype']=(!isset($DBV['formtype']))?"":$DBV['formtype'];
  //設定「值的型態」欄位預設值
  $DBV['valuetype']=(!isset($DBV['valuetype']))?"":$DBV['valuetype'];
  //設定「排序」欄位預設值
  $DBV['sort']=(!isset($DBV['sort']))?"":$DBV['sort'];
  //設定「狀態」欄位預設值
  $DBV['enable']=(!isset($DBV['enable']))?"":$DBV['enable'];
  //設定「類別」欄位預設值
  $DBV['kind']=(!isset($DBV['kind']))?"":$DBV['kind'];

  $DBV['return_url']=$_SESSION['return_url'];

  $DBV['op']="op_insert";

  if($DBV['formtype']=="file"){

    if($DBV['valuetype']=="single_img"){
      #上傳單張圖片
      #建構元(模組名稱,"/資料夾","/檔案","/圖片","/縮圖",$multiple)
      $multiple=false;
      $dir_name="/system/".$DBV['kind']  ;# --- 表單欄位名稱
      $col_name=$DBV['name'];
      $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
      $ugmUpFiles->set_col($col_name,$DBV['sn']);
      #上傳html語法(表單名稱，上傳類型，顯示舊圖，驗證)
      $DBV['form']=$ugmUpFiles->upform_one($col_name,"image/*","show");
    }elseif($DBV['valuetype']=="multiple_img"){
      #上傳多張圖片
      $multiple=true;
      $dir_name="/system/".$DBV['kind']   ;# --- 表單欄位名稱
      $col_name=$DBV['name'];
      $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
      $ugmUpFiles->set_col($col_name,$DBV['sn']);
      #上傳html語法(表單名稱，上傳類型，顯示舊圖，驗證)
      $DBV['form']=$ugmUpFiles->upform($col_name,"image/*","show");
    }
  }elseif($DBV['formtype']=="textbox"){
    $DBV['form']="<input type='text' class='form-control' name='value' id='value' value='{$DBV['value']}'>";
  }elseif($DBV['formtype']=="textarea"){
    $DBV['form']="<textarea class='form-control' rows='5' id='value' name='value'>{$DBV['value']}</textarea>";
  }elseif($DBV['formtype']=="fck"){
    //內容#資料放「content」
    # ======= ckedit====
    if(!file_exists(XOOPS_ROOT_PATH."/modules/tadtools/ck.php")){
      redirect_header("http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50" , 3 , _TAD_NEED_TADTOOLS);
    }
    include_once XOOPS_ROOT_PATH."/modules/tadtools/ck.php";

    #---- 檢查資料夾
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}");
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}/fck");
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}/fck/image");
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}/fck/flash");

    $dir_name=$DIRNAME."/system/{$DBV['kind']}/fck";
    $ck=new CKEditor($dir_name,"value",$DBV['value'],$DIRNAME);
    $ck->setHeight(300);
    //pinrt_r($ck);die();
    $DBV['form']=$ck->render();

  }elseif($DBV['formtype']=="yesno"){
    $value_1=$DBV['value']?" checked":"";
    $value_0=$DBV['value']?"":" checked";
    $DBV['form']="<input type='radio' name='value' id='value_1' value='1' {$value_1}>\n
    <label for='value_1'>"._YES."</label>&nbsp;&nbsp;\n
    <input type='radio' name='value' id='value_0' value='0' {$value_0}>\n
    <label for='value_0'>"._NO."</label>";
  }

  $xoopsTpl->assign('DBV',$DBV);
}
}
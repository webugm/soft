<?php
/* 引入檔頭，每支程都會引入 */
require_once 'head.php';

/* 過濾變數，設定預設值 */
$op = system_CleanVars($_REQUEST, 'op', 'opList', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');

/* 程式流程 */
switch ($op){
	case "xxx" :
		//$msg = XXX();
		redirect_header(WEB_URL, 3000, $msg);
		exit;
	
	default:
		$op = "opList";
		opList();
		break;	
}

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);

/*---- 程式結尾-----*/
$smarty->display('message.tpl');

/*---- 函數區-----*/


###############################
# 預設
###############################
function opList(){
	global $smarty;
}

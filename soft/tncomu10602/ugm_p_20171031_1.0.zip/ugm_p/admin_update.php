<?php
/* 引入檔頭，每支程都會引入 */
require_once 'head.php';

#權限檢查
if($_SESSION['group'] != "admin")redirect_header("index.php", 3000, "您沒有管理員權限！");

/* 過濾變數，設定預設值 */
$op = system_CleanVars($_REQUEST, 'op', 'opList', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');

/* 程式流程 */
switch ($op){

	#預設動作
	default:
		$op = "opList";
		opList();
		redirect_header("admin.php", 3000, "更新完成！");
		exit;	
}

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);

/*---- 程式結尾-----*/
$smarty->display('theme_admin.tpl');

/*---- 函數區-----*/
###############################
# 會員列表
###############################
function opList(){
	global $db;

  #檢查資料夾
  mk_dir(WEB_PATH . "/uploads");
  mk_dir(WEB_PATH . "/uploads/debug");

  //-------- 資料表 ------
  #檢查資料表(creative_nav)
  if (!chk_isTable("users")) {
    $sql = "
      CREATE TABLE `users` (
			  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '使用者編號',
			  `name` varchar(255) NOT NULL COMMENT '使用者姓名',
			  `email` varchar(255) NOT NULL COMMENT '使用者Email',
			  `pass` varchar(255) NOT NULL COMMENT '使用者密碼',
			  `group` enum('user','admin') NOT NULL COMMENT '使用者群組',
			  PRIMARY KEY (`uid`),
			  UNIQUE KEY `email` (`email`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8;
    ";
    createTable($sql);
  }

	
}

 
########################################
# 建立資料表
########################################
function createTable($sql) {
  global $db;
  $db->query($sql) or die(printf("Error: %s <br>" . $sql, $db->sqlstate));
  return true;
}
 
########################################
# 增加欄位
######################################## 
function addColumn($sql) {
  global $db;
  $db->query($sql) or die(printf("Error: %s <br>" . $sql, $db->sqlstate));
  return true;
}
 
########################################
# 檢查某欄位是否存在(欄名,資料表)
########################################
function chk_isColumn($col_name , $tbl_name) {
  global $db;
  if (!$col_name or !$tbl_name) {
    return;
  } 
  //SHOW COLUMNS FROM `show_kind` LIKE 'sn1'
  $sql = "SHOW COLUMNS FROM `{$tbl_name}` LIKE '{$col_name}'";
  $result = $db->query($sql) or die(printf("Error: %s <br>" . $sql, $db->sqlstate));
  if ($result->num_rows) {
    return true;//欄位存在
  }  
  return false; //欄位不存在
} 
########################################
# 檢查資料表是否存在(資料表)
########################################
function chk_isTable($tbl_name) {
  global $db;
  if (!$tbl_name) {
    return;
  } 
  $sql = "SHOW TABLES LIKE '{$tbl_name}'"; //die($sql); 
  $result = $db->query($sql) or die(printf("Error: %s <br>" . $sql, $db->sqlstate)); 
  if ($result->num_rows) {
    return true;//欄位存在
  }  
  return false; //欄位不存在
}

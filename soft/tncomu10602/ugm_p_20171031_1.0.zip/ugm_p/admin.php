<?php
/* 引入檔頭，每支程都會引入 */
require_once 'head.php';

#權限檢查
if($_SESSION['group'] != "admin")redirect_header("index.php", 3000, "您沒有管理員權限！");

/* 過濾變數，設定預設值 */
$op = system_CleanVars($_REQUEST, 'op', 'opList', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');

/* 程式流程 */
switch ($op){
	case "opDeleteTmp" :
		$msg = opDeleteTmp();
		redirect_header($_SESSION['returnUrl'], 3000, $msg);
		exit;


	default:
		$op = "opList";
		$_SESSION['returnUrl'] = getCurrentUrl();
		opList();
		break;	
}

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);

/*---- 程式結尾-----*/
$smarty->display('theme_admin.tpl');

/*---- 函數區-----*/

###############################
# 清理暫存
###############################
function opDeleteTmp(){
	global $smarty;
	$files = glob($smarty->compile_dir.'*'); // 得到所有編譯檔
	foreach($files as $file){ // iterate files
	  if(is_file($file))
	    unlink($file); // 刪除檔案
	}
	return "清理暫存成功！";
}


###############################
# 預設
###############################
function opList(){
	global $smarty;
	//$token = getTokenHTML();
	//$smarty->assign("token", $token);
}

/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'gl', {
	button: 'Inserir fragmento de código',
	codeContents: 'Contido do código',
	emptySnippetError: 'Un fragmento de código non pode estar baleiro.',
	language: 'Linguaxe',
	title: 'Fragmento de código',
	pathName: 'fragmento de código'
} );

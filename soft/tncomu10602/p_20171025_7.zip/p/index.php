<?php
/* 引入檔頭，每支程都會引入 */
require_once 'head.php';

/* 過濾變數，設定預設值 */
$op = system_CleanVars($_REQUEST, 'op', '', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');

/* 程式流程 */
switch ($op){
	case "logout" :
	  $msg = logout();
	  redirect_header("index.php", 3000, $msg);
	  exit;

	case "login" :
	  $msg = login();
	  redirect_header("index.php", 3000, $msg);
	  exit;
	case "signup" :
		$msg = signup();
		redirect_header("index.php", 3000, $msg);
		exit;


	default:
		$op = "op_list";
		op_list();
		break;	
}

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);

/*---- 程式結尾-----*/
$smarty->display('theme.tpl');

/*---- 函數區-----*/
function signup(){
	global $db;
	
  //Array ( [name] => 1 [email] => tawan158@gmail.com [pass] => 111111 [confirmPass] => 111111 [op] => signup )
  #過濾
  $_POST['name'] = db_CleanVars($_POST['name'], "姓名");
  $_POST['email'] = db_CleanVars($_POST['email'], "email", FILTER_VALIDATE_EMAIL);
  $_POST['pass'] = db_CleanVars($_POST['pass'], "密碼");
  $_POST['confirmPass'] = db_CleanVars($_POST['confirmPass'], "確認密碼");

  if($_POST['pass'] != $_POST['confirmPass'] ){
    redirect_header(WEB_URL, 3000,  '密碼不對！');
  }

  checkEmail($_POST['email']) or redirect_header("index.php", 3000, 'email重覆！');

  #密碼加密
  $_POST['pass']  = password_hash($_POST['pass'], PASSWORD_DEFAULT);
 
  #寫進資料庫
  $sql = "insert into `users`
        (`email`,`pass`,`name`) values
        ('{$_POST['email']}','{$_POST['pass']}','{$_POST['name']}')"; //die($sql);
  
  if(!$db->query($sql)){
    redirect_header(WEB_URL, 3000, "(".$db->errno.")".$db->error);
  }
  return "註冊成功！！";

}


function op_list(){
	global $smarty;
}

###############################
# 檢查users=> email 是否重覆
# Email存在 傳回 false
###############################
function checkEmail($email){
  global $db;
 
  $valid = true;
 
  $sql= "select `uid`
         from `users`
         where `email`='{$email}'
  ";
  $result = $db->query($sql);
  if($result){
    list($uid) = $result->fetch_row();
    if($uid){
      $valid = false;
    }
  }
  return $valid;
}
#################################################
#  登入
#################################################
function login(){
  global $db;
  #過濾
  $_POST['email'] = db_CleanVars($_POST['email'], "email", FILTER_VALIDATE_EMAIL);
  $_POST['pass'] = db_CleanVars($_POST['pass'], "密碼");
 
  #撈出使用者
   
  $sql    = "SELECT * FROM `users` where `email`='{$_POST['email']}'";
  $result = $db->query($sql) or redirect_header(WEB_URL, 3000, "(".$db->errno.")".$db->error);
   
  $row = $result->fetch_assoc();
  //Array ( [uid] => 1 [name] => 郭俊良 [email] => tawan158@gmail.com [pass] => $2y$10$6/kdXS9AXiEfunEzZ8V0vukGJqcR0nrUOk4KHtolW.kkUpsbH0tr2 [group] => admin )
 
 
  if (password_verify($_POST['pass'], $row['pass'])) {
      $_SESSION['group'] = $row['group'];
      $_SESSION['name']  = htmlspecialchars($row['name'], ENT_QUOTES);
      $_SESSION['uid']   = intval($row['uid']);
      $_SESSION['email'] = htmlspecialchars($row['email'], ENT_QUOTES);
  } else {
    redirect_header(WEB_URL, 3000, "登入失敗！");
  }
  return "登入成功！";
}


#################################################
#  登入
#################################################
function logout(){
	unset($_SESSION['group']);
	unset($_SESSION['name']);
	unset($_SESSION['uid']);
	unset($_SESSION['email']);
	return "您已登出！"; 
}

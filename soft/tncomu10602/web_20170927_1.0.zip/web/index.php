<?php
/*---- 引入(設定)->檢查----*/
require_once 'head.php';

/* 過濾變數，設定預設值 */
$op = isset($_REQUEST['op'])?htmlspecialchars($_REQUEST['op'], ENT_QUOTES):"";//過濾特殊符號

/* 程式流程 */
switch ($op){
	case "login" :
		$msg = login();
		redirect_header("index.php", 3000, $msg);
		exit;

	case "logout" :
		logout();
	  exit;

	default:
		$op = "op_list";
		op_list();
		break;	
}

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);

/*---- 程式結尾-----*/
$smarty->display('theme.tpl');

/*---- 函數區-----*/
function login(){
	global $smarty;

}
function logout(){
}

function op_list(){
}
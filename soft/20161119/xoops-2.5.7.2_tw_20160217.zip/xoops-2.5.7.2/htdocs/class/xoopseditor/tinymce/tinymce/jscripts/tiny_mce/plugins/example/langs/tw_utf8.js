tinyMCE.addI18n('tw_utf8.example',{
	desc : '這只是個樣板按鈕'
});

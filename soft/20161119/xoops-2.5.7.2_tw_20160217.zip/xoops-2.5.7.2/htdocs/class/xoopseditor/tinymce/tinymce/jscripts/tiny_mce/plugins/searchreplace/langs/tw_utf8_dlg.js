tinyMCE.addI18n('tw_utf8.searchreplace_dlg',{
searchnext_desc:"再次查找",
notfound:"查找已完成 ! 找不到任何目標。 ",
search_title:"查找",
replace_title:"查找/替換",
allreplaced:"已替換所有匹配的字串.",
findwhat:"查找目標",
replacewith:"替換為",
direction:"方向",
up:"向上",
down:"向下",
mcase:"區分大小寫",
findnext:"查找下一個",
replace:"替換",
replaceall:"全部替換"
});

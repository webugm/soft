﻿tinyMCE.addI18n('tw_utf8.advhr_dlg',{
width:"寬度",
size:"高度",
noshade:"無陰影"
});

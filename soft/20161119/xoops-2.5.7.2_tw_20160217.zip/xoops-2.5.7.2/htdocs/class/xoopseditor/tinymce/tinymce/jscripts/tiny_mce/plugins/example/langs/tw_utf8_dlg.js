tinyMCE.addI18n('tw_utf8.example_dlg',{
	title : '這只是個範例標題'
});

XOOPS 2.5.7 Final

The XOOPS Development Team is pleased to announce the release of XOOPS 2.5.7 Final. This version has been made compatible with PHP 5.5.x, in addition to security enhancement.

Download XOOPS 2.5.7 from [url=https://sourceforge.net/projects/xoops/files/XOOPS%20Core%20%28stable%20releases%29/XOOPS%202.5.7/]Sourceforge repository[/url].


How to contribute
-----------------------------------
Bug report: http://sourceforge.net/tracker/?group_id=41586&atid=430840
Patch and enhancement: http://sourceforge.net/tracker/?group_id=41586&atid=430842
Feature design: http://sourceforge.net/tracker/?group_id=41586&atid=430843
Release announcement: https://lists.sourceforge.net/lists/listinfo/xoops-announcement

XOOPS Development Team
June 14, 2014
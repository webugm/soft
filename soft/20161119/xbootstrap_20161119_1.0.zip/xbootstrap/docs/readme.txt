xBootstrap is a theme for XOOPS (www.xoops.org) developed with Bootstrap (http://getbootstrap.com)

Developed by.: Angelo Rocha

URL: www.angelorocha.com.br
XOOPS Fire (Brazillian Support): www.xoopsfire.com
Google Plus:        https://plus.google.com/+AngeloRocha
Twitter:            https://twitter.com/_AngeloRocha
Linkedin:           http://br.linkedin.com/in/angelorocha
Github:             https://github.com/angelorocha

--------------------------------------------------------------------------
This is a template for XOOPS developed with Bootstrap 3.
You can use for personal or commercial purposes.

Viva XOOPS!
www.xoops.org 
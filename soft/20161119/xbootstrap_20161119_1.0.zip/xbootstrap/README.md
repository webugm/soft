xBootstrap
==========

xBootstrap is a theme for XOOPS (www.xoops.org) developed with Bootstrap.

Online demo: http://themes.angelorocha.com.br

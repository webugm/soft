CREATE TABLE ugm_tools_nav (
  `sn` smallint(5) unsigned NOT NULL auto_increment comment 'sn',
  `ofsn` smallint(5) unsigned NOT NULL comment '父類別',
  `title` varchar(255) NOT NULL comment '標題',
  `sort` smallint(5) unsigned NOT NULL comment '排序',
  `enable` enum('1','0') NOT NULL default '1' comment '狀態',
  `kind` varchar(255) NOT NULL default 'kind' comment '類別',
  `url` varchar(255) NOT NULL comment '網址',
  `target` enum('1','0') NOT NULL default '0' comment '外連',
  PRIMARY KEY  (`sn`)
) ENGINE=MyISAM;
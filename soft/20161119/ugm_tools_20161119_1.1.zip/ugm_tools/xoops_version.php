<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2015-04-12
// $Id:$
// ------------------------------------------------------------------------- //

$modversion = array();

//---模組基本資訊---//
$modversion['name'] = _MI_UGMTOOLS_NAME;
$modversion['version']  = '1.2';
$modversion['description'] = _MI_UGMTOOLS_DESC;
$modversion['author'] = _MI_UGMTOOLS_AUTHOR;
$modversion['credits']  = _MI_UGMTOOLS_CREDITS;
$modversion['help'] = 'page=help';
$modversion['license']    = 'GPL see LICENSE';
$modversion['image']    = "images/logo.png";
$modversion['dirname'] = basename(dirname(__FILE__));


//---模組狀態資訊---//
$modversion['status_version'] = '1.2';
$modversion['release_date'] = '2016-07-04';
$modversion['module_website_url'] = '';
$modversion['module_website_name'] = _MI_UGMTOOLS_AUTHOR_WEB;
$modversion['module_status'] = 'release';
$modversion['author_website_url'] = '';
$modversion['author_website_name'] = _MI_UGMTOOLS_AUTHOR_WEB;
$modversion['min_php']= 5.2;
$modversion['min_xoops']='2.5';


//---paypal資訊---//
$modversion ['paypal'] = array();
$modversion ['paypal']['business'] = 'tawan158@gmail.com';
$modversion ['paypal']['item_name'] = 'Donation :'. _MI_UGMTOOLS_AUTHOR;
$modversion ['paypal']['amount'] = 0;
$modversion ['paypal']['currency_code'] = 'USD';

//---安裝設定---//
$modversion['onInstall'] = "include/onInstall.php";
$modversion['onUpdate'] = "include/onUpdate.php";
$modversion['onUninstall'] = "include/onUninstall.php";

//---啟動後台管理界面選單---//
$modversion['system_menu'] = 1;

//---資料表架構---//
$modversion['sqlfile']['mysql'] = "sql/mysql.sql";
$modversion['tables'][1] = "ugm_tools_nav";

//---管理介面設定---//
$modversion['hasAdmin'] = 1;
$modversion['adminindex'] = "admin/main.php";
$modversion['adminmenu'] = "admin/menu.php";

//---使用者主選單設定---//
$modversion['hasMain'] = 0;


//---樣板設定---//
$i=0;
$modversion['templates'][$i]['file'] = 'ugm_tools_adm_main.html';
$modversion['templates'][$i]['description'] = 'ugm_tools_adm_main.html';
$i++;
$modversion['templates'][$i]['file'] = 'ugm_tools_adm_nav.html';
$modversion['templates'][$i]['description'] = 'ugm_tools_adm_nav.html';

$i++;
$modversion['templates'][$i]['file'] = 'ugm_tools_tpl_theme_navbarb.html';
$modversion['templates'][$i]['description'] = 'ugm_tools_tpl_theme_navbarb.html';

$i++;
$modversion['templates'][$i]['file'] = 'ugm_tools_tpl_theme_navbarb1.html';
$modversion['templates'][$i]['description'] = 'ugm_tools_tpl_theme_navbarb1.html';

//---區塊設定---//
$i=0;

?>
<?php
/*
version 1.1
date 2015-03-10
use
 */
#---------------------------------
defined('XOOPS_ROOT_PATH') || die("XOOPS root path not defined");
class ugmKind_theme
{
  protected $tbl;//資料表
  protected $kind;//類別
  protected $stop_level;//層數

  function __construct($tbl="",$kind="",$stop_level=1){
    global $xoopsDB;
    $this->set_tbl($tbl);
    $this->set_kind($kind);
    $this->set_stop_level($stop_level);
  }
  #--------- 設定類 --------------------
  #設定資料表
  public function set_tbl($value=""){
    $this->tbl = $value;
  }
  #設定類別
  public function set_kind($value=""){
    $this->kind = $value;
  }
  #設定層數
  public function set_stop_level($value=1){
    $this->stop_level = $value;
  }
  #-------------------------------------


  #--------- 取得類 --------------------

  #取得分類的類別
  public function get_kind(){
    return $this->kind;
  }
  public function get_tbl(){
    return $this->tbl;  }

  public function get_stop_level(){
    return $this->stop_level;
  }

  #----後台----
  #以流水號取得某筆分類資料
  public function get_one_table_4_sn($sn=""){
    global $xoopsDB;
    if(empty($sn))return;
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)." where sn='{$sn}'";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $data=$xoopsDB->fetchArray($result);
    return $data;
  }
  #######################################################
  #  取得父類別選單->選項(後台類別表單用)# op_form
  #######################################################
  public function get_admin_form_ofsn_option($ofsn_check,$ofsn=0,$level=1,$indent=""){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level >= $this->stop_level)return;
    $down_level=$level+1;
    $indent.="&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($ofsn_check==$sn)?" selected":"";
       $main.="<option value='{$sn}'{$selected}>{$indent}{$title}</option>";
       $main.=$this->get_admin_form_ofsn_option($ofsn_check,$sn,$down_level,$indent);
    }
    return $main;
  }

  ################################################################
  #  取得類別body的資料
  ################################################################
  public function get_admin_list_body($ofsn=0,$level=1){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return;
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $sub="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $icon['folder_i']        =$this->stop_level>$level?true:false;
      $icon['move_i']          =$level != 1       ?true:false;
      $icon['add_down_level_i']=$this->stop_level>$level?true:false;
      $icon['sort_i']=true;

      $sub=$this->get_admin_list_body($sn,$down_level);
      #資料欄位有增減
      $list[]=array('sn' => $sn, 'ofsn' => $ofsn, 'title' => $title, 'enable' => $enable,'icon' => $icon,"target"=>$target,"url"=>$url,'sub'=>$sub);
    }
    return $list;
  }

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_array($in_sn="",$ofsn=0,$stop_level=0 ,$level=1){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level++;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";


    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind} and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    $main="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $active=($in_sn==$sn)?1:0;
      $sub="";
      $sub=$this->get_use_kind_array($in_sn,$sn,$stop_level,$down_level);
      $main[]=array("sn"=>$sn,"title"=>$title,"active"=>$active,"sub"=>$sub);
    }
    return $main;
  }
  #
  #取得使用者類別第1個選項
  public function get_use_first_kind(){
    global $xoopsDB;
    #層數預設值
    $sql = "select sn from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='0' and kind='{$this->kind}' and enable='1'
            limit 1
            ";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($sn)=$xoopsDB->fetchRow($result);
    return $sn;
  }
  #-------------------------------------

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_option1($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $disabled=($level != $stop_level)?" disabled":"";
       $selected=($in_sn==$sn)?" selected":"";
       $main.="<option value='{$sn}'{$selected}{$disabled}>{$indent}{$title}</option>";
       $main.=$this->get_use_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
    }
    return $main;
  }
  #-------------------------------------

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind} and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_use_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }
  #-------------------------------------

  #取得使用者類別導航路徑
  public function get_user_kind_dir($in_sn){
    global $xoopsDB;
    #層數預設值
    $sql = "select *
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$in_sn}'";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $list="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       $parent="";
       if($all['ofsn']){
         $parent=$this->get_user_kind_dir($all['ofsn']);
       }
       $list[]=array("sn"=>$all['sn'],"ofsn"=>$all['ofsn'],"title"=>$all['title'],"parent"=>$parent);
    }
    return $list;
  }
  #-------------------------------------

  #取得使用者類別複選選項
  public function get_use_kind_checkbox_option($in_sn,$ofsn=0,$form_name="kind",$stop_level=0 ,$level=1){
    global $xoopsDB;
    #將傳入值轉成陣列
    if($in_sn){
      $in_sn_arr=explode(",",$in_sn);
    }
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    $i=0;
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $style=!($i % 4)?"style='margin-left: 0;'":"";
       $checked=(in_array($sn,$in_sn_arr))?" checked":"";
       $main.="
              <div class='span3' {$style}>
                <input name='{$form_name}[]' type='checkbox' value='{$sn}' {$checked} id='{$form_name}_{$sn}'>
                <label class='checkbox-inline' for='{$form_name}_{$sn}'>{$title}</label>&nbsp;
              </div>
        ";
       $main.=$this->get_use_kind_checkbox_option($in_sn,$sn,$form_name,$stop_level ,$down_level);
       $i++;
    }
    return $main;
  }
  #-------------------------------------

  #以流水號取得標題
  public function get_kind_title_from_sn($sn){
    global $xoopsDB;
    $title="";
    $sql="select title
          from ".$xoopsDB->prefix($this->tbl)."
          where sn='{$sn}'
          ";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($title)=$xoopsDB->fetchRow($result);
    return $title;
  }
  #-------------------------------------


  #取得類別複選選項(sn)陣列 轉 (title)陣列
  public function get_use_kind_sn2title($in_sn){
    global $xoopsDB;
    $title="";
    #將傳入值轉成陣列
    if($in_sn){
      $in_sn_arr=explode(",",$in_sn);
    }
    foreach($in_sn_arr as $k=>$sn){
      if($k){
        $title.=" , ".$this->get_kind_title_from_sn($sn);
      }else{
        $title.=$this->get_kind_title_from_sn($sn);
      }
    }
    return $title;
  }



  #檢查類-----------------------------------
  #確認底下有幾層
  #chk_kind_level_down
  public function chk_kind_level_down($sn_in,$level=1,$get_level=1){
    global $xoopsDB;

    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return $level;
    $level++;
    $sql = "select sn
            from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$sn_in}'";// return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $get_level_tmp=$this->chk_kind_level_down($sn,$level,$level);
       $get_level=($get_level_tmp > $get_level)?$get_level_tmp:$get_level;
    }
    return $get_level;
  }
  ###########################################################
  #  確認所在層數
  ###########################################################
  public function chk_kind_level($sn,$level=1){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level>$this->stop_level)return $level;
    $sql = "select ofsn
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$sn}'";// return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($ofsn)=$xoopsDB->fetchRow($result);
    if(!$ofsn)return $level;
    return $this->chk_kind_level($ofsn,++$level);
  }
  ################################################################################
  #   檢查是否有子類別
  #   1. 有 ->  true
  #   2. 無 ->  false
  ################################################################################
  function check_sub_kind($sn=""){
    global $xoopsDB;
    if(empty($sn)) return false;
    $sql = "select count(*) from ".$xoopsDB->prefix($this->tbl)."
            where `ofsn`='{$sn}'";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($count)=$xoopsDB->fetchRow($result);
    if($count)return true;
    return false;
  }

}
?>
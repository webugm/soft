<?php
//include_once "../../tadtools/ck.php";
class ugm_CKEditor extends CKEditor{
  var $DirName;
  //建構函數
  function ugm_CKEditor($xoopsDirName="",$ColName="",$Value="",$DirName=""){
    $this->DirName=$DirName;
    parent::CKEditor($xoopsDirName,$ColName,$Value);
  }

  //產生編輯器
  function render(){
    $_SESSION['xoops_mod_name']=$this->xoopsDirName;

    // before being fed to the textarea of CKEditor
    $content = str_replace('&', '&amp;', $this->Value);
    $content=str_replace('[','&#91;',$content);

    $editor="
    <link rel='stylesheet' type='text/css' href='".TADTOOLS_URL."/ckeditor/mathquill.css' />
    <script src='".TADTOOLS_URL."/ckeditor/mathquill.js'></script>
    <script type='text/javascript' src='".TADTOOLS_URL."/ckeditor/ckeditor.js'></script>

    <textarea name='{$this->ColName}' style='width:{$this->Width};height:{$this->Height};' id='editor_{$this->ColName}' class='ckeditor_css'>{$content}</textarea>
    <script type='text/javascript'>
    CKEDITOR.replace('editor_{$this->ColName}' , {
      skin : 'moono' ,
      language : '"._LANGCODE."' ,
      toolbar : '{$this->ToolbarSet}' ,
      extraPlugins: 'autogrow,syntaxhighlight,summary,oembed,mathedit',
      filebrowserBrowseUrl : '".TADTOOLS_URL."/elFinder/elfinder.php?type=file',
      filebrowserImageBrowseUrl : '".TADTOOLS_URL."/elFinder/elfinder.php?type=image',
      filebrowserFlashBrowseUrl : '".TADTOOLS_URL."/elFinder/elfinder.php?type=flash',
      filebrowserUploadUrl : '".TADTOOLS_URL."/upload.php?type=file',
      filebrowserImageUploadUrl : '".TADTOOLS_URL."/upload.php?type=image',
      filebrowserFlashUploadUrl : '".TADTOOLS_URL."/upload.php?type=flash'
    } );
    CKEDITOR.add
    CKEDITOR.config.contentsCss = ['".TADTOOLS_URL."/bootstrap3/css/bootstrap.css', '".XOOPS_URL."/modules/{$this->DirName}/css/module_b3.css'];
    </script>";
    /*
    CKEDITOR.add
    CKEDITOR.config.contentsCss = '".TADTOOLS_URL."/bootstrap3/css/bootstrap.css' ;*/
    return $editor;
  }
}
?>

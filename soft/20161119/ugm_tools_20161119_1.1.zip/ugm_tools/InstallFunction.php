<?php

#---- 檢查ugm modules 的 system (name and kind)是否有變數
if(!function_exists("check_ugm_module_system_nameKind")){
function check_ugm_module_system_nameKind($name,$kind,$tbl)
{
  global $xoopsDB;
  $sql="select sn
        from ".$xoopsDB->prefix($tbl)."
        where name='{$name}' and kind='{$kind}'";//die($sql);
  $result=$xoopsDB->query($sql);
  list($sn)=$xoopsDB->fetchRow($result);
  if(empty($sn)) return false;
  return true;
}
}
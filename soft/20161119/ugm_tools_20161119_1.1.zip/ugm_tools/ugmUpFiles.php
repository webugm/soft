<?php
/*
version 1.1
date 2015-03-03
use
*/
#---------------------------------
defined('XOOPS_ROOT_PATH') || die("XOOPS root path not defined");
/*
<input type="file" name="cover" maxlength="1" accept="image/*" class="span12">
 */
class ugmUpFiles{
  var $ugmUpFilesTblName;//資料表名稱
  var $ugmUpFilesDir;//檔案dir
  var $ugmUpFilesUrl;//檔案url
  var $ugmUpFilesImgDir;//圖片dir
  var $ugmUpFilesImgUrl;//圖片url
  var $ugmUpFilesThumbDir;//縮圖dir
  var $ugmUpFilesThumbUrl;//縮圖url
  var $col_name;//資料表欄位
  var $col_sn;//資料表欄位
  var $sort;//資料表欄位
  var $subdir;//資料表欄位
  var $prefix;//資料表的前置字元 x_「ugm_adopt」_files_center，模組名稱
  var $file_dir="/file";
  var $image_dir="/image";
  var $thumbs_dir="/image/.thumbs";

  var $thumb_width='120px';#縮圖寬度
  var $thumb_height='70px';#縮圖高度
  var $thumb_bg_color='#000000';
  var $thumb_position='center center';
  var $thumb_repeat='no-repeat';
  var $thumb_size='contain';
  var $multiple=true;//多檔
  #建構元(模組名稱,"/資料夾","/檔案","/圖片","/縮圖",$multiple)
  function __construct($prefix="",$subdir="",$file="/file",$image="/image",$thumbs="/image/.thumbs",$multiple=true){
    global $xoopsDB;
    if(!empty($prefix))$this->set_prefix($prefix);
    if(!empty($subdir))$this->set_dir('subdir',$subdir);
    $this->set_dir('file',$file);
    $this->set_dir('image',$image);
    $this->set_dir('thumbs',$thumbs);
    $this->ugmUpFilesTblName=$xoopsDB->prefix("{$this->prefix}_files_center");
    $this->multiple=$multiple;
  }

  //上傳圖檔，$this->col_name=對應欄位名稱,$col_sn=對應欄位編號,$種類：img,file,$sort=圖片排序,$files_sn="更新編號"
  public function upload_file($upname='upfile',$main_width="1280",$thumb_width="120",$files_sn="",$desc=NULL,$safe_name=false,$hash=false){
    global $xoopsDB,$xoopsUser;

    //if(empty($main_width))$main_width="1280";
    if(empty($thumb_width))$thumb_width="120";

    //die(var_dump($_FILES[$upname]));
    //引入上傳物件
    include_once XOOPS_ROOT_PATH."/modules/tadtools/upload/class.upload.php";

    //取消上傳時間限制
    set_time_limit(0);
    //設置上傳大小
    ini_set('memory_limit', '80M');

    /*
    //儲存檔案描述
    if(!empty($_POST['save_description'])){
      foreach($_POST['save_description'] as $save_files_sn=>$files_desc){
        $this->update_col_val($save_files_sn,'description',$files_desc);
      }
    }
    */
    #---------------------------------------
    //die(var_export($_POST['del_file']));
    //刪除勾選檔案
    if(!empty($_POST["del_{$this->col_name}"])){
      foreach($_POST["del_{$this->col_name}"] as $del_files_sn){
        $this->del_files($del_files_sn);
      }
    }
    #---------------------------------------
    //$i檔案索引 0、1、2、、
    //$k=>name、type、tmp_name、error、size
    //$v=>xxx.jpg、image/jpeg、C:\Dropbox\server\UniServerZ_1\tmp\phpF0D6.tmp、0、620888

    $files = array();
    foreach ($_FILES[$upname] as $k => $l) {
      foreach ($l as $i => $v) {
        if (!array_key_exists($i, $files)){
          $files[$i] = array();
        }
        $files[$i][$k] = $v;//$file[0][name]=xxx.jpg
      }
    }

    //print_r($files);die();
    //處理檔案上傳，檢查是否有上傳
    if($_FILES[$upname]['name'][0]){
      #有上傳
      foreach ($files as $file) {
        //先刪除舊檔
        if(!empty($files_sn)){
          $this->del_files($files_sn);
        }
        //自動排序
        if(empty($this->sort)){
          $this->sort=$this->auto_sort();
        }
        //取得檔案
        $file_handle = new upload($file,"zh_TW");

        if ($file_handle->uploaded) {
          #單檔上傳，先刪舊檔--------------------
          if(!$this->multiple){
            $sql = "select files_sn
                    from `{$this->ugmUpFilesTblName}`
                    where `col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}'";//die($sql);
            $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
            while($all=$xoopsDB->fetchArray($result)){
              //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
              foreach($all as $k=>$v){
                $$k=$v;
              }
              $this->del_files($files_sn);
            }
          }
          #---------------------------------------
          //取得副檔名
          $ext=strtolower($file_handle->file_src_name_ext);
          //判斷檔案種類
          if($ext=="jpg" or $ext=="jpeg" or $ext=="png" or $ext=="gif"){
            $kind="img";
          }else{
            $kind="file";
          }

          $file_handle->file_safe_name = false;
          $file_handle->file_overwrite = true;
          $file_handle->no_script = false;

          $hash_name=md5(rand(0,1000).$name);

          if($hash){
            $new_filename   = $hash_name;
          }else{
            $new_filename   = ($safe_name)?"{$this->col_name}_{$this->col_sn}_{$this->sort}":$file_handle->file_src_name_body;
          }

          //die($new_filename);
          $os_charset=(PATH_SEPARATOR==':')?"UTF-8":"Big5";//linux:windows

          if($os_charset != _CHARSET){
            $new_filename=iconv(_CHARSET, $os_charset, $new_filename);
          }
          $file_handle->file_new_name_body   = $new_filename;


          //若是圖片才縮圖___1
          if($kind=="img" and !empty($main_width)){
            if($file_handle->image_src_x > $main_width){
              $file_handle->image_resize         = true;
              $file_handle->image_x              = $main_width;
              $file_handle->image_ratio_y         = true;
            }
          }
          $path=($kind=="img")?$this->ugmUpFilesImgDir:$this->ugmUpFilesDir;
          $readme=($hash)?"{$path}/{$hash_name}_info.txt":"";
          $file_handle->process($path);
          $file_handle->auto_create_dir = true;
          #------------------------------------------------------
          //若是圖片才製作小縮圖____2
          if($kind=="img"){
            $file_handle->file_safe_name = false;
            $file_handle->file_overwrite = true;

            $file_handle->file_new_name_body   = $new_filename;

            if($file_handle->image_src_x > $thumb_width){
              $file_handle->image_resize         = true;
              $file_handle->image_x              = $thumb_width;
              $file_handle->image_ratio_y         = true;
            }
            $file_handle->process($this->ugmUpFilesThumbDir);
            $file_handle->auto_create_dir = true;
          }
          #------------------------------------------------------


          #------------------------------------------------------
          //上傳檔案
          if($file_handle->processed) {
            $file_handle->clean();
            if($hash){
              $fp = fopen($readme, 'w');
              fwrite($fp, $file['name']);
              fclose($fp);
            }

            $file_name = ($safe_name)?"{$this->col_name}_{$this->col_sn}_{$this->sort}.{$ext}":$file['name'];

            $description=is_null($desc)?$file['name']:$desc;


            $hash_name=($hash)?"{$hash_name}.{$ext}":"";

            if(empty($files_sn)){
              $sql = "insert into `{$this->ugmUpFilesTblName}`  (`col_name`,`col_sn`,`sort`,`kind`,`file_name`,`file_type`,`file_size`,`description`,`counter`,`original_filename`,`sub_dir`,`hash_filename`) values('{$this->col_name}','{$this->col_sn}','{$this->sort}','{$kind}','{$file_name}','{$file['type']}','{$file['size']}','{$description}',0,'{$file['name']}','{$this->subdir}','{$hash_name}')"; //die($sql);
              $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
            }else{
              $sql = "replace into `{$this->ugmUpFilesTblName}` (`files_sn`,`col_name`,`col_sn`,`sort`,`kind`,`file_name`,`file_type`,`file_size`,`description`,`original_filename`,`sub_dir`,`hash_filename`) values('{$files_sn}','{$this->col_name}','{$this->col_sn}','{$this->sort}','{$kind}','{$file_name}','{$file['type']}','{$file['size']}','{$description}','{$file['name']}','{$this->subdir}','{$hash_name}')";

              $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
            }
            //die($sql);
          } else {
            redirect_header($_SERVER['PHP_SELF'],3, "Error:".$file_handle->error);
          }
        }
        $this->sort="";
      }

    }

  }

  ###############################################################################
  #  上傳圖片自動更新排序
  ###############################################################################
  function op_update_showPic_sort(){
    global $xoopsDB;
    $sort=0;
    foreach ($_POST['li'] as $files_sn) {
      if(!$files_sn)continue;
      $sort++;
      $sql="update ".$xoopsDB->prefix("{$this->prefix}_files_center")."
            set `sort`='{$sort}'
            where `files_sn`='{$files_sn}'";
      $xoopsDB->queryF($sql) or die("Save Sort Fail! (".date("Y-m-d H:i:s").")");
    }
    return "Save Sort OK({$sort})! (".date("Y-m-d H:i:s").")"._BP_F5;
  }

  //上傳元件
  public function upform($name='file',$accept="",$show="show",$c_w_n="col-md-"){
    //$maxlength=empty($maxlength)?"":"maxlength='{$maxlength}'";
    $accept=$accept?"accept='{$accept}'":"";// image/* ,
    $multiple=$this->multiple?"multiple='multiple'":"";


    if($show=="show"){
      $show=$this->list_show_file($c_w_n);
    }
    $main="
    <input type='file' name='{$name}[]' $multiple $accept class='form-control'>
    {$show}
    ";
    return $main;
  }

  //上傳元件(單張圖)$Pic->get_one_img_src($name,$this->col_sn,1,false,false);
  #上傳html語法(表單名稱，上傳類型，顯示舊圖，驗證)
  public function upform_one($name='file',$accept="",$show="show",$validate=""){
    //$maxlength=empty($maxlength)?"":"maxlength='{$maxlength}'";
    $accept=$accept?"accept='{$accept}'":"";// image/* ,
    $img="";
    if($show=="show" and $this->col_sn){
      $tmp=$this->get_one_img_src($name,$this->col_sn,1,true,false);
      if($tmp){
        $img="<div style='margin-top:10px;'><img src='{$tmp}' class='img-responsive'></div>";
      }
    }
    $validate=$validate?" validate[{$validate}]":"";//required
    $main="
    <input type='file' name='{$name}[]'  $accept class='form-control{$validate}'>
    {$img}
    ";
    return $main;
  }

  //上傳圖檔，$this->col_name=對應欄位名稱,$col_sn=對應欄位編號,$種類：img,file,$sort=圖片排序,$files_sn="更新編號"
  public function upload_single_img($upname='upfile',$main_width="",$thumb_width="120",$files_sn="",$desc=NULL,$safe_name=false,$hash=false){
    global $xoopsDB,$xoopsUser;

    //if(empty($main_width))$main_width="1280";
    if(empty($thumb_width))$thumb_width="120";

    //die(var_dump($_FILES[$upname]));
    //引入上傳物件
    include_once XOOPS_ROOT_PATH."/modules/tadtools/upload/class.upload.php";

    //取消上傳時間限制
    set_time_limit(0);
    //設置上傳大小
    ini_set('memory_limit', '80M');

    #---------------------------------------
    //$i檔案索引 0、1、2、、
    //$k=>name、type、tmp_name、error、size
    //$v=>xxx.jpg、image/jpeg、C:\Dropbox\server\UniServerZ_1\tmp\phpF0D6.tmp、0、620888
    $files = array();
    foreach ($_FILES[$upname] as $k => $l) {
      foreach ($l as $i => $v) {
        if (!array_key_exists($i, $files)){
          $files[$i] = array();
        }
        $files[$i][$k] = $v;//$file[0][name]=xxx.jpg
      }
    }
    //處理檔案上傳，檢查是否有上傳
    if($_FILES[$upname]['name'][0]){
      #有上傳
      foreach ($files as $file) {
        //先刪除舊檔($files_sn 由函數傳來！)
        if(!empty($files_sn)){
          $this->del_files($files_sn);
        }
        //自動排序
        if(empty($this->sort)){
          $this->sort=$this->auto_sort();
        }
        //取得檔案
        $file_handle = new upload($file,"zh_TW");

        if ($file_handle->uploaded) {
          #單檔上傳，先刪舊檔--------------------
          if(!$this->multiple){
            $sql = "select files_sn
                    from `{$this->ugmUpFilesTblName}`
                    where `col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}'";//die($sql);
            $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
            while($all=$xoopsDB->fetchArray($result)){
              //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
              foreach($all as $k=>$v){
                $$k=$v;
              }
              $this->del_files($files_sn);
            }
          }
          #---------------------------------------
          //取得副檔名
          $ext=strtolower($file_handle->file_src_name_ext);
          //判斷檔案種類
          if($ext=="jpg" or $ext=="jpeg" or $ext=="png" or $ext=="gif"){
            $kind="img";
          }else{
            $kind="file";
          }

          $file_handle->file_safe_name = false;
          $file_handle->file_overwrite = true;
          $file_handle->no_script = false;

          $hash_name=md5(rand(0,1000).$name);

          if($hash){
            $new_filename   = $hash_name;
          }else{
            $new_filename   = ($safe_name)?"{$this->col_name}_{$this->col_sn}_{$this->sort}":$file_handle->file_src_name_body;
          }

          //die($new_filename);
          $os_charset=(PATH_SEPARATOR==':')?"UTF-8":"Big5";//linux:windows

          if($os_charset != _CHARSET){
            $new_filename=iconv(_CHARSET, $os_charset, $new_filename);
          }
          $file_handle->file_new_name_body   = $new_filename;


          //若是(圖片且有設主圖寬度)才縮圖___1
          if($kind=="img" and !empty($main_width)){
            if($file_handle->image_src_x > $main_width){
              $file_handle->image_resize         = true;
              $file_handle->image_x              = $main_width;
              $file_handle->image_ratio_y         = true;
            }
          }
          $path=($kind=="img")?$this->ugmUpFilesImgDir:$this->ugmUpFilesDir;
          $readme=($hash)?"{$path}/{$hash_name}_info.txt":"";
          $file_handle->process($path);
          $file_handle->auto_create_dir = true;
          #------------------------------------------------------
          //若是圖片才製作小縮圖____2
          if($kind=="img"){
            $file_handle->file_safe_name = false;
            $file_handle->file_overwrite = true;

            $file_handle->file_new_name_body   = $new_filename;

            if($file_handle->image_src_x > $thumb_width){
              $file_handle->image_resize         = true;
              $file_handle->image_x              = $thumb_width;
              $file_handle->image_ratio_y         = true;
            }
            $file_handle->process($this->ugmUpFilesThumbDir);
            $file_handle->auto_create_dir = true;
          }
          #------------------------------------------------------

          #------------------------------------------------------
          //上傳檔案
          if($file_handle->processed) {
            $file_handle->clean();
            if($hash){
              $fp = fopen($readme, 'w');
              fwrite($fp, $file['name']);
              fclose($fp);
            }

            $file_name = ($safe_name)?"{$this->col_name}_{$this->col_sn}_{$this->sort}.{$ext}":$file['name'];

            $description=is_null($desc)?$file['name']:$desc;


            $hash_name=($hash)?"{$hash_name}.{$ext}":"";

            if(empty($files_sn)){
              $sql = "insert into `{$this->ugmUpFilesTblName}`  (`col_name`,`col_sn`,`sort`,`kind`,`file_name`,`file_type`,`file_size`,`description`,`counter`,`original_filename`,`sub_dir`,`hash_filename`) values('{$this->col_name}','{$this->col_sn}','{$this->sort}','{$kind}','{$file_name}','{$file['type']}','{$file['size']}','{$description}',0,'{$file['name']}','{$this->subdir}','{$hash_name}')"; //die($sql);
              $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
            }else{
              $sql = "replace into `{$this->ugmUpFilesTblName}` (`files_sn`,`col_name`,`col_sn`,`sort`,`kind`,`file_name`,`file_type`,`file_size`,`description`,`original_filename`,`sub_dir`,`hash_filename`) values('{$files_sn}','{$this->col_name}','{$this->col_sn}','{$this->sort}','{$kind}','{$file_name}','{$file['type']}','{$file['size']}','{$description}','{$file['name']}','{$this->subdir}','{$hash_name}')";

              $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
            }
            //die($sql);
          } else {
            redirect_header($_SERVER['PHP_SELF'],3, "Error:".$file_handle->error);
          }
        }
        $this->sort="";
      }

    }

  }

  //列出檔案
  public function list_show_file_b3($del=""){
    global $xoopsDB;
    $all_file="";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}'
            order by sort";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $fileidname=str_replace('.','',$file_name);
      if($kind=="file"){
        $thumb_pic=TADTOOLS_URL."/multiple-file-upload/downloads.png";
      }else{
        $thumb_pic="{$this->ugmUpFilesThumbUrl}/{$file_name}";
      }
      #顯示
      $del_list="";
      if($del){
        $del_list="
          <p>
            <input type='checkbox' name='del_{$this->col_name}[]' value='{$files_sn}' id='del_{$files_sn}'>
            <label class='checkbox-inline' for='del_{$files_sn}'>"._DELETE."</label>
          </p>
        ";
      }
      $all_file.="
        <li class='col-md-3' id='li_{$files_sn}'>
          <div class='thumbnail'>
            <p><i class='glyphicon glyphicon-move'></i>&nbsp;sort:&nbsp;{$sort}</p>
            <img src='{$thumb_pic}' alt='' style='width:100%;'>
          </div>
          $del_list
        </li>";
    }

    if($all_file){
      $jquery=get_jquery(true);
      $js_code="

        <script type='text/javascript'>
          $(document).ready(function(){
            //sort js start
            $('#sort_{$this->col_name}').sortable({ opacity: 0.6, cursor: 'move', update: function() {
                var order = $(this).sortable('serialize') +
                            '&op=op_update_showPic_sort'
                            ;
                $.post(
                  '".$_SERVER['PHP_SELF']."',
                  order,
                  function(theResponse){
                    $('#{$this->col_name}_save_msg').html(theResponse);
                });
            }
            });
            //sort js end
          });
        </script>
      ";
      $files="
        $js_code
        <div id='{$this->col_name}_save_msg'></div>
        <div class='row'>
          <ul class='thumbnails' id='sort_{$this->col_name}'>
            $all_file
          </ul>
        </div>
      ";
    }
    return $files;
  }

  //列出檔案
  public function list_show_file($c_w_n="col-md-"){
    global $xoopsDB,$xoopsUser;
    $all_file="";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}'
            order by sort";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $fileidname=str_replace('.','',$file_name);
      if($kind=="file"){
        $thumb_pic=TADTOOLS_URL."/multiple-file-upload/downloads.png";
      }else{
        $thumb_pic="{$this->ugmUpFilesThumbUrl}/{$file_name}";
      }
      #顯示

      $all_file.="
        <li class='col-md-3' id='li_{$files_sn}'>
          <div class='thumbnail'>
            <p><i class='glyphicon glyphicon-move'></i>&nbsp;sort:&nbsp;{$sort}</p>
            <img src='{$thumb_pic}' alt='' style='width:100%;'>
            <p>
              <input type='checkbox' name='del_{$this->col_name}[]' value='{$files_sn}' id='del_{$files_sn}'>
              <label class='checkbox-inline' for='del_{$files_sn}'>"._DELETE."</label>
            </p>
          </div>
        </li>";
    }

    if($all_file){
      $jquery=get_jquery(true);
      $js_code="
        $jquery
        <script type='text/javascript'>
          $(document).ready(function(){
            //sort js start
            $('#sort_{$this->col_name}').sortable({ opacity: 0.6, cursor: 'move', update: function() {
                var order = $(this).sortable('serialize') +
                            '&op=op_update_showPic_sort'
                            ;
                $.post(
                  '".$_SERVER['PHP_SELF']."',
                  order,
                  function(theResponse){
                    $('#{$this->col_name}_save_msg').html(theResponse);
                });
            }
            });
            //sort js end
          });
        </script>
      ";
      $files="
        $js_code
        <div id='{$this->col_name}_save_msg'></div>
        <div class='row'>
          <ul class='thumbnails' id='sort_{$this->col_name}'>
            $all_file
          </ul>
        </div>
      ";
    }


    return $files;
  }

  //得到全部圖片、縮圖 img 的 src 碼
  public function get_all_img_src($col_name="",$col_sn=""){
    global $xoopsDB;
    $src="";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$col_name}' and `col_sn`='{$col_sn}'
            order by sort
            ";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
    $i=0;$src="";
    while($all=$xoopsDB->fetchArray($result)){
      foreach($all as $k=>$v){
        $$k=$v;
      }
      if($files_sn and $kind=="img"){
        $src[$i]['main']="{$this->ugmUpFilesUrl}/{$file_name}";
        $src[$i]['thumb']="{$this->ugmUpFilesThumbUrl}/{$file_name}";
      }
      $i++;
    }
    #沒有圖
    if(!$src){
      $src[$i]['main']=XOOPS_URL."/modules/{$this->prefix}/images/no_1024.jpg";
      $src[$i]['thumb']=XOOPS_URL."/modules/{$this->prefix}/images/no_200.jpg";
    }
    return $src;
  }

  //得到單張縮圖 img 的 src 碼
  // $multiple=false;
  // $dir_name="/slider";
  // $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
  // $list[$k]['img']=$ugmUpFiles->get_one_img_src($ugmKind->get_kind(),$list_one['sn'],1,true,false);

  public function get_one_img_src($col_name="",$col_sn="",$sort=1,$thumb=false,$no_pic=true){
    global $xoopsDB;
    $src="";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$col_name}' and `col_sn`='{$col_sn}' and sort='{$sort}'
            ";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    $all=$xoopsDB->fetchArray($result);
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
    foreach($all as $k=>$v){
      $$k=$v;
    }
    if($files_sn and $kind=="img"){
      if($thumb){
        $src="{$this->ugmUpFilesThumbUrl}/{$file_name}";
      }else{
        $src="{$this->ugmUpFilesUrl}/{$file_name}";
      }
    }

    #沒有圖
    if(!$src and $no_pic){
      $src=$thumb?XOOPS_URL."/modules/ugm_tools/images/no_200.jpg":XOOPS_URL."/modules/ugm_tools/images/no_1024.jpg";
    }
    return $src;
  }
  //得到單張縮圖 img 的 html 碼
  public function get_one_img($col_name="",$col_sn="",$sort=1,$thumb=false){
    global $xoopsDB;
    $img="";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$col_name}' and `col_sn`='{$col_sn}' and sort='{$sort}'
            ";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    $all=$xoopsDB->fetchArray($result);
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
    foreach($all as $k=>$v){
      $$k=$v;
    }
    if($files_sn and $kind=="img"){
      if($thumb){
        $thumb_pic="{$this->ugmUpFilesThumbUrl}/{$file_name}";
      }else{
        $thumb_pic="{$this->ugmUpFilesUrl}/{$file_name}";
      }
      $img="<img src='$thumb_pic' class='img-responsive'>";
    }
    return $img;
  }
  //得到單張縮圖 img 的 檔名
  public function get_one_img_name($col_name="",$col_sn="",$sort=1,$thumb=false){
    global $xoopsDB;
    $img="";
    $sql = "select file_name from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$col_name}' and `col_sn`='{$col_sn}' and sort='{$sort}'
            ";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    list($file_name)=$xoopsDB->fetchRow($result);
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
    return $file_name;
  }

  //得到多張(縮)圖 img 的 html 碼
  public function get_multi_img($col_name="",$col_sn="",$readme=true,$max_count=0,$thumb=false){
    global $xoopsDB;
    $img="";
    $limit=$max_count?" limit {$max_count}":"";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$col_name}' and `col_sn`='{$col_sn}'
            order by sort
            $limit
            ";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $readme=$readme?"<p class='caption'>{$description}</p>":"";
      if($files_sn and $kind=="img"){
        if($thumb){
          $thumb_pic="{$this->ugmUpFilesThumbUrl}/{$file_name}";
        }else{
          $thumb_pic="{$this->ugmUpFilesUrl}/{$file_name}";
        }
        $img[]="<img src='$thumb_pic'>
                $readme
              ";
      }
    }
    return $img;
  }

  //列出縮圖
  public function list_show_thumb($c_w_n="span"){
    global $xoopsDB,$xoopsUser;
    $all_file="";
    $sql = "select * from `{$this->ugmUpFilesTblName}`
            where `col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}'
            order by sort";//die($sql);
    $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<p>$sql</p>");
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $files_sn, $col_name, $col_sn, $sort, $kind, $file_name, $file_type, $file_size, $description
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $fileidname=str_replace('.','',$file_name);
      if($kind=="file"){
        $thumb_pic=TADTOOLS_URL."/multiple-file-upload/downloads.png";
      }else{
        $thumb_pic="{$this->ugmUpFilesThumbUrl}/{$file_name}";
      }
      #顯示

      $all_file.="
        <li class='{$c_w_n}2' id='li_{$files_sn}'>
          <div class='thumbnail'>
            <div style='word-wrap: break-word;word-break: break-all;'>&nbsp;sort:&nbsp;{$sort}</div>
            <img src='{$thumb_pic}' alt='' style='width:100%;'>
          </div>
        </li>";
    }

    if($all_file){
      $files="
        <div id='{$this->col_name}_save_msg'></div>
        <div class='row'>
          <ul class='thumbnails' id='sort_{$this->col_name}'>
            $all_file
          </ul>
        </div>
      ";
    }
    return $files;
  }

  private function delete_directory($dirname) {
    if (is_dir($dirname))
        $dir_handle = opendir($dirname);
    if (!$dir_handle)
        return false;
    while($file = readdir($dir_handle)) {
        if ($file != "." && $file != "..") {
            if (!is_dir($dirname."/".$file))
                unlink($dirname."/".$file);
            else
                delete_directory($dirname.'/'.$file);
        }
    }
    closedir($dir_handle);
    rmdir($dirname);
    return true;
  }

  //刪除實體檔案
  public function del_files($files_sn=""){
    global $xoopsDB,$xoopsUser;

    if(!empty($files_sn)){
      $del_what="`files_sn`='{$files_sn}'";
    }elseif(!empty($this->col_name) and !empty($this->col_sn)){
      $and_sort=(empty($this->sort))?"":"and `sort`='{$this->sort}'";
      $del_what="`col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}' $and_sort";
    }

    $sql = "select * from `{$this->ugmUpFilesTblName}`  where $del_what";//die($sql);
    //die($sql);
    $result=$xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error()."<br>".$sql);

    while(list($files_sn,$col_name,$col_sn,$sort,$kind,$file_name,$file_type,$file_size,$description,$counter,$original_filename,$hash_filename,$sub_dir)=$xoopsDB->fetchRow($result)){
      $this->set_col($col_name,$col_sn,$sort);
      $del_sql = "delete  from `{$this->ugmUpFilesTblName}`  where files_sn='{$files_sn}'";//die($del_sql);
      $xoopsDB->queryF($del_sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

      if(!empty($hash_filename))$file_name=$hash_filename;

      if($kind=="img"){
        unlink("{$this->ugmUpFilesImgDir}/{$file_name}") or die("實體檔案刪除錯誤：{$this->ugmUpFilesImgDir}/{$file_name}");
        unlink("{$this->ugmUpFilesThumbDir}/{$file_name}");
      }else{
        unlink("{$this->ugmUpFilesDir}/{$file_name}");
      }

      $f=explode('.',$hash_filename);
      if(file_exists("{$this->ugmUpFilesDir}/{$f[0]}_info.txt")){
        unlink("{$this->ugmUpFilesDir}/{$f[0]}_info.txt");
      }

      $tmp_dir=XOOPS_ROOT_PATH."/uploads/{$this->prefix}/tmp/{$files_sn}";
      $this->delete_directory($tmp_dir);
    }
  }


  public function set_prefix($prefix=""){
    $this->prefix = $prefix;
    $this->set_path();
  }
  //設定路徑
  public function set_path(){
    $this->ugmUpFilesDir=XOOPS_ROOT_PATH."/uploads/{$this->prefix}{$this->subdir}{$this->file_dir}";
    $this->ugmUpFilesUrl=XOOPS_URL."/uploads/{$this->prefix}{$this->subdir}{$this->file_dir}";
    $this->ugmUpFilesImgDir=XOOPS_ROOT_PATH."/uploads/{$this->prefix}{$this->subdir}{$this->image_dir}";
    $this->ugmUpFilesImgUrl=XOOPS_URL."/uploads/{$this->prefix}{$this->subdir}{$this->image_dir}";
    $this->ugmUpFilesThumbDir=XOOPS_ROOT_PATH."/uploads/{$this->prefix}{$this->subdir}{$this->thumbs_dir}";
    $this->ugmUpFilesThumbUrl=XOOPS_URL."/uploads/{$this->prefix}{$this->subdir}{$this->thumbs_dir}";

  }
  //設定目錄
  public function set_dir($type,$dir=""){
    if($type=="subdir"){
      $this->subdir = $dir;
    }elseif($type=="file"){
      $this->file_dir = $dir;
    }elseif($type=="image"){
      $this->image_dir = $dir;
    }elseif($type=="thumbs"){
      $this->thumbs_dir = $dir;
    }
    $this->set_path();
  }
  //設定欄名，sn,sort
  public function set_col($col_name="",$col_sn="",$sort=""){
    $this->col_name = $col_name;
    $this->col_sn = $col_sn;
    $this->sort = $sort;
  }


  //自動編號
  public function auto_sort(){
    global $xoopsDB,$xoopsUser;

    $sql = "select max(sort) from `{$this->ugmUpFilesTblName}`  where `col_name`='{$this->col_name}' and `col_sn`='{$this->col_sn}'";

     $result=$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
     list($max)=$xoopsDB->fetchRow($result);
    return ++$max;
  }

}
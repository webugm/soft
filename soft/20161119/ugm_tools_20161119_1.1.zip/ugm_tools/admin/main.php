<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2015-04-12
// $Id:$
// ------------------------------------------------------------------------- //

/*-----------引入檔案區--------------*/
include_once "../../../mainfile.php";
$isAdmin=true;
include_once "../function.php";
$xoopsOption['template_main'] = (isset($_SESSION['bootstrap']) and $_SESSION['bootstrap']=='3')? 'ugm_tools_adm_main_b3.html':'ugm_tools_adm_main.html';
include_once "header.php";

/*-----------功能函數區--------------*/


    //
    function f1(){
      global $xoopsDB , $xoopsTpl;
      $main="Hello Admin!";
      $xoopsTpl->assign('main' , $main);
    }

    //
    function f2(){
      global $xoopsDB;

    }
    

/*-----------執行動作判斷區----------*/
$op=empty($_REQUEST['op'])?"":$_REQUEST['op'];


switch($op){
  /*---判斷動作請貼在下方---*/

  
    case "f2":
    f2();
    header("location: {$_SERVER['PHP_SELF']}");
    break;

    default:
    f1();
    break;
    

  /*---判斷動作請貼在上方---*/
}

/*-----------秀出結果區--------------*/
$xoopsTpl->assign("isAdmin" , true);
$xoTheme->addStylesheet(XOOPS_URL.'/modules/tadtools/css/xoops_adm.css');
include_once 'footer.php';
?>
<?php
#kind
define("_MD_UGMMOUDEL_KIND_TITLE", "類別名稱");
#nav
define("_MD_UGMMOUDEL_NAV_TITLE", "選單名稱");

define("_MD_UGMMOUDEL_KIND_OFSN", "父類別");
define("_MD_UGMMOUDEL_KIND_ENABLE", "狀態");
define("_MD_UGMMOUDEL_KIND_ENABLE_1", "啟用");
define("_MD_UGMMOUDEL_KIND_ENABLE_0", "停用");
define("_MD_UGMMOUDEL_KIND_TARGET", "連結狀態");
define("_MD_UGMMOUDEL_KIND_TARGET_1", "外連");
define("_MD_UGMMOUDEL_KIND_TARGET_0", "本站");
define("_MD_UGMMOUDEL_KIND_URL", "網址");
define("_MD_UGMMOUDEL_KIND_URL_TITLE", "網址名稱");
define("_MD_UGMMOUDEL_KIND_SORT", "排序");
define("_MD_UGMMOUDEL_KIND_NO_DEL", "分類已使用，目前無法刪除！！");
define("_MD_UGMMOUDEL_KIND_ROOT", "根目錄");
define("_MD_UGMMOUDEL_KIND_FUN", "功能");
define("_MD_UGMMOUDEL_KIND_CREATE_SUB", "建立子類別");
define("_MD_UGMMOUDEL_KIND_HAVE_SUB_NOT_DEL", "尚有子類別不能刪除");
define("_MD_UGMMOUDEL_KIND_LEVEL_ERROR", "來源層數+目的的階層 > 類別層數，請先調整來源的下層，再重新拖曳！！");
define("_MD_UGMMOUDEL_KIND_ROOT_ERROR", "根目錄不能移動！！");
define("_MD_UGMMOUDEL_KIND_RESET_BUTTON", "重整畫面");

define('_MD_UGMMOUDEL_ADD_FORM_TITLE', '新增表單');
define('_MD_UGMMOUDEL_EDIT_FORM_TITLE', '編輯表單');
define('_MD_UGMMOUDEL_RETURN_LIST', '返回');
define('_MD_UGMMOUDEL_SHOWONE', '單筆顯示');
define('_MD_UGMMOUDEL_RETURN_MAIN', '前台');
define('_MD_UGMMOUDEL_ALL', '全部');
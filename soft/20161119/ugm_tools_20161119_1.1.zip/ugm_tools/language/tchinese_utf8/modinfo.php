<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2015-04-12
// $Id:$
// ------------------------------------------------------------------------- //
include_once XOOPS_ROOT_PATH."/modules/tadtools/language/{$xoopsConfig['language']}/modinfo_common.php";

define('_MI_UGMTOOLS_NAME','ugm_tools');
define('_MI_UGMTOOLS_AUTHOR','ugm_tools');
define('_MI_UGMTOOLS_CREDITS','');
define('_MI_UGMTOOLS_DESC','ugm_tools');
define('_MI_UGMTOOLS_AUTHOR_WEB','');
define('_MI_UGMTOOLS_ADMENU1', "管理介面");
define('_MI_UGMTOOLS_ADMENU1_DESC', "管理介面");

define('_MI_UGMTOOLS_ADMENU2', "選單管理");
define('_MI_UGMTOOLS_ADMENU2_DESC', "選單管理");
?>
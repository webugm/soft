<?php
/*
version 1.1
date 2015-03-10
use
 */
#---------------------------------
defined('XOOPS_ROOT_PATH') || die("XOOPS root path not defined");
class ugmKind
{
  protected $tbl;//資料表
  protected $kind;//類別
  protected $stop_level;//層數
  protected $ofsn;//父類別

  function __construct($tbl="",$kind="",$stop_level=1,$ofsn=null){
    $this->set_tbl($tbl);
    $this->set_kind($kind);
    $this->set_stop_level($stop_level);
    $this->set_ofsn($ofsn);
  }
  #--------- 設定類 --------------------
  #設定資料表
  public function set_tbl($value=""){
    $this->tbl = $value;
  }
  #設定類別
  public function set_kind($value=""){
    $this->kind = $value;
  }
  #設定層數
  public function set_stop_level($value=1){
    $this->stop_level = $value;
  }
  #設定父類別
  public function set_ofsn($value=null){
    $this->ofsn = $value;
  }
  //--------- 取得類 ------------*/
  #取得資料表
  public function get_tbl()
  {
    return $this->tbl;
  }
  #取得分類
  public function get_kind()
  {
    return $this->kind;
  }
  #取得層數
  public function get_stop_level()
  {
    return $this->stop_level;
  }
  #取得父類別
  public function get_ofsn()
  {
    return $this->ofsn;
  }

  #取得外鍵下拉選單
  public function get_ForeignKeyForm($kind_arr)
  {
    $kind_option="";
    foreach($kind_arr as $key=>$value){
      $selected="";
      if($this->kind == $key){
        $selected=" selected";
      }
      $kind_option.="<option value='{$key}'{$selected}>{$value['title']}</option>";
    }
    $kind_form="
      <div class='row' style='margin-bottom:5px;'>
        <div class='col-md-4'>
          <select name='kind' id='kind' onchange=\"location.href='?kind='+this.value\"  class='form-control'>
            $kind_option
          </select>
        </div>
      </div>
    ";
    return $kind_form;
  }

  
  ################################################################
  #  取得選單列表
  #  有資料表沒有 kind 、ofsn欄位
  ################################################################
  public function get_admin_list_nav($ofsn=0,$level=1)
  {
    global $xoopsDB;
    
    #---- 過濾讀出的變數值 ----
    $myts = MyTextSanitizer::getInstance();

    #---- and_key ----
    if($this->kind and $this->ofsn !== null){
      #有分類 且 有 ofsn
      $and_key = "where kind='{$this->kind}' and ofsn='{$ofsn}'";
    }elseif(!$this->kind and $this->ofsn !== null){
      #無分類 且 有 ofsn
      $and_key = "where ofsn='{$ofsn}'";
    }elseif($this->kind and $this->ofsn === null){
      #有分類 且 無 ofsn
      $and_key = "where kind='{$this->kind}'";
    }else{
      #無分類 且 無 ofsn
      $and_key = "";
    }


    #檢查目前階層是否大於層次
    if($level>$this->stop_level)return;

    #設定下層
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            {$and_key}
            order by sort";//die($sql);

    
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $i=0;$rows="";
    while($row=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort url target
      //Array ( [sn] => 1 [ofsn] => 0 [title] => 育將電腦 [sort] => 1 [enable] => 1 [kind] => kind [url] => http://www.ugm.com.tw [target] => 1 [col_sn] => 0 [content] => )
      $row['sn']      = intval($row['sn']);
      $row['ofsn']    = intval($row['ofsn']);
      $row['enable']  = intval($row['enable']);
      $row['target']  = intval($row['target']);
      $row['title']   = $myts->htmlSpecialChars($row['title']);
      $row['url']     = $myts->htmlSpecialChars($row['url']);
      
      
      $sub = "";//下層
      if($this->ofsn !== null){        
        $sub=$this->get_admin_list_nav($row['sn'],$down_level);
      }

      #移動圖示
      if($sub){
        #有下層
        $icon['move_i']        = $this->stop_level > $down_level ? true:false;
      }else{
        #無下層
        $icon['move_i']        = true ;
      }

      #資料夾圖示(最後一層沒有)
      $icon['folder_i']        = $this->stop_level > $level ? true:false;

      #增加類別圖示
      $icon['add_down_level_i']= $this->stop_level > $level ? true:false;
      #排序圖示
      $icon['sort_i']=true;

      $row['icon'] = $icon;

      $rows[$i]=$row;
      $rows[$i]['sub']=$sub;
      $i++;
    }
    return $rows;
  }

  ################################################################
  #  取得類別body的html
  #  data-tt-id 本身
  #  data-tt-parent-id 父層
  ################################################################
  public function get_admin_list_nav_html($list,$title_arr)
  {
    $html = "";
    foreach ($list as $k=>$v){
      $html .= $this -> get_admin_html($v,$title_arr);
      for($i=1; $i<$this->stop_level and $v['sub'];$i++){
        foreach ($v['sub'] as $k=>$v){
          $html .= $this -> get_admin_html($v,$title_arr);
        }
      }
    }
    return $html;
  }


  ################################################################
  #  取得類別body的html
  #  data-tt-id 本身
  #  data-tt-parent-id 父層
  #  $title_arr 只取引索引值，且排序
  ################################################################
  public function get_admin_html($v,$title_arr)
  {
    $v['ofsn'] = intval($v['ofsn']);
    
    #移動
    $v['icon']['move_i']=$v['icon']['move_i'] ? "
        <img src='".XOOPS_URL."/modules/tadtools/treeTable/images/move_s.png' class='folder' alt='"._MA_TREETABLE_MOVE_PIC."' title='"._MA_TREETABLE_MOVE_PIC."'>
      ":"";

    #資料夾
    $v['icon']['folder_i']=$v['icon']['folder_i'] ? "<span class='folder'></span>":"";

    #排序
    $v['icon']['sort_i']=$v['icon']['sort_i'] ? "<img src='".XOOPS_URL."/modules/tadtools/treeTable/images/updown_s.png' style='cursor: s-resize;' alt='"._TAD_SORTABLE."' title='"._TAD_SORTABLE."'>
    ":"";

    #新增下層
    $v['icon']['add_down_level_i']=$v['icon']['add_down_level_i'] ? "<a href='?op=op_form&ofsn={$v['sn']}&kind={$this->kind}'><img src='".XOOPS_URL."/modules/ugm_tools/images/add.gif'  alt='In ({$v['title']}) "._MD_UGMMOUDEL_KIND_CREATE_SUB."' title='In ({$v['title']}) "._MD_UGMMOUDEL_KIND_CREATE_SUB."'>
      </a>
    ":"";

    #啟用
    $v['enable'] = $v['enable'] ? "
      <a href='?op=op_update_enable&sn={$v['sn']}&enable=0&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_0."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_0."'><img src='".XOOPS_URL."/modules/ugm_tools/images/on.png' /></a>
    ":"
      <a href='?op=op_update_enable&sn={$v['sn']}&enable=1&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_1."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_1."'><img src='".XOOPS_URL."/modules/ugm_tools/images/off.png' /></a>
    ";

    #外連
    $v['target']=$v['target']?"<a href='?op=op_update_target&sn={$v['sn']}&target=0&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_0."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_0."'><img src='".XOOPS_URL."/modules/ugm_tools/images/on.png' /></a>":"<a href='?op=op_update_target&sn={$v['sn']}&target=1&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_1."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_1."'><img src='".XOOPS_URL."/modules/ugm_tools/images/off.png' /></a>";    

    $html_body = "";
    foreach ($title_arr as $key =>$t){
      if($key == "title"){
        $html_body .=
        "<td class='text-left'>\n
          {$v['icon']['folder_i']}\n{$v['icon']['move_i']}\n{$v['icon']['sort_i']}\n
          <input type='text' name='title[{$v['sn']}]' value='{$v['title']}' id='title_{$v['sn']}' class='validate[required]' style='width:60%;'>\n
          {$v['icon']['add_down_level_i']}\n
        </td>\n";
      }elseif($key == "url"){        
        $html_body .=
        "<td class='text-left'>\n
          <input type='text' name='url[{$v['sn']}]' value='{$v['url']}' id='url_{$v['sn']}' class='form-control'>\n
        </td>\n";
      }elseif($key == "target"){       
        $html_body .=
        "<td class='text-center'>\n
          {$v['target']}\n
        </td>\n";
      }elseif($key == "enable"){      
        $html_body .=
        "<td class='text-center'>\n
          {$v['enable']}\n
        </td>\n";
      }elseif($key == "function"){     
        $html_body .=
        "<td class='text-center'>\n
          <a href='?op=op_form&sn={$v['sn']}&kind={$this->kind}' class='btn btn-success btn-xs' title='"._EDIT."'>"._EDIT."</a>\n
          <a href='javascript:op_delete_js({$v['sn']});' class='btn btn-danger btn-xs'>
            "._DELETE."
          </a>\n
        </td>\n";        
      }
    }

    $html .=
    "<tr id='tr_{$v['sn']}' data-tt-id='{$v['sn']}' data-tt-parent-id='{$v['ofsn']}' >\n
      {$html_body}        
    </tr>\n
    ";
    return $html;
  }


  ################################################################
  #  取得類別body的陣列
  #  有資料表沒有 kind 、ofsn欄位
  ################################################################
  public function get_admin_list_body_arr($ofsn=0,$level=1)
  {
    global $xoopsDB;
    
    #---- 過濾讀出的變數值 ----
    $myts = MyTextSanitizer::getInstance();

    if($this->kind and $this->ofsn !== null){
      #有分類 且 有 ofsn
      $and_key = "where kind='{$this->kind}' and ofsn='{$ofsn}'";
    }elseif(!$this->kind and $this->ofsn !== null){
      #無分類 且 有 ofsn
      $and_key = "where ofsn='{$ofsn}'";
    }elseif($this->kind and $this->ofsn === null){
      #有分類 且 無 ofsn
      $and_key = "where kind='{$this->kind}'";
    }else{
      #無分類 且 無 ofsn
      $and_key = "";
    }

    #檢查目前階層是否大於層次
    if($level>$this->stop_level)return;
    #設定下層
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            {$and_key}
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $i=0;$rows="";
    while($row=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort
      //Array ( [sn] => 1 [ofsn] => 0 [title] => 育將電腦 [sort] => 1 [enable] => 1 [kind] => kind [url] => http://www.ugm.com.tw [target] => 1 [col_sn] => 0 [content] => )
      $row['sn']      = intval($row['sn']);
      $row['enable']  = intval($row['enable']);
      $row['target']  = intval($row['target']);
      $row['title']   = $myts->htmlSpecialChars($row['title']);
      $row['url']     = $myts->htmlSpecialChars($row['url']);

      $sub = "";//下層
      if($this->ofsn !== null){
        $sub=$this->get_admin_list_body_arr($row['sn'],$down_level);
      }

      //移動圖示
      if($sub){
        #有下層
        $icon['move_i']        = $stop_level > $down_level ? true:false;
        //$row['sub'] = $sub;
      }else{
        #無下層
        $icon['move_i']        = true ;
      }

      //資料夾圖示(最後一層沒有)
      $icon['folder_i']        = $this->stop_level > $level ? true:false;
      //增加類別圖示
      $icon['add_down_level_i']= $this->stop_level > $level ? true:false;
      //排序圖示
      $icon['sort_i']=true;

      $row['icon'] = $icon;
      $rows[$i]=$row;
      //$rows[$i]['icon']=$icon;
      $rows[$i]['sub']=$sub;
      $i++;
    }
    return $rows;
  }

  ################################################################
  #  取得類別body的html
  #  data-tt-id 本身
  #  data-tt-parent-id 父層
  ################################################################
  public function get_html($v,$title_arr)
  {
    // $text_inden="";
    // for($i=0;$i < $inden;$i++)
    // {
    //   $text_inden.="&nbsp;&nbsp;&nbsp;&nbsp;";
    // }
    $v['ofsn'] = intval($v['ofsn']);
    #移動
    $v['icon']['move_i']=$v['icon']['move_i'] ? "
        <img src='".XOOPS_URL."/modules/tadtools/treeTable/images/move_s.png' class='folder' alt='"._MA_TREETABLE_MOVE_PIC."' title='"._MA_TREETABLE_MOVE_PIC."'>
      ":"";
    #資料夾
    $v['icon']['folder_i']=$v['icon']['folder_i'] ? "<span class='folder'></span>":"";
    #排序
    $v['icon']['sort_i']=$v['icon']['sort_i'] ? "<img src='".XOOPS_URL."/modules/tadtools/treeTable/images/updown_s.png' style='cursor: s-resize;' alt='"._TAD_SORTABLE."' title='"._TAD_SORTABLE."'>
    ":"";
    #新增
    $v['icon']['add_down_level_i']=$v['icon']['add_down_level_i'] ? "<a href='?op=op_form&ofsn={$v['sn']}&kind={$this->kind}'><img src='".XOOPS_URL."/modules/ugm_tools/images/add.gif'  alt='In ({$v['title']}) "._MD_UGMMOUDEL_KIND_CREATE_SUB."' title='In ({$v['title']}) "._MD_UGMMOUDEL_KIND_CREATE_SUB."'>
      </a>
    ":"";
    #啟用
    $v['enable'] = $v['enable'] ? "
      <a href='?op=op_update_enable&sn={$v['sn']}&enable=0&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_0."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_0."'><img src='".XOOPS_URL."/modules/ugm_tools/images/on.png' /></a>
    ":"
      <a href='?op=op_update_enable&sn={$v['sn']}&enable=1&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_1."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_1."'><img src='".XOOPS_URL."/modules/ugm_tools/images/off.png' /></a>
    ";


    $v['target']=$v['target']?"<a href='?op=op_update_target&sn={$v['sn']}&target=0&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_0."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_0."'><img src='".XOOPS_URL."/modules/ugm_tools/images/on.png' /></a>":"<a href='?op=op_update_target&sn={$v['sn']}&target=1&kind={$this->kind}' title='"._MD_UGMMOUDEL_KIND_ENABLE_1."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_1."'><img src='".XOOPS_URL."/modules/ugm_tools/images/off.png' /></a>";

    

    foreach ($title_arr as $key =>$t){
      if($key == "title"){
        $html_body .=
        "<td class='text-left'>\n
          {$v['icon']['folder_i']}\n{$v['icon']['move_i']}\n{$v['icon']['sort_i']}\n
          <input type='text' name='title[{$v['sn']}]' value='{$v['title']}' id='title_{$v['sn']}' class='validate[required]' style='width:60%;'>\n
          {$v['icon']['add_down_level_i']}\n
        </td>\n";
      }elseif($key == "url"){        
        $html_body .=
        "<td class='text-left'>\n
          <input type='text' name='url[{$v['sn']}]' value='{$v['url']}' id='url_{$v['sn']}' class='form-control'>\n
        </td>\n";
      }elseif($key == "target"){       
        $html_body .=
        "<td class='text-center'>\n
          {$v['target']}\n
        </td>\n";
      }elseif($key == "enable"){      
        $html_body .=
        "<td class='text-center'>\n
          {$v['enable']}\n
        </td>\n";
      }elseif($key == "function"){     
        $html_body .=
        "<td class='text-center'>\n
          <a href='?op=op_form&sn={$v['sn']}&kind={$this->kind}' class='btn btn-success btn-xs'>
            "._EDIT."
          </a>\n
          <a href='javascript:op_delete_js({$v['sn']});' class='btn btn-danger btn-xs'>
            "._DELETE."
          </a>\n
        </td>\n";        
      }
    }

    $html .=
    "<tr id='tr_{$v['sn']}' data-tt-id='{$v['sn']}' data-tt-parent-id='{$v['ofsn']}' >\n
      {$html_body}        
    </tr>\n
    ";
    return $html;
  }

  ################################################################
  #  取得類別body的html
  #  data-tt-id 本身
  #  data-tt-parent-id 父層
  ################################################################
  public function get_admin_list_body_html($list,$title_arr)
  {
    $html = "";
    foreach ($list as $k=>$v){
      $html .= $this -> get_html($v,$title_arr);
      for($i=1; $i<$this->stop_level and $v['sub'];$i++){
        foreach ($v['sub'] as $k=>$v){
          $html .= $this -> get_html($v,$title_arr);
        }
      }
    }
    return $html;
  }


  #檢查類-----------------------------------
  #確認底下有幾層
  #chk_kind_level_down
  public function chk_kind_level_down($sn_in,$level=1,$get_level=1)
  {
    global $xoopsDB;

    if($level>$this->stop_level)return $level;
    $level++;
    $and_key = "";

    if($this->kind){
      #有分類 
      $and_key = " and kind='{$this->kind}'";
    }

    $sql = "select sn
            from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$sn_in}'{$and_key}"; //return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    while($row=$xoopsDB->fetchArray($result)){
      $get_level_tmp=$this->chk_kind_level_down($row['sn'],$level,$level);
      $get_level=($get_level_tmp > $get_level)?$get_level_tmp:$get_level;
    }
    return $get_level;
  }

  ###########################################################
  #  確認所在層數
  ###########################################################
  public function chk_kind_level($sn,$level=1)
  {
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level>$this->stop_level)return $level;
    $sql = "select ofsn
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$sn}'";// return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($ofsn)=$xoopsDB->fetchRow($result);
    if(!$ofsn)return $level;
    return $this->chk_kind_level($ofsn,++$level);
  }


  ###########################################################
  #  排序全部重整
  ###########################################################
  public function set_sort_reset($ofsn=0,$level=1,$sort=1){
    global $xoopsDB;

    if($level>$this->stop_level)return $sort;

    $down_level=$level + 1;

    $sql = "select `sn` from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    #--------------------------------------------------------------------
    while($row=$xoopsDB->fetchArray($result)){
      $sql_1 = "update ".$xoopsDB->prefix($this->tbl)." set
        `sort`   = '{$sort}'
        where sn='{$row['sn']}'";
      $xoopsDB->queryF($sql_1) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
      $sort=$this->set_sort_reset($row['sn'],$down_level,++$sort);
    }
    return $sort;
  }

  //----以上開發完成要刪除
  
  #佈景專用
  ################################################################
  #  取得 選單
  ################################################################
  public function get_use_theme_nav($ofsn=0,$level=1)
  {
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return;
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $sub="";$i=0;
    while($all=$xoopsDB->fetchArray($result)){

      $icon['folder_i']        =$this->stop_level>$level?true:false;
      $icon['move_i']          =$level != 1       ?true:false;
      $icon['add_down_level_i']=$this->stop_level>$level?true:false;
      $icon['sort_i']=true;
      $all['url']=str_replace ("{XOOPS_URL}",XOOPS_URL,$all['url']);//置換代碼

      $sub=$this->get_use_theme_nav($all['sn'],$down_level);
      $list[$i]=$all;
      $list[$i]['icon']=$icon;
      $list[$i]['sub']=$sub;
      $i++;
    }
    return $list;
  }


  ################################################################
  #  取得 選單
  ################################################################
  public function get_use_theme_nav_html($ofsn=0,$level=1)
  {
    global $xoopsDB;

    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return;
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $sub="";$i=0;
    while($all=$xoopsDB->fetchArray($result)){
      //$all['url']=str_replace ("{XOOPS_URL}",XOOPS_URL,$all['url']);//置換代碼
      $sub=$this->get_use_theme_nav_html($all['sn'],$down_level);

      $list[$i]=$all;
      $list[$i]['sub']=$sub;
      $i++;
    }
    return $list;
  }


  #----後台----
  #以流水號取得某筆分類資料
  public function get_one_table_4_sn($sn="")
  {
    global $xoopsDB;
    if(empty($sn))return;
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)." where sn='{$sn}'";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $data=$xoopsDB->fetchArray($result);
    return $data;
  }

  #取得管理者類別選項(stop_level那層可選)
  #enable=0 可選
  public function get_admin_list_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent="")
  {
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_admin_list_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }

  #(後台類別表單用、每層都可以選)
  #enable=0 可選
  public function get_admin_all_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent="")
  {
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $selected=($in_sn==$sn)?" selected":"";
      if($level != $stop_level){
        $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
        $main.=$this->get_admin_all_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
      }else{
        $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
      }
    }
    return $main;
  }

  #######################################################
  #  取得父類別選單->選項(後台類別表單用)# op_form
  #######################################################
  public function get_admin_form_ofsn_option($ofsn_check,$ofsn=0,$level=1,$indent="")
  {
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level >= $this->stop_level)return;
    $down_level=$level+1;
    $indent.="&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($ofsn_check==$sn)?" selected":"";
       $main.="<option value='{$sn}'{$selected}>{$indent}{$title}</option>";
       $main.=$this->get_admin_form_ofsn_option($ofsn_check,$sn,$down_level,$indent);
    }
    return $main;
  }
  ################################################################
  #  取得類別body的資料
  ################################################################
  public function get_admin_list_bodyImg($ofsn=0,$level=1)
  {
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return;
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $sub="";$i=0;$list="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort
      /*
      foreach($all as $k=>$v){
        $$k=$v;
      }
      */
      $icon['folder_i']        =$this->stop_level>$level?true:false;
      $icon['move_i']          =$level != 1       ?true:false;
      $icon['add_down_level_i']=$this->stop_level>$level?true:false;
      $icon['sort_i']=true;

      $sub=$this->get_admin_list_bodyImg($all['sn'],$down_level);
      #資料欄位有增減
      /*
      $list[]=array('sn' => $sn, 'ofsn' => $ofsn, 'title' => $title, 'enable' => $enable,'icon' => $icon,"target"=>$target,"url"=>$url,'sub'=>$sub);
      */
      //print_r($all);die();
      $all['block_id']=$all['block_id']?$all['block_id']:"";
      $list[$i]=$all;
      $list[$i]['icon']=$icon;
      $list[$i]['sub']=$sub;
      $i++;
    }
    return $list;
  }

  #前台

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_list_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent="")
  {
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and enable='1' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_use_list_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }

  #取得使用者類別選項(每層都可選)
  public function get_use_list_all_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent="")
  {
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and enable='1' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       $main.=$this->get_use_list_all_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
    }
    return $main;
  }



  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_array($in_sn="",$ofsn=0 ,$level=1)
  {
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level > $this->stop_level)return;
    $down_level=$level++;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}'  and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    $main="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $active=($in_sn==$sn)?1:0;
      $sub="";
      $sub=$this->get_use_kind_array($in_sn,$sn,$down_level);
      $main[]=array("sn"=>$sn,"title"=>$title,"active"=>$active,"sub"=>$sub);
    }
    return $main;
  }
  #
  #取得使用者類別第1個選項
  public function get_use_first_kind(){
    global $xoopsDB;
    #層數預設值
    $sql = "select sn from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='0' and kind='{$this->kind}' and enable='1'
            limit 1
            ";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($sn)=$xoopsDB->fetchRow($result);
    return $sn;
  }
  #-------------------------------------

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_option1($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $disabled=($level != $stop_level)?" disabled":"";
       $selected=($in_sn==$sn)?" selected":"";
       $main.="<option value='{$sn}'{$selected}{$disabled}>{$indent}{$title}</option>";
       $main.=$this->get_use_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
    }
    return $main;
  }
  #-------------------------------------

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind} and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_use_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }
  #-------------------------------------
  #取得使用者類別選項(value = title)一定只有一層
  public function get_use_kind_option_value_title($in_sn){
    global $xoopsDB;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='0' {$and_kind} and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$title)?" selected":"";
       $main.="<option value='{$title}' {$selected}>{$title}</option>";
    }
    return $main;
  }
  #-------------------------------------

  #取得使用者類別導航路徑
  public function get_user_kind_dir($in_sn){
    global $xoopsDB;
    #層數預設值
    $sql = "select *
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$in_sn}'";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $list="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       $parent="";
       if($all['ofsn']){
         $parent=$this->get_user_kind_dir($all['ofsn']);
       }
       $list[]=array("sn"=>$all['sn'],"ofsn"=>$all['ofsn'],"title"=>$all['title'],"parent"=>$parent);
    }
    return $list;
  }
  #-------------------------------------

  # 取得使用者類別複選選項,表單值為title且只有一層
  # $ugmKind->get_use_kind_checkbox_option_for_title($DBV['contact_service'])
  # 傳入值 = 標題1,標題2......
  public function get_use_kind_checkbox_option_for_title($in_txt=""){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    #將傳入值轉成陣列
    if($in_txt){
      $in_txt_arr=explode(",",$in_txt);
    }
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $checked=(in_array($title,$in_txt_arr))?" checked":"";
      $main.="<input type='checkbox' name='{$this->kind}[]' id='{$this->kind}_{$sn}' value='{$title}' {$checked}><label for='{$this->kind}_{$sn}'> {$title}</label>&nbsp;&nbsp;&nbsp;&nbsp;\n
      ";
    }
    return $main;
  }
  #-------------------------------------

  #以流水號取得標題
  public function get_kind_title_from_sn($sn){
    global $xoopsDB;
    $title="";
    $sql="select title
          from ".$xoopsDB->prefix($this->tbl)."
          where sn='{$sn}'
          ";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($title)=$xoopsDB->fetchRow($result);
    return $title;
  }
  #-------------------------------------
  #取得類別複選選項(sn)陣列 轉 (title)陣列
  public function get_use_kind_sn2title($in_sn){
    global $xoopsDB;
    $title="";
    #將傳入值轉成陣列
    if($in_sn){
      $in_sn_arr=explode(",",$in_sn);
    }
    foreach($in_sn_arr as $k=>$sn){
      if($k){
        $title.=" , ".$this->get_kind_title_from_sn($sn);
      }else{
        $title.=$this->get_kind_title_from_sn($sn);
      }
    }
    return $title;
  }



  ################################################################################
  #   檢查是否有子類別
  #   1. 有 ->  true
  #   2. 無 ->  false
  ################################################################################
  function check_sub_kind($sn=""){
    global $xoopsDB;
    if(empty($sn)) return false;
    $sql = "select count(*) from ".$xoopsDB->prefix($this->tbl)."
            where `ofsn`='{$sn}'";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($count)=$xoopsDB->fetchRow($result);
    if($count)return true;
    return false;
  }

}
<?php
/*
version 1.0
date 2015-09-22
use
 */
#---------------------------------
defined('XOOPS_ROOT_PATH') || die("XOOPS root path not defined");
class ugmKind_form
{
  protected $tbl;//資料表
  protected $kind;//類別
  protected $stop_level;//層數

  function __construct($tbl="",$kind="",$stop_level=1){
    global $xoopsDB;
    $this->set_tbl($tbl);
    $this->set_kind($kind);
    $this->set_stop_level($stop_level);
  }

  #--------- 設定類 --------------------
  #設定資料表
  public function set_tbl($value=""){
    $this->tbl = $value;
  }
  #設定類別
  public function set_kind($value=""){
    $this->kind = $value;
  }
  #設定層數
  public function set_stop_level($value=1){
    $this->stop_level = $value;
  }
  #--------- 取得類 --------------------
  #取得分類的類別
  public function get_kind(){
    return $this->kind;
  }
  public function get_tbl(){
    return $this->tbl;  }

  public function get_stop_level(){
    return $this->stop_level;
  }
  ################################################################
  #  取得類別body的資料
  ################################################################
  public function get_admin_list_body($ofsn=0,$level=1){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return;
    $down_level=$level + 1;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------
    $sub="";$i=0;$list="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort
      /*
      foreach($all as $k=>$v){
        $$k=$v;
      }
      */
      $icon['folder_i']        =$this->stop_level>$level?true:false;
      $icon['move_i']          =$level != 1       ?true:false;
      $icon['add_down_level_i']=$this->stop_level>$level?true:false;
      $icon['sort_i']=true;

      $sub=$this->get_admin_list_body($all['sn'],$down_level);
      #資料欄位有增減
      /*
      $list[]=array('sn' => $sn, 'ofsn' => $ofsn, 'title' => $title, 'enable' => $enable,'icon' => $icon,"target"=>$target,"url"=>$url,'sub'=>$sub);
      */
      //print_r($all);die();
      $list[$i]=$all;
      $list[$i]['icon']=$icon;
      $list[$i]['sub']=$sub;
      $i++;
    }
    return $list;
  }

  ################################################################
  #  還原陣列
  ################################################################
  public function reduction_admin_list_body($list_all){
    if(!$list_all)return;
    $body="";
    foreach($list_all as $list){
      #資料夾圖示
      $folder_i=$list['icon']['folder_i']?"<span class='folder'></span>":"";
      #移動圖示
      $move_i=$list['icon']['move_i']?"
        <img src='".XOOPS_URL."/modules/tadtools/treeTable/images/move_s.png' class='folder ui-draggable ui-draggable-handle' alt='用來搬移此分類到其他分類之下，請拖曳之，到目的地分類。' title='用來搬移此分類到其他分類之下，請拖曳之，到目的地分類。'>
      ":"";
      #排序圖示
      $sort_i=$list['icon']['sort_i']?"
        <img src='".XOOPS_URL."/modules/tadtools/treeTable/images/updown_s.png' style='cursor: s-resize;' alt='"._TAD_SORTABLE."' title='"._TAD_SORTABLE."'>
      ":"";
      #新增下層圖示
      $add_down_level_i=$list['icon']['add_down_level_i']?"
        <a href='?op=op_form&ofsn={$list['sn']}&kind={$list['kind']}'>
          <img src='".XOOPS_URL."/modules/ugm_tools/images/add.gif'  alt='IN ({$list['title']})"._MD_UGMMOUDEL_KIND_CREATE_SUB."' title='IN ({$list['title']})"._MD_UGMMOUDEL_KIND_CREATE_SUB."'>
        </a>
      ":"";
      #啟用圖示
      $enable_i=$list['enable']?
        "<a href='?op=op_update_enable&sn={$list['sn']}&enable=0&kind={$list['kind']}' title='"._MD_UGMMOUDEL_KIND_ENABLE_0."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_0."'><img src='".XOOPS_URL."/modules/ugm_tools/images/on.png' /></a>":
        "<a href='?op=op_update_enable&sn={$list['sn']}&enable=1&kind={$list['kind']}' title='"._MD_UGMMOUDEL_KIND_ENABLE_1."' atl='"._MD_UGMMOUDEL_KIND_ENABLE_1."'><img src='".XOOPS_URL."/modules/ugm_tools/images/off.png' /></a>";
      #編輯按鈕
      $edit_button="<a href='?op=op_form&sn={$list['sn']}&kind={$list['kind']}' class='btn btn-success'>"._EDIT."</a>";
      #刪除接鈕
      $del_button="<a href=\"javascript:op_delete_js({$list['sn']});\" class='btn btn-danger'>"._DELETE."</a>";

      $body.="
        <tr id='tr_{$list['sn']}' data-tt-id='{$list['sn']}' data-tt-parent-id={$list['ofsn']} >
          <td class='text-left'>

            {$folder_i}{$move_i}{$sort_i}
            <input type='text' name='title[{$list['sn']}]' value='{$list['title']}' id='title_{$list['sn']}' class='validate[required]' style='width:60%;'>
            {$add_down_level_i}
          </td>
          <td class='text-center'>
            {$enable_i}
          </td>
          <td class='text-center'>
            {$edit_button} {$del_button}
          </td>
        </tr>
      ";
      if($list['sub']){
        $body.=$this->reduction_admin_list_body($list['sub']);
      }
    }
    return $body;
  }

  ###########################################################
  #  確認底下有幾層
  ###########################################################
  function get_kind_level_down($sn_in,$level=1,$get_level=1){
    global $xoopsDB;
    if($level>$this->stop_level)return $level;
    $level++;
    $sql = "select sn
            from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$sn_in}'";//if($level==3) return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $get_level_tmp=$this->get_kind_level_down($sn,$level,$level);
       $get_level=$get_level_tmp > $get_level?$get_level_tmp:$get_level;
    }
    return $get_level;
  }

  ###########################################################
  #  取得所在之層數
  ###########################################################
  public function get_kind_level($sn,$level=1){
    global $xoopsDB;
    #假如超過停止層數
    if($level>$this->stop_level)return $level;

    $sql = "select ofsn
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$sn}'";// return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($ofsn)=$xoopsDB->fetchRow($result);
    if(!$ofsn)return $level;
    return $this->get_kind_level($ofsn,++$level);
  }

  ###############################################################################
  #  移動類別儲存
  ###############################################################################
  public function op_save_drag(){
    global $xoopsDB;
    $tbl=$this->get_tbl();
    $kind=$this->get_kind();
    $stop_level=$this->get_stop_level();

    $ofsn=intval($_POST['ofsn']);//目的
    $sn=intval($_POST['sn']);//來源


    if(!$sn){
      #根目錄不可移動
      die(_MD_UGMMOUDEL_KIND_ROOT_ERROR."(".date("Y-m-d H:i:s").")"._BP_F5);
    }elseif($ofsn==$sn){
      #自己移至自己
      die(_MA_TREETABLE_MOVE_ERROR1."(".date("Y-m-d H:i:s").")"._BP_F5);
    }elseif($this->get_kind_level($ofsn) + $this->get_kind_level_down($sn) > $stop_level){
      #自己往底層移動或自己底下層數+目的所在層數 > 類別層數
      die(_MD_UGMMOUDEL_KIND_LEVEL_ERROR."(".date("Y-m-d H:i:s").")"._BP_F5);
    }

    $sql="update ".$xoopsDB->prefix($tbl)."
          set `ofsn`='{$ofsn}' where `sn`='{$sn}'";
    $xoopsDB->queryF($sql) or die("Reset Fail! (".date("Y-m-d H:i:s").")");

    #排序全部重整
    $this->set_sort_reset();

    return "Reset OK! (".date("Y-m-d H:i:s").")"._BP_F5;
  }

  ###########################################################
  #  排序全部重整
  ###########################################################
  public function set_sort_reset($ofsn=0,$level=1,$sort=1){
    global $xoopsDB;
    $tbl=$this->get_tbl();
    $kind=$this->get_kind();
    $stop_level=$this->get_stop_level();

    if($level>$stop_level)return $sort;
    $down_level=$level + 1;

    $sql = "select `sn`,`ofsn` from ".$xoopsDB->prefix($tbl)."
            where ofsn='{$ofsn}' and kind='{$kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    #--------------------------------------------------------------------

    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $sql_1 = "update ".$xoopsDB->prefix($tbl)." set
        `sort`   = '{$sort}'
        where sn='{$sn}'";
      $xoopsDB->queryF($sql_1) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
      $sort=$this->set_sort_reset($sn,$down_level,++$sort);
    }
    return $sort;
  }
  ###############################################################################
  #  得到外鍵表單
  ###############################################################################
  public function get_foreign_key_option($foreign_key=array())
  {
    $kind_option="";
    foreach($foreign_key as $key=>$value){
      $selected="";
      if($this->get_kind() == $key){
        $selected=" selected";
      }
      $kind_option.="<option value='{$key}'{$selected}>{$value['title']}</option>";
    }
    return $kind_option;
  }

  ###########################################################
  #  新增、編輯資料
  ###########################################################
  public function op_insert(){
    global $xoopsDB;
    #XOOPS表單安全檢查
    if(!$GLOBALS['xoopsSecurity']->check())
    {
      $error=implode("<br />", $GLOBALS['xoopsSecurity']->getErrors());
      redirect_header($_SERVER['PHP_SELF'], 3, $error);
    }
    #---------------------
    //---- 過濾資料 -----------------------------------------*/
    $myts =& MyTextSanitizer::getInstance();
    #類別名稱
    $_POST['title']=$myts->addSlashes($_POST['title']);
    if(empty($_POST['title']))return false;
    #類別
    $_POST['kind']=$myts->addSlashes($_POST['kind']);
    #排序
    //$_POST['sort']  =get_ugm_module_max_sort("sort",$tbl);
    #狀態
    $_POST['enable']=intval($_POST['enable']);
    #sn
    $_POST['sn']    =intval($_POST['sn']);
    #ofsn
    $_POST['ofsn']  =intval($_POST['ofsn']);
    //-------------------------------------------------------*/
    if($_POST['sn']){
      #編輯
      #--------檢查---------------------------
      $sql = "select * from ".$xoopsDB->prefix($this->get_tbl())." where sn='{$_POST['sn']}'";
      $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
      $DBV=$xoopsDB->fetchArray($result);
      if($_POST['ofsn']!=$DBV['ofsn']){
        #類別有變動
        if($_POST['sn']==$_POST['ofsn']){
          return _MA_TREETABLE_MOVE_ERROR1;
        }elseif( ($this->get_kind_level($_POST['ofsn']) + $this->get_kind_level_down($_POST['sn'])) > $this->get_stop_level()){
          //#自己往底層移動或自己底下層數+目的所在層數 > 類別層數
          return _MD_UGMMOUDEL_KIND_LEVEL_ERROR;
        }
      }
      #--------檢查結束---------------------------
      #
      $sql = "update ".$xoopsDB->prefix($this->get_tbl())." set
        `ofsn`   = '{$_POST['ofsn']}' ,
        `title`  = '{$_POST['title']}' ,
        `enable` = '{$_POST['enable']}'
        where sn='{$_POST['sn']}'";
      $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    }else{
      #---------新增------------------------
      #---------取得排序--------------------
      $sql="select max(sort)as max_sort
            from ".$xoopsDB->prefix($this->get_tbl())."
            where ofsn='{$_POST['ofsn']}' and kind='{$_POST['kind']}'";
      $sort=get_ugm_module_sql($sql);
      $sort['max_sort']++;
      #---------寫入-------------------------
      $sql = "insert into ".$xoopsDB->prefix($this->get_tbl())."
      (`ofsn` ,`title` , `enable` , `sort`,`kind`)
      values('{$_POST['ofsn']}' , '{$_POST['title']}' ,'{$_POST['enable']}' , '{$sort['max_sort']}' , '{$_POST['kind']}')";//die($sql);
      $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
      //取得最後新增資料的流水編號
      $_POST['sn'] = $xoopsDB->getInsertId();
    }
    #排序全部重整
    $this->set_sort_reset();
    return _BP_SUCCESS;
  }
  ###########################################################
  #  批次編輯資料
  ###########################################################
  public function op_all_insert(){
    global $xoopsDB;
    $tbl=$this->get_tbl();
    //$kind=$ugmKind_form->get_kind();
    //---- 過濾資料 -----------------------------------------*/
    $myts =& MyTextSanitizer::getInstance();
    foreach($_POST['title'] as $sn=>$title){
      $title=$myts->addSlashes($title);
      $sn=intval($sn);#編輯
      $sql = "update ".$xoopsDB->prefix($tbl)." set
             `title` = '{$title}'
             where sn='{$sn}'";
      $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    }
    //#排序全部重整
    //set_sort_reset($kind);
    return _BP_SUCCESS;
  }
  ###############################################################################
  #  刪除資料
  ###############################################################################
  public function op_delete($sn=""){
    global $xoopsDB;
    if(empty($sn)) return _BP_DEL_ERROR;

    #檢查是否有子類別
    if ($this->check_sub_kind($sn)) return _MD_UGMMOUDEL_KIND_HAVE_SUB_NOT_DEL;
    $sql = "delete from ".$xoopsDB->prefix($this->get_tbl())."
            where sn='{$sn}'";//die($sql);
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF']."?kind=".$this->get_kind(),3, mysql_error());

    #排序全部重整
    $this->set_sort_reset();
    return _BP_DEL_SUCCESS;
  }

  ################################################################################
  #   檢查是否有子類別
  #   1. 有 ->  true
  #   2. 無 ->  false
  ################################################################################
  function check_sub_kind($sn=""){
    global $xoopsDB;
    if(empty($sn)) return false;
    $sql = "select count(*) from ".$xoopsDB->prefix($this->get_tbl())."
            where `ofsn`='{$sn}'";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($count)=$xoopsDB->fetchRow($result);
    if($count)return true;
    return false;
  }


  ###############################################################################
  #  更新啟用
  ###############################################################################
  public function op_update_enable(){
    global $xoopsDB;
    #權限
    /***************************** 過瀘資料 *************************/
    $enable=intval($_GET['enable']);
    $sn=intval($_GET['sn']);
    /****************************************************************/
    if($sn){
      //更新
      $sql = "update ".$xoopsDB->prefix($this->get_tbl())." set  `enable` = '{$enable}' where `sn`='{$sn}'";
      $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
      return _BP_SUCCESS;
    }
    return _BP_DATA_ERROR;
  }

  ###############################################################################
  #  自動更新排序
  ###############################################################################
  public function op_update_sort(){
    global $xoopsDB;
    $sort=1;
    foreach ($_POST['tr'] as $sn) {
      if(!$sn)continue;
      $sql="update ".$xoopsDB->prefix($this->get_tbl())." set `sort`='{$sort}' where `sn`='{$sn}'";
      $xoopsDB->queryF($sql) or die("Save Sort Fail! (".date("Y-m-d H:i:s").")");
      $sort++;
    }
    return "Save Sort OK! (".date("Y-m-d H:i:s").")"._BP_F5;
  }

  /* 前台使用 */

  ###############################################################################
  #  取得使用者類別選項(每層都可選)
  #  enable=1
  ###############################################################################
  public function get_main_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;

    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and enable='1' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       $main.=$this->get_main_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
    }
    return $main;
  }


  /*




  #######################################################
  #  取得父類別選單->選項(後台類別表單用)# op_form
  #######################################################
  public function get_admin_form_ofsn_option($ofsn_check,$ofsn=0,$level=1,$indent=""){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level >= $this->stop_level)return;
    $down_level=$level+1;
    $indent.="&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}'
            order by sort";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($ofsn_check==$sn)?" selected":"";
       $main.="<option value='{$sn}'{$selected}>{$indent}{$title}</option>";
       $main.=$this->get_admin_form_ofsn_option($ofsn_check,$sn,$down_level,$indent);
    }
    return $main;
  }



  #----後台----
  #以流水號取得某筆分類資料
  public function get_one_table_4_sn($sn=""){
    global $xoopsDB;
    if(empty($sn))return;
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)." where sn='{$sn}'";//die($sql);
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $data=$xoopsDB->fetchArray($result);
    return $data;
  }

  #取得管理者類別選項(stop_level那層可選)
  #enable=0 可選
  public function get_admin_list_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_admin_list_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }





  #前台

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_list_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and enable='1' {$and_kind}
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_use_list_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }




  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_array($in_sn="",$ofsn=0 ,$level=1){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level > $this->stop_level)return;
    $down_level=$level++;

    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}'  and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    $main="";
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $active=($in_sn==$sn)?1:0;
      $sub="";
      $sub=$this->get_use_kind_array($in_sn,$sn,$down_level);
      $main[]=array("sn"=>$sn,"title"=>$title,"active"=>$active,"sub"=>$sub);
    }
    return $main;
  }
  #
  #取得使用者類別第1個選項
  public function get_use_first_kind(){
    global $xoopsDB;
    #層數預設值
    $sql = "select sn from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='0' and kind='{$this->kind}' and enable='1'
            limit 1
            ";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($sn)=$xoopsDB->fetchRow($result);
    return $sn;
  }
  #-------------------------------------

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_option1($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $disabled=($level != $stop_level)?" disabled":"";
       $selected=($in_sn==$sn)?" selected":"";
       $main.="<option value='{$sn}'{$selected}{$disabled}>{$indent}{$title}</option>";
       $main.=$this->get_use_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
    }
    return $main;
  }
  #-------------------------------------

  #取得使用者類別選項(stop_level那層可選)
  public function get_use_kind_option($in_sn,$ofsn=0,$stop_level=0 ,$level=1,$indent=""){
    global $xoopsDB;
    #層數預設值
    $stop_level=$stop_level?$stop_level:$this->stop_level;
    if($level > $stop_level)return;
    $down_level=$level+1;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $down_indent=$indent."&nbsp;&nbsp;&nbsp;&nbsp;";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' {$and_kind} and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       if($level != $stop_level){
         $main.="<optgroup label='{$indent}{$title}'>\n";
         $main.=$this->get_use_kind_option($in_sn,$sn,$stop_level,$down_level,$down_indent);
         $main.="</optgroup>\n";
       }else{
         $main.="<option value='{$sn}' {$selected}>{$indent}{$title}</option>";
       }
    }
    return $main;
  }
  #-------------------------------------
  #取得使用者類別選項(value = title)一定只有一層
  public function get_use_kind_option_value_title($in_sn){
    global $xoopsDB;
    $and_kind=$this->kind?" and kind='{$this->kind}'":"";
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='0' {$and_kind} and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $selected=($in_sn==$sn)?" selected":"";
       $main.="<option value='{$title}' {$selected}>{$title}</option>";
    }
    return $main;
  }
  #-------------------------------------

  #取得使用者類別導航路徑
  public function get_user_kind_dir($in_sn){
    global $xoopsDB;
    #層數預設值
    $sql = "select *
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$in_sn}'";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $list="";
    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
       $parent="";
       if($all['ofsn']){
         $parent=$this->get_user_kind_dir($all['ofsn']);
       }
       $list[]=array("sn"=>$all['sn'],"ofsn"=>$all['ofsn'],"title"=>$all['title'],"parent"=>$parent);
    }
    return $list;
  }
  #-------------------------------------

  #取得使用者類別複選選項
  public function get_use_kind_checkbox_option($in_sn,$ofsn=0,$level=1){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    #將傳入值轉成陣列
    if($in_sn){
      $in_sn_arr=explode(",",$in_sn);
    }
    #層數預設值
    if($level > $this->stop_level)return;
    $down_level=$level+1;
    $sql = "select * from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$ofsn}' and kind='{$this->kind}' and enable='1'
            order by sort";//die($sql) ;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $main="";
    $i=0;
    while($all=$xoopsDB->fetchArray($result)){
      //以下會產生這些變數： $sn , $ofsn , $title , $enable  ,$sort,$kind
      foreach($all as $k=>$v){
        $$k=$v;
      }
      $checked=(in_array($sn,$in_sn_arr))?" checked":"";
      $main.="
        <label style='display:block;margin-left:70px;'>
          <input type='checkbox' name='{$this->kind}[]' id='{$this->kind}_{$sn}' value='{$sn}' {$checked}> {$title}
        </label>
        ";
       $main.=$this->get_use_kind_checkbox_option($in_sn,$sn,$down_level);
       $i++;
    }
    return $main;
  }
  #-------------------------------------

  #以流水號取得標題
  public function get_kind_title_from_sn($sn){
    global $xoopsDB;
    $title="";
    $sql="select title
          from ".$xoopsDB->prefix($this->tbl)."
          where sn='{$sn}'
          ";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($title)=$xoopsDB->fetchRow($result);
    return $title;
  }
  #-------------------------------------
  #取得類別複選選項(sn)陣列 轉 (title)陣列
  public function get_use_kind_sn2title($in_sn){
    global $xoopsDB;
    $title="";
    #將傳入值轉成陣列
    if($in_sn){
      $in_sn_arr=explode(",",$in_sn);
    }
    foreach($in_sn_arr as $k=>$sn){
      if($k){
        $title.=" , ".$this->get_kind_title_from_sn($sn);
      }else{
        $title.=$this->get_kind_title_from_sn($sn);
      }
    }
    return $title;
  }



  #檢查類-----------------------------------
  #確認底下有幾層
  #chk_kind_level_down
  public function chk_kind_level_down($sn_in,$level=1,$get_level=1){
    global $xoopsDB;

    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");

    if($level>$this->stop_level)return $level;
    $level++;
    $sql = "select sn
            from ".$xoopsDB->prefix($this->tbl)."
            where ofsn='{$sn_in}'";// return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

    while($all=$xoopsDB->fetchArray($result)){
       //以下會產生這些變數： $sn
       foreach($all as $k=>$v){
         $$k=$v;
       }
       $get_level_tmp=$this->chk_kind_level_down($sn,$level,$level);
       $get_level=($get_level_tmp > $get_level)?$get_level_tmp:$get_level;
    }
    return $get_level;
  }
  ###########################################################
  #  確認所在層數
  ###########################################################
  public function chk_kind_level($sn,$level=1){
    global $xoopsDB;
    if(!$this->tbl or !$this->kind or !$this->stop_level)redirect_header(XOOPS_URL,3, "TABLE ERROR！！");
    if($level>$this->stop_level)return $level;
    $sql = "select ofsn
            from ".$xoopsDB->prefix($this->tbl)."
            where sn='{$sn}'";// return $sql;
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    list($ofsn)=$xoopsDB->fetchRow($result);
    if(!$ofsn)return $level;
    return $this->chk_kind_level($ofsn,++$level);
  }

  */
}
?>
<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/

include_once XOOPS_ROOT_PATH . '/modules/tadtools/language/' . $xoopsConfig['language'] . '/modinfo_common.php';

define('_MI_UGMCREATIVE_NAME','佈景管理');
define('_MI_UGMCREATIVE_AUTHOR','育將電腦工作室');
define('_MI_UGMCREATIVE_LICENSE','育將電腦工作室');
define('_MI_UGMCREATIVE_CREDITS','郭俊良');
define('_MI_UGMCREATIVE_DESC','佈景管理');
define('_MI_UGMCREATIVE_AUTHOR_WEB','育將電腦工作室');
define('_MI_UGMCREATIVE_ADMENU1', '選單管理');
define('_MI_UGMCREATIVE_ADMENU1_DESC', '選單管理');
define('_MI_UGMCREATIVE_ADMENU2', '輪播圖管理');
define('_MI_UGMCREATIVE_ADMENU2_DESC', '輪播圖管理');
define('_MI_UGMCREATIVE_ADMENU3', '變數管理');
define('_MI_UGMCREATIVE_ADMENU3_DESC', '變數管理');
define('_MI_UGMCREATIVE_ADMENU4', '圖示連結');
define('_MI_UGMCREATIVE_ADMENU4_DESC', '圖示連結');

//偏好設定


//INSTALL 預設值


//BLOCK

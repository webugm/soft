<?php
/*-----------引入檔案區--------------*/
$xoopsOption['template_main'] = 'ugm_creative_adm_icon_b3.html';
include_once "header.php";
include_once "../function.php";
#取得資料表
$tbl = "ugm_creative_nav";
#取得模組名稱
$DIRNAME = $xoopsModule->getVar('dirname');
/*-----------執行動作判斷區----------*/
#system_CleanVars (&$global, $key, $default= '', $type= 'int')
include_once $GLOBALS['xoops']->path('/modules/system/include/functions.php');
$op = system_CleanVars($_REQUEST, 'op', '', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');
$kind = system_CleanVars($_REQUEST, 'kind', 'icon', 'string');
 
#初始值
$kind_arr = array(
  "icon" => array("title" => "圖示連結", "stop_level" => 1, "description" => ""),
);
#---------------------------------
 
switch ($op) {
case "op_update_sort": //更新排序ajax
  echo op_update_sort();
  XoopsCache::clear();
  write_html();
  exit;
 
case "op_update_enable": //更新啟用
  op_update_enable();
  XoopsCache::clear();
  write_html();
  redirect_header($_SESSION['return_url'], 3, _BP_SUCCESS);
  break;
 
case "op_update_target": //更新外連狀態
  op_update_target();
  XoopsCache::clear();
  write_html();
  redirect_header($_SESSION['return_url'], 3, _BP_SUCCESS);
  break;
 
case "op_insert": //新增、更新資料表
  op_insert($sn);
  XoopsCache::clear();
  write_html();
  redirect_header($_SESSION['return_url'], 3, _BP_SUCCESS);
  exit;
  break;
 
case "op_all_insert": //更新列表所有資料
  op_all_insert();
  XoopsCache::clear();
  write_html();
  redirect_header($_SESSION['return_url'], 3, _BP_SUCCESS);
  break;
 
case "op_form": //新增、編輯表單
  op_form($sn);
  break;
 
//刪除資料
case "op_delete": //刪除
  op_delete($sn);
  XoopsCache::clear();
  write_html();
  redirect_header($_SESSION['return_url'], 3, _BP_DEL_SUCCESS);
  break;
 
//預設動作
default:
  # ---- 目前網址 ----
  $_SESSION['return_url'] = getCurrentUrl();
  $op = "op_list";
  op_list();
  break;
  /*---判斷動作請貼在上方---*/
}
 
/*-----------秀出結果區--------------*/
#CSS
$xoTheme->addStylesheet(XOOPS_URL . "/modules/ugm_tools/css/xoops_adm3.css");
$xoTheme->addStylesheet(XOOPS_URL . "/modules/ugm_tools/css/forms.css");
$xoTheme->addStylesheet(XOOPS_URL . "/modules/{$DIRNAME}/css/module_b3.css");
get_jquery(true);
$file_name = basename($_SERVER['PHP_SELF']);
$moduele_admin = new ModuleAdmin();
$xoopsTpl->assign("Navigation", $moduele_admin->addNavigation($file_name));
$xoopsTpl->assign("op", $op);
$xoopsTpl->assign("DIRNAME", $DIRNAME);
$xoopsTpl->assign("action", $file_name);
include_once 'footer.php';
/*-----------功能函數區--------------*/
###############################################################################
#  編輯表單
###############################################################################
function op_form($sn = "") {
  global $xoopsDB, $xoopsTpl, $DIRNAME, $tbl, $kind;
  //----------------------------------*/
  //抓取預設值
  if (!empty($sn)) {
    $DBV = get_ugm_module_tbl($sn, $tbl);
  } else {
    $DBV = array();
  }
  //預設值設定
  //設定「kind_sn」欄位預設值
  $DBV['sn'] = (!isset($DBV['sn'])) ? "" : $DBV['sn'];
 
  //設定「kind_ofsn」欄位預設值
  $DBV['ofsn'] = (!isset($DBV['ofsn'])) ? 0 : $DBV['ofsn'];
 
  //設定「title」欄位預設值
  $DBV['title'] = (!isset($DBV['title'])) ? "" : $DBV['title'];
 
  //設定「enable」欄位預設值
  $DBV['enable'] = (!isset($DBV['enable'])) ? "1" : $DBV['enable'];
 
  //kind
  $DBV['kind'] = (!isset($DBV['kind'])) ? $kind : $DBV['kind'];
 
  //設定「target」欄位預設值
  $DBV['target'] = (!isset($DBV['target'])) ? "0" : $DBV['target'];
 
  //設定「url」欄位預設值
  $DBV['url'] = (!isset($DBV['url'])) ? "" : $DBV['url'];
 
  //設定「col_sn」欄位預設值
  $DBV['col_sn'] = (!isset($DBV['col_sn'])) ? "" : $DBV['col_sn'] ? $DBV['col_sn'] : "";
 
  $content = json_decode($DBV['content'], true);//(PHP 5 >= 5.2.0 true=>array 
  $DBV['content'] = $content['content'];
  $DBV['icon'] = $content['icon'];
 
  $DBV['op'] = "op_insert";
 
  #--------------------------------------------------------------------
  //----- 驗證碼 -----------------*/
  if (!file_exists(XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php")) {
    redirect_header("index.php", 3, _TAD_NEED_TADTOOLS);
  }
  include_once XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php";
  $formValidator = new formValidator("#myForm", true);
  $formValidator->render();
  //-------------------------------*/
  $xoopsTpl->assign('DBV', $DBV);
}
 
###############################################################################
#  列表
#  $content = json_decode($row['content'], true);
#  $row['icon'] = $content['icon'];
#  $row['content'] = $content['content'];
###############################################################################
function op_list() {
  global $xoopsTpl, $kind_arr, $DIRNAME, $kind, $xoopsDB;
  //---- 過濾資料 -----------------------*/
  $myts = &MyTextSanitizer::getInstance();
 
  # ----得到外鍵選單之選項 ----------------------------
  $kind_option = $kind_description = "";
  foreach ($kind_arr as $key => $value) {
    $selected = "";
    if ($kind == $key) {
      $selected = " selected";
      $kind_description = $value['description'];
    }
    $kind_option .= "<option value='{$key}'{$selected}>{$value['title']}</option>";
  }
  $kind_form = "
      <select name='kind' id='kind' onchange=\"location.href='?kind='+this.value\"  class='form-control' style='width:300px;'>
        $kind_option
      </select>
  ";
  #----------------------------------------------
  $xoopsTpl->assign('kind_form', $kind_form);
  $xoopsTpl->assign('kind', $kind);
  $xoopsTpl->assign('kind_description', $kind_description);
 
  # ----得到陣列 ----------------------------
  $sql = "select *
        from " . $xoopsDB->prefix("ugm_creative_nav") . "
        where `kind`='{$kind}'
        order by sort"; //die($sql);
  $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
  $rows = array();
  while ($row = $xoopsDB->fetchArray($result)) {
    $row['sn'] = intval($row['sn']);
    $row['title'] = $myts->addSlashes($row['title']);
    $row['target'] = intval($row['target']);
    $content = json_decode($row['content'], true);
    $row['icon'] = $content['icon'];
    $row['content'] = "";
    $rows[] = $row;
  }
  $xoopsTpl->assign('rows', $rows);
 
  #---- 刪除javascript函數 ----
  if (!file_exists(XOOPS_ROOT_PATH . "/modules/tadtools/sweet_alert.php")) {
    redirect_header("index.php", 3, _MA_NEED_TADTOOLS);
  }
  include_once XOOPS_ROOT_PATH . "/modules/tadtools/sweet_alert.php";
  $sweet_alert_obj = new sweet_alert();
  $sweet_alert_obj->render('op_delete_js', "?op=op_delete&kind={$kind}&sn=", "sn");
 
  #-----驗證碼---------------------------------------------------------
  if (!file_exists(XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php")) {
    redirect_header("index.php", 3, _TAD_NEED_TADTOOLS);
  }
  include_once XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php";
  $formValidator = new formValidator("#myForm", true);
  $formValidator->render();
   
}
 
###########################################################
#  新增、編輯資料
#  $content = json_encode($content, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);
###########################################################
function op_insert() {
  global $xoopsDB, $tbl, $DIRNAME;
  //---- 過濾資料 -----------------------------------------*/
  $myts = &MyTextSanitizer::getInstance();
  #輪播標題
  $_POST['title'] = $myts->addSlashes($_POST['title']);
  if (empty($_POST['title'])) {
    return false;
  }
 
  #摘要與圖示存成json
  $content['content'] = $myts->addSlashes($_POST['content']);
  $content['icon'] = $myts->addSlashes($_POST['icon']);
  $_POST['content'] = json_encode($content, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);
 
  #網址
  $_POST['url'] = $myts->addSlashes($_POST['url']);
  #類別
  $_POST['kind'] = $myts->addSlashes($_POST['kind']);
  #狀態
  $_POST['enable'] = intval($_POST['enable']);
  #連結狀態
  $_POST['target'] = intval($_POST['target']);
  #sn
  $_POST['sn'] = intval($_POST['sn']);
  #ofsn
  $_POST['ofsn'] = intval($_POST['ofsn']);
  //-------------------------------------------------------*/
  if ($_POST['sn']) {
    #編輯
    $sql = "update " . $xoopsDB->prefix($tbl) . " set
        `ofsn`   = '{$_POST['ofsn']}' ,
        `title`  = '{$_POST['title']}' ,
        `content`  = '{$_POST['content']}' ,
        `enable` = '{$_POST['enable']}',
        `target` = '{$_POST['target']}',
        `url` = '{$_POST['url']}'
        where sn='{$_POST['sn']}'";
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
  } else {
    #---------新增------------------------
    #---------取得排序--------------------
    $sql = "select max(sort)as max_sort
              from " . $xoopsDB->prefix($tbl) . "
              where ofsn='{$_POST['ofsn']}' and kind='{$_POST['kind']}'";
    $sort = get_ugm_module_sql($sql);
    $sort['max_sort']++;
    #---------寫入-------------------------
    $sql = "insert into " . $xoopsDB->prefix($tbl) . "
          (`ofsn` ,`title` ,`content`, `enable` , `sort`,`kind`,`target`,`url`)
          values('{$_POST['ofsn']}' , '{$_POST['title']}', '{$_POST['content']}' ,'{$_POST['enable']}' , '{$sort['max_sort']}' , '{$_POST['kind']}', '{$_POST['target']}', '{$_POST['url']}')";
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
    //取得最後新增資料的流水編號
    $_POST['sn'] = $xoopsDB->getInsertId();
  }
 
  return $_POST['sn'];
}
 
###############################################################################
#  更新啟用
###############################################################################
function op_update_enable() {
  global $xoopsDB, $tbl;
  #權限
  /***************************** 過瀘資料 *************************/
  $enable = intval($_GET['enable']);
  $sn = intval($_GET['sn']);
  /****************************************************************/
  //更新
  $sql = "update
       " . $xoopsDB->prefix($tbl) . "
       set  `enable` = '{$enable}'
       where `sn`='{$sn}'";
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
  return;
}
 
###############################################################################
#  更新外連
###############################################################################
function op_update_target() {
  global $xoopsDB, $tbl;
  #權限
  /***************************** 過瀘資料 *************************/
  $target = intval($_GET['target']);
  $sn = intval($_GET['sn']);
  /****************************************************************/
  //更新
  $sql = "update
      " . $xoopsDB->prefix($tbl) . "
      set `target` = '{$target}'
      where `sn`='{$sn}'";
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
  return;
}
 
###########################################################
#  批次編輯資料
###########################################################
function op_all_insert() {
  global $xoopsDB, $tbl;
  //---- 過濾資料 -----------------------------------------*/
  $myts = &MyTextSanitizer::getInstance();
  foreach ($_POST['title'] as $sn => $title) {
    $title = $myts->addSlashes($title);
    $sn = intval($sn); #編輯
    $url = $myts->addSlashes($_POST['url'][$sn]);
    $sql = "update
         " . $xoopsDB->prefix($tbl) . " set
             `title` = '{$title}',
             `url` = '{$url}'
             where sn='{$sn}'";
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
  }
}
###############################################################################
#  刪除資料
###############################################################################
function op_delete($sn = "") {
  global $xoopsDB, $tbl, $DIRNAME;
 
  if (empty($sn)) {
    redirect_header($_SERVER['PHP_SELF'], 3, _BP_DEL_ERROR);
  }
 
  #取得資料
  $sql = "delete from " . $xoopsDB->prefix($tbl) . "
            where sn='{$sn}'"; //die($sql);
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
}
###############################################################################
#  自動更新排序
###############################################################################
function op_update_sort() {
  global $xoopsDB, $tbl;
  $sort = 1;
  foreach ($_POST['tr'] as $sn) {
    if (!$sn) {
      continue;
    }
    $sql = "update
         " . $xoopsDB->prefix($tbl) . "
         set `sort`='{$sort}'
         where `sn`='{$sn}'";
    $xoopsDB->queryF($sql) or die("Save Sort Fail! (" . date("Y-m-d H:i:s") . ")");
    $sort++;
  }
  return "Save Sort OK! (" . date("Y-m-d H:i:s") . ")" . _BP_F5;
}
 
###############################################################################
#  產生 write_html
###############################################################################
function write_html() {
  global $tbl, $xoopsDB, $DIRNAME, $kind;
  //---- 過濾資料 ----------------------*/
  $myts = &MyTextSanitizer::getInstance();
 
  $sql = "select *
            from      " . $xoopsDB->prefix($tbl) . "
            where kind='{$kind}' and enable='1'
            order by sort"; //die($sql);
  $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
  $item = "";
  $i = 0;
  while ($row = $xoopsDB->fetchArray($result)) {
 
    $row['target'] = $row['target'] ? " target='_blank'" : "";
    $row['title'] = $myts->htmlSpecialChars($row['title']);
    $row['url'] = $myts->htmlSpecialChars($row['url']);
    $content = json_decode($row['content'], true);
    $row['icon'] = $myts->htmlSpecialChars($content['icon']);
    $html = 0;
    $br = 1;
    $row['content'] = $myts->displayTarea($content['content'], $html, 1, 0, 1, $br);
    //print_r($row);die();
 
    $item .= "          <div class='col-lg-3 col-md-6 text-center'>\n";
    $item .= "          <a href='{$row['url']}'{$row['target']}>\n";
 
    $item .= "            <div class='service-box'>\n";
    $item .= "              <i class='fa fa-4x {$row['icon']} text-primary sr-icons'></i>\n";
    $item .= "              <h3>{$row['title']}</h3>\n";
    $item .= "              <p class='text-muted'>{$row['content']}</p>\n";
    $item .= "            </div>\n";
    $item .= "          </a>\n";
    $item .= "          </div>\n";
  }
 
  $content = "";
  $content = "<section id='services'>\n";
  $content .= " <div class='container'>\n";
  $content .= "   <div class='row'>\n";
  $content .= "     <div class='col-lg-12 text-center'>\n";
  $content .= "       <h2 class='section-heading'>最新消息</h2>\n";
  $content .= "       <hr class='primary'>\n";
  $content .= "     </div>\n";
  $content .= "   </div>\n";
  $content .= " </div>\n";
  $content .= " <div class='container'>\n";
  $content .= "   <div class='row'>\n";
  $content .= $item;
  $content .= "   </div>\n";
  $content .= " </div>\n";
  $content .= "</section>\n";
 
  #---- 檢查資料夾
  mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/tpl");
  $file = XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/tpl/creative_services.html";
  $f = fopen($file, 'w'); //以寫入方式開啟文件
  fwrite($f, $content); //將新的資料寫入到原始的文件中
  fclose($f);
}
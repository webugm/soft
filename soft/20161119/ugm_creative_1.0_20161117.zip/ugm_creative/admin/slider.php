<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/

/*-----------引入檔案區--------------*/
$xoopsOption['template_main'] = 'ugm_creative_adm_slider_b3.html';
include_once "header.php";
include_once "../function.php";
#引入上傳物件
include_once XOOPS_ROOT_PATH . "/modules/ugm_tools/ugmUpFiles.php";
#取得kind資料庫
$tbl = "ugm_creative_nav";
#取得模組名稱
$DIRNAME = $xoopsModule->getVar('dirname');
#引入類別物件---------------------------------
include_once XOOPS_ROOT_PATH . "/modules/ugm_tools/ugmKind.php";
/*-----------執行動作判斷區----------*/
#system_CleanVars (&$global, $key, $default= '', $type= 'int')
include_once $GLOBALS['xoops']->path('/modules/system/include/functions.php');
$op = system_CleanVars($_REQUEST, 'op', '', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');
$kind = system_CleanVars($_REQUEST, 'kind', 'photo', 'string');

#初始值
$kind_arr = array(
	"photo" => array("title" => "相片展示", "stop_level" => 1, "description" => "圖片大小：650 x 350"),
);
#stop_level
$stop_level = 1;
$ugmKind = new ugmKind($tbl, $kind, $stop_level);
#---------------------------------

switch ($op) {
case "op_update_sort": //更新排序
	echo op_update_sort();
	XoopsCache::clear();
	write_Slider_html();
	exit;

case "op_save_drag": //移動類別儲存
	echo op_save_drag();
	XoopsCache::clear();
	write_Slider_html();
	exit;
//更新狀態
case "op_update_enable":
	op_update_enable();
	XoopsCache::clear();
	write_Slider_html();
	redirect_header($_SERVER['PHP_SELF'] . "?kind={$kind}", 3, _BP_SUCCESS);
	break;

//更新外連狀態
case "op_update_target":
	op_update_target();
	XoopsCache::clear();
	write_Slider_html();
	redirect_header($_SERVER['PHP_SELF'] . "?kind={$kind}", 3, _BP_SUCCESS);
	break;

//新增資料
case "op_insert":
	op_insert($sn);
	XoopsCache::clear();
	write_Slider_html();
	redirect_header($_SERVER['PHP_SELF'] . "?kind={$kind}", 3, _BP_SUCCESS);
	break;

//新增資料
case "op_all_insert":
	op_all_insert();
	XoopsCache::clear();
	write_Slider_html();
	redirect_header($_SERVER['PHP_SELF'] . "?kind={$kind}", 3, _BP_SUCCESS);
	break;
//輸入表格
case "op_form":
	op_form($sn);
	break;

//刪除資料
case "op_delete":
	op_delete($sn);
	XoopsCache::clear();
	write_Slider_html();
	redirect_header($_SERVER['PHP_SELF'] . "?kind={$kind}", 3, _BP_DEL_SUCCESS);
	break;

//預設動作
default:
	$op = "op_list";
	op_list();
	break;
	/*---判斷動作請貼在上方---*/
}

/*-----------秀出結果區--------------*/
#CSS
$xoTheme->addStylesheet(XOOPS_URL . "/modules/ugm_tools/css/xoops_adm3.css");
$xoTheme->addStylesheet(XOOPS_URL . "/modules/ugm_tools/css/forms.css");
$xoTheme->addStylesheet(XOOPS_URL . "/modules/{$DIRNAME}/css/module_b3.css");
get_jquery(true);
//$xoopsTpl->assign("isAdmin" , true);
$file_name = basename($_SERVER['PHP_SELF']);
$moduele_admin = new ModuleAdmin();
$xoopsTpl->assign("Navigation", $moduele_admin->addNavigation($file_name));
$xoopsTpl->assign("op", $op);
$xoopsTpl->assign("DIRNAME", $DIRNAME);
$xoopsTpl->assign("action", $file_name);
include_once 'footer.php';
/*-----------功能函數區--------------*/
#取得stop_level
function get_stop_level($kind, $kind_arr) {
	foreach ($kind_arr as $key => $value) {
		if ($kind == $key) {
			return $value['stop_level'];
		}
	}
}

###############################################################################
#  編輯表單
###############################################################################
function op_form($sn = "") {
	global $xoopsDB, $xoopsTpl, $ugmKind, $DIRNAME;
	//----------------------------------*/
	$_GET['ofsn'] = !isset($_GET['ofsn']) ? 0 : intval($_GET['ofsn']);
	//抓取預設值
	if (!empty($sn)) {
		$DBV = $ugmKind->get_one_table_4_sn($sn); //get_ugm_module_tbl($sn,$ugmKind->get_tbl());//
	} else {
		$DBV = array();
	}
	//預設值設定
	//設定「kind_sn」欄位預設值
	$DBV['sn'] = (!isset($DBV['sn'])) ? "" : $DBV['sn'];

	//設定「kind_ofsn」欄位預設值
	$DBV['ofsn'] = (!isset($DBV['ofsn'])) ? $_GET['ofsn'] : $DBV['ofsn'];
	$DBV['ofsn_option'] = $ugmKind->get_admin_form_ofsn_option($DBV['ofsn']);

	//設定「title」欄位預設值
	$DBV['title'] = (!isset($DBV['title'])) ? "" : $DBV['title'];

	//設定「content」欄位預設值
	$DBV['content'] = (!isset($DBV['content'])) ? "" : $DBV['content'];

	//設定「enable」欄位預設值
	$DBV['enable'] = (!isset($DBV['enable'])) ? "1" : $DBV['enable'];

	//kind
	$DBV['kind'] = (!isset($DBV['kind'])) ? $ugmKind->get_kind() : $DBV['kind'];

	//設定「target」欄位預設值
	$DBV['target'] = (!isset($DBV['target'])) ? "0" : $DBV['target'];

	//設定「url」欄位預設值
	$DBV['url'] = (!isset($DBV['url'])) ? "" : $DBV['url'];

	//設定「col_sn」欄位預設值
	$DBV['col_sn'] = (!isset($DBV['col_sn'])) ? "" : $DBV['col_sn'] ? $DBV['col_sn'] : "";

	$DBV['op'] = "op_insert";

	#上傳單張圖片
	#建構元(模組名稱,"/資料夾","/檔案","/圖片","/縮圖",$multiple)
	//$cate=str_replace ("slider_","",$ugmKind->get_kind());
	$multiple = false;
	$dir_name = "/photo";
	$ugmUpFiles = new ugmUpFiles($DIRNAME, $dir_name, NULL, "", "/thumbs", $multiple);
	$ugmUpFiles->set_col($DBV['kind'], $DBV['sn']);
	#上傳html語法(表單名稱，上傳類型，顯示舊圖，驗證)
	$DBV['form'] = $ugmUpFiles->upform_one($DBV['kind'], "image/*", "show");
	#--------------------------------------------------------------------
	//----- 驗證碼 -----------------*/
	if (!file_exists(XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php")) {
		redirect_header("index.php", 3, _TAD_NEED_TADTOOLS);
	}
	include_once XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php";
	$formValidator = new formValidator("#myForm", true);
	$formValidator->render();
	//-------------------------------*/
	$xoopsTpl->assign('DBV', $DBV);
}

###############################################################################
#  列出所有類別的資料
###############################################################################
function op_list() {
	global $xoopsTpl, $kind_arr, $ugmKind, $DIRNAME, $kind;
	# ----得到外鍵選單之選項 ----------------------------
	$kind_option = "";
	foreach ($kind_arr as $key => $value) {
		$selected = "";
		if ($ugmKind->get_kind() == $key) {
			$selected = " selected";
			$kind_description = $value['description'];
		}
		$kind_option .= "<option value='{$key}'{$selected}>{$value['title']}</option>";
	}
	$kind_form = "
      <select name='kind' id='kind' onchange=\"location.href='?kind='+this.value\"  class='form-control' style='width:300px;'>
        $kind_option
      </select>
  ";
	#----------------------------------------------------

	$xoopsTpl->assign('kind_form', $kind_form);
	$xoopsTpl->assign('kind', $kind);
	$xoopsTpl->assign('kind_description', $kind_description);
	# ----得到陣列 ----------------------------
	$ofsn = 0;
	$level = 1;
	$list = $ugmKind->get_admin_list_body($ofsn, $level);

	#處理縮圖
	$multiple = false;
	$dir_name = "/photo";
	$ugmUpFiles = new ugmUpFiles($DIRNAME, $dir_name, NULL, "", "/thumbs", $multiple);

	foreach ($list as $k => $list_one) {
		$list[$k]['img'] = $ugmUpFiles->get_one_img_src($ugmKind->get_kind(), $list_one['sn'], 1, true, false);
	}

	#---- 刪除javascript函數 ----
	if (!file_exists(XOOPS_ROOT_PATH . "/modules/tadtools/sweet_alert.php")) {
		redirect_header("index.php", 3, _MA_NEED_TADTOOLS);
	}
	include_once XOOPS_ROOT_PATH . "/modules/tadtools/sweet_alert.php";
	$sweet_alert_obj = new sweet_alert();
	$sweet_alert_obj->render('op_delete_js', "?op=op_delete&kind={$kind}&sn=", "sn");
	#-----驗證碼---------------------------------------------------------
	if (!file_exists(XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php")) {
		redirect_header("index.php", 3, _TAD_NEED_TADTOOLS);
	}
	include_once XOOPS_ROOT_PATH . "/modules/tadtools/formValidator.php";
	$formValidator = new formValidator("#myForm", true);
	$formValidator->render();
	#-----驗證碼---------------------------------------------------------

	$xoopsTpl->assign('list', $list);
}

###########################################################
#  新增、編輯資料
###########################################################
function op_insert() {
	global $xoopsDB, $ugmKind, $DIRNAME;
	//---- 過濾資料 -----------------------------------------*/
	$myts = &MyTextSanitizer::getInstance();
	#輪播標題
	$_POST['title'] = $myts->addSlashes($_POST['title']);
	if (empty($_POST['title'])) {
		return false;
	}

	#輪播摘要
	$_POST['content'] = $myts->addSlashes($_POST['content']);
	#網址
	$_POST['url'] = $myts->addSlashes($_POST['url']);
	#類別
	$_POST['kind'] = $myts->addSlashes($_POST['kind']);
	#狀態
	$_POST['enable'] = intval($_POST['enable']);
	#連結狀態
	$_POST['target'] = intval($_POST['target']);
	#sn
	$_POST['sn'] = intval($_POST['sn']);
	#ofsn
	$_POST['ofsn'] = intval($_POST['ofsn']);
	//-------------------------------------------------------*/
	if ($_POST['sn']) {
		#編輯
		#--------檢查---------------------------
		$DBV = $ugmKind->get_one_table_4_sn($_POST['sn']);
		if ($_POST['ofsn'] != $DBV['ofsn']) {
			#類別有變動
			if ($_POST['sn'] == $_POST['ofsn']) {
				redirect_header($_SERVER['PHP_SELF'], 3, _MA_TREETABLE_MOVE_ERROR1);
			} elseif (($ugmKind->chk_kind_level_down($_POST['sn']) + $ugmKind->chk_kind_level($_POST['ofsn'])) > $ugmKind->get_stop_level()) {
				redirect_header($_SERVER['PHP_SELF'], 3, _MD_UGMMOUDEL_KIND_LEVEL_ERROR);
			}
		}
		#--------檢查結束---------------------------
		#
		$sql = "update " . $xoopsDB->prefix($ugmKind->get_tbl()) . " set
      `ofsn`   = '{$_POST['ofsn']}' ,
      `title`  = '{$_POST['title']}' ,
      `content`  = '{$_POST['content']}' ,
      `enable` = '{$_POST['enable']}',
      `target` = '{$_POST['target']}',
      `url` = '{$_POST['url']}'
      where sn='{$_POST['sn']}'";
		$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
	} else {
		#---------新增------------------------
		#---------取得排序--------------------
		$sql = "select max(sort)as max_sort
          from " . $xoopsDB->prefix($ugmKind->get_tbl()) . "
          where ofsn='{$_POST['ofsn']}' and kind='{$_POST['kind']}'";
		$sort = get_ugm_module_sql($sql);
		$sort['max_sort']++;
		#---------寫入-------------------------
		$sql = "insert into " . $xoopsDB->prefix($ugmKind->get_tbl()) . "
    (`ofsn` ,`title` ,`content`, `enable` , `sort`,`kind`,`target`,`url`)
    values('{$_POST['ofsn']}' , '{$_POST['title']}', '{$_POST['content']}' ,'{$_POST['enable']}' , '{$sort['max_sort']}' , '{$_POST['kind']}', '{$_POST['target']}', '{$_POST['url']}')";
		$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
		//取得最後新增資料的流水編號
		$_POST['sn'] = $xoopsDB->getInsertId();
	}

	//-------------------------------------------------------*/
	if (!$_FILES[$_POST['kind']]["error"][0]) {
		$multiple = false; //單檔
		//$cate=str_replace ("slider_","",$ugmKind->get_kind());//home
		$dir_name = "/photo";
		$col_name = $_POST['kind']; //表單名稱
		$safe_name = true; //安全名

		$ugmUpFiles = new ugmUpFiles($DIRNAME, $dir_name, NULL, "", "/thumbs", $multiple);
		$ugmUpFiles->set_col($col_name, $_POST['sn']);
		#上傳單檔圖片
		$ugmUpFiles->upload_single_img($col_name, "", 200, NULL, $_POST['title'], $safe_name, false);
		#(name,sn,sort,縮圖,替代圖)
		//$img_src_thumb=$ugmUpFiles->get_one_img_src($_POST['name'],$_POST['sn'],1,true,false);
		#(name,sn,sort,縮圖,替代圖)
		//$img_src_main=$ugmUpFiles->get_one_img_src($_POST['name'],$_POST['sn'],1,false,false););
	}
	return $_POST['sn'];
}

###############################################################################
#  更新啟用
###############################################################################
function op_update_enable() {
	global $xoopsDB, $ugmKind;
	#權限
	/***************************** 過瀘資料 *************************/
	$enable = intval($_GET['enable']);
	$sn = intval($_GET['sn']);
	/****************************************************************/
	//更新
	$sql = "update " . $xoopsDB->prefix($ugmKind->get_tbl()) . " set  `enable` = '{$enable}' where `sn`='{$sn}'";
	$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
	return;
}

###############################################################################
#  更新外連
###############################################################################
function op_update_target() {
	global $xoopsDB, $ugmKind;
	#權限
	/***************************** 過瀘資料 *************************/
	$target = intval($_GET['target']);
	$sn = intval($_GET['sn']);
	/****************************************************************/
	//更新
	$sql = "update " . $xoopsDB->prefix($ugmKind->get_tbl()) . " set  `target` = '{$target}' where `sn`='{$sn}'";
	$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
	return;
}

###############################################################################
#  移動類別儲存
###############################################################################
function op_save_drag() {
	global $xoopsDB, $ugmKind;
	//$ofsn=intval(str_replace("tr_","",$_POST['ofsn']));
	//$sn=intval(str_replace("tr_","",$_POST['sn']));
	$ofsn = intval($_POST['ofsn']); //目的
	$sn = intval($_POST['sn']); //來源
	if (!$sn) {
		#根目錄不可移動
		die(_MD_UGMMOUDEL_KIND_ROOT_ERROR . "(" . date("Y-m-d H:i:s") . ")" . _BP_F5);
	} elseif ($ofsn == $sn) {
		#自己移至自己
		die(_MA_TREETABLE_MOVE_ERROR1 . "(" . date("Y-m-d H:i:s") . ")" . _BP_F5);
	} elseif ($ugmKind->chk_kind_level($ofsn) + $ugmKind->chk_kind_level_down($sn) > $ugmKind->get_stop_level()) {
		#自己往底層移動或自己底下層數+目的所在層數 > 類別層數
		die(_MD_UGMMOUDEL_KIND_LEVEL_ERROR . "(" . date("Y-m-d H:i:s") . ")" . _BP_F5);
	}

	$sql = "update " . $xoopsDB->prefix($ugmKind->get_tbl()) . "
        set `ofsn`='{$ofsn}' where `sn`='{$sn}'";
	$xoopsDB->queryF($sql) or die("Reset Fail! (" . date("Y-m-d H:i:s") . ")");

	return "Reset OK! (" . date("Y-m-d H:i:s") . ")" . _BP_F5;
}

###########################################################
#  批次編輯資料
###########################################################
function op_all_insert() {
	global $xoopsDB, $ugmKind;
	//---- 過濾資料 -----------------------------------------*/
	$myts = &MyTextSanitizer::getInstance();
	foreach ($_POST['title'] as $sn => $title) {
		$title = $myts->addSlashes($title);
		$sn = intval($sn); #編輯
		$url = $myts->addSlashes($_POST['url'][$sn]);
		$sql = "update " . $xoopsDB->prefix($ugmKind->get_tbl()) . " set
           `title` = '{$title}',
           `url` = '{$url}'
           where sn='{$sn}'";
		$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
	}
}
###############################################################################
#  刪除資料
###############################################################################
function op_delete($sn = "") {
	global $xoopsDB, $tbl, $DIRNAME;
	if (empty($sn)) {
		redirect_header($_SERVER['PHP_SELF'], 3, _BP_DEL_ERROR);
	}

	#取得資料
	$DBV = get_ugm_module_tbl($sn, $tbl);
	$sql = "delete from " . $xoopsDB->prefix($tbl) . "
          where sn='{$sn}'"; //die($sql);
	$xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());

	$multiple = false;
	$cate = str_replace("slider_", "", $DBV['kind']); //home
	$dir_name = "/photo";
	$ugmUpFiles = new ugmUpFiles($DIRNAME, $dir_name, NULL, "", "/thumbs", $multiple);
	$ugmUpFiles->set_col($DBV['kind'], $sn);
	$ugmUpFiles->del_files();
}
###############################################################################
#  自動更新排序
###############################################################################
function op_update_sort() {
	global $xoopsDB, $ugmKind, $DIRNAME;
	$sort = 1;
	foreach ($_POST['tr'] as $sn) {
		if (!$sn) {
			continue;
		}

		$sql = "update " . $xoopsDB->prefix($ugmKind->get_tbl()) . " set `sort`='{$sort}' where `sn`='{$sn}'";
		$xoopsDB->queryF($sql) or die("Save Sort Fail! (" . date("Y-m-d H:i:s") . ")");
		$sort++;
	}
	return "Save Sort OK! (" . date("Y-m-d H:i:s") . ")" . _BP_F5;
}

###############################################################################
#  產生 slider.html
###############################################################################
function write_Slider_html() {
	global $ugmKind, $xoopsDB, $DIRNAME;
	$tbl = $ugmKind->get_tbl();
	$kind = $ugmKind->get_kind();
	$dir_name = "/photo";

	//sn  ofsn  title sort  enable  kind  url target  col_sn
	$sql = "select a.sn,a.title,a.content,a.url,a.target,b.file_name,b.sub_dir
          from      " . $xoopsDB->prefix($tbl) . "                      as a
          left join " . $xoopsDB->prefix("ugm_creative_files_center") . " as b on a.sn = b.col_sn and b.col_name = '{$kind}' and b.sort='1'
          where a.kind='{$kind}' and a.enable='1'
          order by a.sort"; //die($sql);
	$result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());
	//---- 過濾資料 ------------------------*/
	$myts = &MyTextSanitizer::getInstance();
	$item = "";
	$i = 0;
	while ($row = $xoopsDB->fetchArray($result)) {
		$row['target'] = $row['target'] ? " target='_blank'" : "";
		$row['title'] = $myts->htmlSpecialChars($row['title']);
		$row['url'] = $myts->htmlSpecialChars($row['url']);
		$row['file_name'] = $myts->htmlSpecialChars($row['file_name']);
		$row['sub_dir'] = $myts->htmlSpecialChars($row['sub_dir']);
		$html = 0;
		$br = 1;
		$row['content'] = $myts->displayTarea($row['content'], $html, 1, 0, 1, $br);
		#大圖
		if ($row['file_name'] and file_exists(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}{$row['sub_dir']}/{$row['file_name']}")) {
			$row['file_name'] = XOOPS_URL . "/uploads/{$DIRNAME}{$row['sub_dir']}/{$row['file_name']}";
		} else {
			#無圖處理
			$row['file_name'] = XOOPS_URL . "/modules/ugm_tools/images/no_pic/pic_1920_500.jpg";
		}
		#相片展示
		$item .= "			<div class='col-lg-4 col-sm-6'>\n";
		$item .= "				 <a href='{$row['file_name']}' class='portfolio-box'>\n";
		$item .= "					<img src='{$row['file_name']}' class='img-responsive' alt=''>\n";
		$item .= "					<div class='portfolio-box-caption'>\n";
		$item .= "						<div class='portfolio-box-caption-content'>\n";
		$item .= "							<div class='project-category text-faded'>\n";
		$item .= "								{$row['url']}\n";
		$item .= "							</div>\n";
		$item .= "							<div class='project-name'>\n";
		$item .= "								{$row['title']}\n";
		$item .= "							</div>\n";
		$item .= "						</div>\n";
		$item .= "					</div>\n";
		$item .= "				</a>\n";

		$item .= "			</div>\n";
	}
	/*

	*/

	$content = "<section class='no-padding' id='portfolio'>\n";
	$content .= "	<div class='container-fluid'>\n";
	$content .= "		<div class='row no-gutter popup-gallery'>\n";
	$content .= $item;
	$content .= "		</div>\n";
	$content .= "	</div>\n";
	$content .= "</section>\n";

	#---- 檢查資料夾
	mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/tpl");
	$file = XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/tpl/creative_portfolio.html";
	$f = fopen($file, 'w'); //以寫入方式開啟文件
	fwrite($f, $content); //將新的資料寫入到原始的文件中
	fclose($f);
}

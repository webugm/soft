<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/

include_once "../../tadtools/language/{$xoopsConfig['language']}/admin_common.php";
define('_TAD_NEED_TADTOOLS', '需要 tadtools 模組，可至<a href="http://campus-xoops.tn.edu.tw/modules/tad_modules/index.php?module_sn=1" target="_blank">XOOPS輕鬆架</a>下載。');

//ugm_creative_nav-list
define('_MA_UGMCREATIVE_SN', 'sn');
define('_MA_UGMCREATIVE_OFSN', '父類別');
define('_MA_UGMCREATIVE_TITLE', '標題');
define('_MA_UGMCREATIVE_SORT', '排序');
define('_MA_UGMCREATIVE_ENABLE', '狀態');
define('_MA_UGMCREATIVE_KIND', '類別');
define('_MA_UGMCREATIVE_URL', '網址');
define('_MA_UGMCREATIVE_TARGET', '外連');
define('_MA_UGMCREATIVE_BLOCK_ID', '區塊ID');
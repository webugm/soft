CREATE TABLE `ugm_xbootstrap_files_center` (
  `files_sn` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '檔案流水號',
  `col_name` varchar(255) NOT NULL default '' COMMENT '欄位名稱',
  `col_sn` smallint(5) unsigned NOT NULL default 0 COMMENT '欄位編號',
  `sort` smallint(5) unsigned NOT NULL default 0 COMMENT '排序',
  `kind` enum('img','file') NOT NULL default 'img' COMMENT '檔案種類',
  `file_name` varchar(255) NOT NULL default '' COMMENT '檔案名稱',
  `file_type` varchar(255) NOT NULL default '' COMMENT '檔案類型',
  `file_size` int(10) unsigned NOT NULL default 0 COMMENT '檔案大小',
  `description` text NOT NULL default '' COMMENT '檔案說明',
  `counter` mediumint(8) unsigned NOT NULL default 0 COMMENT '下載人次',
  `original_filename` varchar(255) NOT NULL default '' COMMENT '檔案名稱',
  `hash_filename` varchar(255) NOT NULL default '' COMMENT '加密檔案名稱',
  `sub_dir` varchar(255) NOT NULL default '' COMMENT '檔案子路徑',
  PRIMARY KEY (`files_sn`)
) ENGINE=MyISAM;

CREATE TABLE ugm_xbootstrap_nav (
  `sn` smallint(5) unsigned NOT NULL auto_increment comment 'sn',
  `ofsn` smallint(5) unsigned NOT NULL default 0 comment '父類別',
  `kind` varchar(255) NOT NULL default 'nav_home' comment '分類',
  `title` varchar(255) NOT NULL default '' comment '標題',
  `sort` smallint(5) unsigned NOT NULL default 0 comment '排序',
  `enable` enum('1','0') NOT NULL default '1' comment '狀態',
  `url` varchar(255) NOT NULL default '' comment '網址',
  `target` enum('1','0') NOT NULL default '0' comment '外連',
  `col_sn` int(10) unsigned NOT NULL default 0 comment 'col_sn',
  `content` text NOT NULL default '' comment '內容',
  PRIMARY KEY  (`sn`)
) ENGINE=MyISAM;

CREATE TABLE `ugm_xbootstrap_system` (
  `sn` smallint(5) unsigned NOT NULL AUTO_INCREMENT comment 'sn',
  `name` varchar(255) NOT NULL DEFAULT '' comment '表單名稱',
  `kind` varchar(255) NOT NULL default 'system' comment '類別',
  `title` varchar(255) NOT NULL DEFAULT '' comment '標題',
  `value` text default '' comment '值',
  `description` varchar(255) NOT NULL DEFAULT '' comment '描述',
  `formtype` varchar(255) NOT NULL DEFAULT '' comment '表單型態',
  `valuetype` varchar(255) NOT NULL DEFAULT '' comment '值的型態',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0' comment '排序',
  `enable` enum('1','0') NOT NULL default '1' comment '狀態',
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM;



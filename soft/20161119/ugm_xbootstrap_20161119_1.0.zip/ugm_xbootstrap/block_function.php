<?php
define("_TAD_NEWS_ERROR_LEVEL",1);

//錯誤顯示方式
if(!function_exists("show_error")){
  function show_error($sql=""){
  	if(_TAD_NEWS_ERROR_LEVEL==1){
  		return mysql_error()."<p>$sql</p>";
  	}elseif(_TAD_NEWS_ERROR_LEVEL==2){
  		return mysql_error();
  	}elseif(_TAD_NEWS_ERROR_LEVEL==3){
  		return "sql error";
  	}
  	return;
  }
}

<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/

define('_TAD_NEED_TADTOOLS','需要 tadtools 模組，可至<a href="http://campus-xoops.tn.edu.tw/modules/tad_modules/index.php?module_sn=1" target="_blank">XOOPS輕鬆架</a>下載。');
define('_MD_UGMXBOOTSTRAP_SMNAME1', '商品展示主頁');

#all
define("_BP_SUCCESS", "資料寫入成功！！");
define("_BP_DEL_ERROR", "刪除錯誤！！");
define("_BP_DEL_SUCCESS", "刪除成功！！");
define("_BP_F5", "「可以按F5重整畫面！！」");
define("_BP_VIEW", "瀏覽");
define("_BP_DATA_ERROR", "資料錯誤");
define("_BP_AUTO_SEND_MAIL_MESSAGE", "提醒您，此郵件是系統自動回覆,請勿回信。");
define("_BP_SEND_SUCCESS", "已收到您的訊息，我們會儘快處理、回覆，謝謝！！");
define("_BP_FUNCTION", "功能");
define("_BP_EXPORT", "匯出");


define("_MD_UGMMOUDEL_KIND_OFSN", "父類別");
define("_MD_UGMMOUDEL_KIND_TITLE", "類別名稱");
define("_MD_UGMMOUDEL_KIND_ENABLE", "狀態");
define("_MD_UGMMOUDEL_KIND_ENABLE_1", "啟用");
define("_MD_UGMMOUDEL_KIND_ENABLE_0", "停用");
define("_MD_UGMMOUDEL_KIND_TARGET", "連結狀態");
define("_MD_UGMMOUDEL_KIND_TARGET_1", "外連");
define("_MD_UGMMOUDEL_KIND_TARGET_0", "本站");
define("_MD_UGMMOUDEL_KIND_URL", "網址");
define("_MD_UGMMOUDEL_KIND_URL_TITLE", "網址名稱");
define("_MD_UGMMOUDEL_KIND_SORT", "排序");
define("_MD_UGMMOUDEL_KIND_NO_DEL", "分類已使用，目前無法刪除！！");
define("_MD_UGMMOUDEL_KIND_ROOT", "根目錄");
define("_MD_UGMMOUDEL_KIND_FUN", "功能");
define("_MD_UGMMOUDEL_KIND_CREATE_SUB", "建立子類別");
define("_MD_UGMMOUDEL_KIND_HAVE_SUB_NOT_DEL", "尚有子類別不能刪除");
define("_MD_UGMMOUDEL_KIND_LEVEL_ERROR", "來源層數+目的的階層 > 類別層數，請先調整來源的下層，再重新拖曳！！");
define("_MD_UGMMOUDEL_KIND_ROOT_ERROR", "根目錄不能移動！！");
define("_MD_UGMMOUDEL_KIND_RESET_BUTTON", "重整畫面");
define('_MD_UGMMOUDEL_ADD_FORM_TITLE', '新增表單');
define('_MD_UGMMOUDEL_EDIT_FORM_TITLE', '編輯表單');
define('_MD_UGMMOUDEL_RETURN_LIST', '返回');
define('_MD_UGMMOUDEL_SHOWONE', '單筆顯示');
define('_MD_UGMMOUDEL_RETURN_MAIN', '前台');
define('_MD_UGMMOUDEL_ALL', '全部');

define("_MD_UGMMOUDEL_NAV_TITLE", "選單名稱");
#slider.php
define("_MD_UGMMOUDEL_SLIDER_TITLE", "輪播圖標題");
# ------------------------------------------

# system
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_1','logo圖(圖片150 * 42)');
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_1_DESC','上傳logo圖<br>有異動時，必須回到選單管理執行「送出」');

define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_2','首頁訊息 標題');
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_2_DESC','首頁訊息 標題');

define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_3','首頁訊息 內容');
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_3_DESC','首頁訊息 內容');

define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_4','首頁訊息 連結網址');
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_4_DESC','首頁訊息 連結網址');

define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_5','首頁訊息 啟用狀態');
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_5_DESC','首頁訊息 啟用狀態');

define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_6','首頁訊息 外連狀態');
define('_MD_UGMXBOOTSTRAP_SYSTEM_NAME_6_DESC','首頁訊息 外連狀態');

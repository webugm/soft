<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/


$modversion = array();

//---模組基本資訊---//
$modversion['name']        = _MI_UGMCREATIVE_NAME;
$modversion['version']     = '1.0';
$modversion['description'] = _MI_UGMCREATIVE_DESC;
$modversion['author']      = _MI_UGMCREATIVE_AUTHOR;
$modversion['credits']     = _MI_UGMCREATIVE_CREDITS;
$modversion['help']        = 'page=help';
$modversion['license']     = _MI_UGMCREATIVE_LICENSE;
$modversion['image']       = "images/logo.png";
$modversion['dirname']     = basename(__DIR__);

//---模組狀態資訊---//
$modversion['status_version']      = '1.0';
$modversion['release_date']        = '2016-06-10';
$modversion['module_website_url']  = 'http://www.ugm.com.tw';
$modversion['module_website_name'] = _MI_UGMCREATIVE_AUTHOR_WEB;
$modversion['module_status']       = 'release';
$modversion['author_website_url']  = 'http://www.ugm.com.tw';
$modversion['author_website_name'] = _MI_UGMCREATIVE_AUTHOR_WEB;
$modversion['min_php']             = '5.4';
$modversion['min_xoops']           = '2.5';

//---paypal資訊---//
$modversion['paypal']                  = array();
$modversion['paypal']['business']      = 'tawan158@gmail.com';
$modversion['paypal']['item_name']     = 'Donation :' . _MI_UGMCREATIVE_AUTHOR;
$modversion['paypal']['amount']        = 0;
$modversion['paypal']['currency_code'] = 'USD';

//---安裝設定---//
$modversion['onInstall']   = "include/onInstall.php";
$modversion['onUpdate']    = "include/onUpdate.php";
$modversion['onUninstall'] = "include/onUninstall.php";

//---啟動後台管理界面選單---//
$modversion['system_menu'] = 1;


//---資料表架構---//
$modversion['sqlfile']['mysql'] = "sql/mysql.sql";
$modversion['tables'][1] = "ugm_creative_files_center";
$modversion['tables'][2] = "ugm_creative_nav";
$modversion['tables'][3] = "ugm_creative_system";

//---管理介面設定---//
$modversion['hasAdmin']   = 1;
$modversion['adminindex'] = "admin/index.php";
$modversion['adminmenu']  = "admin/menu.php";

//---使用者主選單設定---//
$modversion['hasMain'] = 0;
$i=0;


//---樣板設定---//
$i=0;
#---- 系統變數(後台) ---
$modversion['templates'][$i]['file'] = 'ugm_creative_adm_system_b3.html';
$modversion['templates'][$i]['description'] = 'ugm_creative_adm_system_b3.html for bootstrap3';

#---- 選單(後台) ---
$i++;
$modversion['templates'][$i]['file'] = 'ugm_creative_adm_nav_b3.html';
$modversion['templates'][$i]['description'] = 'ugm_creative_adm_nav_b3.html for bootstrap3';

#---- 輪播(後台) ---
$i++;
$modversion['templates'][$i]['file'] = 'ugm_creative_adm_slider_b3.html';
$modversion['templates'][$i]['description'] = 'ugm_creative_adm_slider_b3.html for bootstrap3';



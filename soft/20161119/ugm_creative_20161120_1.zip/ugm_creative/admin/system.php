<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/


/*-----------引入檔案區--------------*/
$isAdmin=true;
$xoopsOption['template_main'] = 'ugm_creative_adm_system_b3.html';
include_once "header.php";
include_once "../function.php";

include_once XOOPS_ROOT_PATH."/modules/ugm_tools/ugmUpFiles.php";

#取得主要資料庫
$tbl="ugm_creative_system";
#模組名稱
$DIRNAME=$xoopsModule->getVar('dirname');
#Foreign key
$kind_arr=array(
  "message_home"=>array("title"=>"首頁訊息")
);

/*-----------執行動作判斷區----------*/
#system_CleanVars (&$global, $key, $default= '', $type= 'int')
include_once $GLOBALS['xoops']->path( '/modules/system/include/functions.php' );
$op = system_CleanVars($_REQUEST, 'op', '', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');
$kind = system_CleanVars($_REQUEST, 'kind', 'message_home', 'string');
$name = system_CleanVars($_REQUEST, 'name', '', 'string');

switch($op){
  //更新多檔圖片排序
  case "op_update_showPic_sort":
    $tbl="ugm_creative_files_center";
    echo op_update_sort($tbl,"li","files_sn");
    XoopsCache::clear();
  exit;

  //更新排序
  case "op_update_sort":
    echo op_update_sort($tbl,"tr");
    XoopsCache::clear();
  exit;
  //更新狀態
  case "op_update_enable":
    $sn=op_update_enable($sn);
    XoopsCache::clear();
    redirect_header($_SESSION['return_url'],3,_BP_SUCCESS);
  exit;
  #---- 新增資料
  case "op_insert":
    $sn=op_insert();
    #寫入uploads/ugm_creative/system/nav/logo.html
    if($name == "system_nav_logo") run_system_nav_logo($sn,$name,$kind);
    #寫入 uploads/ugm_creative/system/message_home/message_home.html
    if($kind == "message_home") run_system_message_home($sn,$name,$kind);
    XoopsCache::clear();
    redirect_header($_SESSION['return_url'],3,_BP_SUCCESS);
  exit;

  //輸入表格
  case "op_form":
    //print_r($_REQUEST);die();
    op_form($sn,$kind,$name);
  break;

  //顯示單筆
  case "showOne":
    echo show_lytebox_html_b3(showOne($sn));
  exit;

  //預設動作
  default:
    if(!$sn){
      # ---- 目前網址 ----
      $_SESSION['return_url']=getCurrentUrl();
      $op="op_list";
      #---- 放在function
      ugm_system_list($kind,$name);
    }else{
      $op="showOne";
      $main=showOne($sn,$kind,true);
      $xoopsTpl->assign("main" , $main);

    }
  break;

}


/*-----------秀出結果區--------------*/
#CSS
$xoTheme->addStylesheet(XOOPS_URL."/modules/ugm_tools/css/xoops_adm3.css");
$xoTheme->addStylesheet(XOOPS_URL."/modules/ugm_tools/css/forms.css");
$xoTheme->addStylesheet(XOOPS_URL."/modules/{$DIRNAME}/css/module_b3.css");
#檔名
$file_name=basename ($_SERVER['PHP_SELF']);
$moduele_admin = new ModuleAdmin();
$xoopsTpl->assign("Navigation",$moduele_admin->addNavigation($file_name));
$xoopsTpl->assign("op",$op);
$xoopsTpl->assign("DIRNAME" , $DIRNAME);
$xoopsTpl->assign("action" , $file_name);
include_once 'footer.php';

/*-----------function區--------------*/
###############################################################################
#  寫入logo.html
###############################################################################
function run_system_nav_logo($sn,$name,$kind)
{
  global $DIRNAME,$xoopsConfig;
  $multiple=false;
  $dir_name="/system/".$kind  ;# --- 表單欄位名稱
  $col_name=$name;
  $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
  $ugmUpFiles->set_col($col_name,$sn);

  $logo_src=$ugmUpFiles->get_one_img_src($col_name,$sn,1);
  #---- 檢查資料夾
  mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system");
  mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$kind}");

  $content = "<img src='{$logo_src}' alt='{$xoopsConfig['sitename']}' class='img-responsive'>";
  $file=XOOPS_ROOT_PATH."/uploads/ugm_creative/system/{$kind}/logo.html";
  $f = fopen($file, 'w');//以寫入方式開啟文件
  fwrite($f,$content);//將新的資料寫入到原始的文件中
  fclose($f);

}

###############################################################################
#  寫入message_home.html
###############################################################################
function run_system_message_home($sn,$name,$kind)
{
  global $DIRNAME;
  #---- 過濾讀出的變數值 ----
  $myts = MyTextSanitizer::getInstance();
  #---- 檢查資料夾
  mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system");
  mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$kind}");

  $tbl="ugm_creative_system";
  $kind="message_home";
  #---- 首頁訊息 標題
  $name="system_message_home_title";
  $system_message_home_title= $myts->htmlSpecialChars(get_modules_system_var($tbl,$kind,$name));
  #---- 首頁訊息 內容
  $html=1;$br=0;
  $name="system_message_home_content";
  $system_message_home_content= $myts->displayTarea(get_modules_system_var($tbl,$kind,$name), $html, 1, 0, 1, $br);
  #---- 首頁訊息 連結網址
  $name="system_message_home_url";
  $system_message_home_url= $myts->htmlSpecialChars(get_modules_system_var($tbl,$kind,$name));
  #---- 首頁訊息 啟用狀態
  $name="system_message_home_enable";
  $system_message_home_enable= intval(get_modules_system_var($tbl,$kind,$name));
  #---- 首頁訊息 外連狀態
  $name="system_message_home_target";
  $system_message_home_target= intval(get_modules_system_var($tbl,$kind,$name));
  $system_message_home_target=$system_message_home_target?" target='_blank'":"";

  if($system_message_home_enable){
    $content  = "<div class='aligncenter home-message row'>\n";
    $content .= "  <div class='col-md-12'>\n";
    $content .= "    <h2>{$system_message_home_title}</h2>\n";
    $content .= "    <p class='lead'>{$system_message_home_content}</p>\n";
    $content .= "    <p><a href='{$system_message_home_url}' class='btn btn-md btn-success'{$system_message_home_target}><{\$smarty.const.THEME_LEARNINGMORE}></a></p>\n";
    $content .= "  </div>\n";
    $content .= "</div><!-- .home-message -->\n";
  }else{
    $content = "";
  }

  $file=XOOPS_ROOT_PATH."/uploads/ugm_creative/system/{$kind}/message_home.html";
  $f = fopen($file, 'w');//以寫入方式開啟文件
  fwrite($f,$content);//將新的資料寫入到原始的文件中
  fclose($f);

}
###############################################################################
#  編輯表單
###############################################################################
function op_form($sn="",$kind="system",$name="")
{
  global $xoopsDB,$xoopsUser,$tbl,$xoopsTpl,$DIRNAME,$kind_arr;
  //----------------------------------*/
  //抓取預設值
  if(!empty($sn)){
    $DBV=get_ugm_module_tbl($sn,$tbl);
  }elseif(!empty($name)){
    $sql = "select *
            from ".$xoopsDB->prefix($tbl)."
            where name='{$name}' and kind='{$kind}'";
    $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    $DBV=$xoopsDB->fetchArray($result);
  }

  $pre=_EDIT;

  #防呆
  if(empty($DBV))redirect_header($_SESSION['return_url'],3, "錯誤！！");

  $DBV['form_title']=$pre.$kind_arr[$kind]['title'];

  //預設值設定 sn  name  title value description formtype  valuetype sort  enable  kind
  //設定「sn」欄位預設值
  $DBV['sn']=(!isset($DBV['sn']))?"":$DBV['sn'];
  //設定「表單名稱」欄位預設值
  $DBV['name']=(!isset($DBV['name']))?"":$DBV['name'];
  //設定「標題」欄位預設值
  $DBV['title']=(!isset($DBV['title']))?"":constant($DBV['title']);
  //設定「值」欄位預設值
  $DBV['value']=(!isset($DBV['value']))?"":$DBV['value'];
  //設定「描述」欄位預設值
  $DBV['description']=(!isset($DBV['description']))?"":constant($DBV['description']);
  //設定「表單型態」欄位預設值
  $DBV['formtype']=(!isset($DBV['formtype']))?"":$DBV['formtype'];
  //設定「值的型態」欄位預設值
  $DBV['valuetype']=(!isset($DBV['valuetype']))?"":$DBV['valuetype'];
  //設定「排序」欄位預設值
  $DBV['sort']=(!isset($DBV['sort']))?"":$DBV['sort'];
  //設定「狀態」欄位預設值
  $DBV['enable']=(!isset($DBV['enable']))?"":$DBV['enable'];
  //設定「類別」欄位預設值
  $DBV['kind']=(!isset($DBV['kind']))?"":$DBV['kind'];

  $DBV['return_url']=$_SESSION['return_url'];

  $DBV['op']="op_insert";

  if($DBV['formtype']=="file"){

    if($DBV['valuetype']=="single_img"){
      #上傳單張圖片
      #建構元(模組名稱,"/資料夾","/檔案","/圖片","/縮圖",$multiple)
      $multiple=false;
      $dir_name="/system/".$DBV['kind']  ;# --- 表單欄位名稱
      $col_name=$DBV['name'];
      $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
      $ugmUpFiles->set_col($col_name,$DBV['sn']);
      #上傳html語法(表單名稱，上傳類型，顯示舊圖，驗證)
      $DBV['form']=$ugmUpFiles->upform_one($col_name,"image/*","show");
    }elseif($DBV['valuetype']=="multiple_img"){
      #上傳多張圖片
      $multiple=true;
      $dir_name="/system/".$DBV['kind']   ;# --- 表單欄位名稱
      $col_name=$DBV['name'];
      $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
      $ugmUpFiles->set_col($col_name,$DBV['sn']);
      #上傳html語法(表單名稱，上傳類型，顯示舊圖，驗證)
      $DBV['form']=$ugmUpFiles->upform($col_name,"image/*","show");
    }
  }elseif($DBV['formtype']=="textbox"){
    $DBV['form']="<input type='text' class='form-control' name='value' id='value' value='{$DBV['value']}'>";
  }elseif($DBV['formtype']=="textarea"){
    $DBV['form']="<textarea class='form-control' rows='5' id='value' name='value'>{$DBV['value']}</textarea>";
  }elseif($DBV['formtype']=="fck"){
    //內容#資料放「content」
    # ======= ckedit====
    if(!file_exists(XOOPS_ROOT_PATH."/modules/tadtools/ck.php")){
      redirect_header("http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50" , 3 , _TAD_NEED_TADTOOLS);
    }
    include_once XOOPS_ROOT_PATH."/modules/tadtools/ck.php";
    #---- 檢查資料夾
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}");
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}/fck");
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}/fck/image");
    mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/system/{$DBV['kind']}/fck/flash");

    $dir_name=$DIRNAME."/system/{$DBV['kind']}/fck";
    $ck=new CKEditor($dir_name,"value",$DBV['value'],$DIRNAME);
    $ck->setHeight(300);
    $DBV['form']=$ck->render();

  }elseif($DBV['formtype']=="yesno"){
    $value_1=$DBV['value']?" checked":"";
    $value_0=$DBV['value']?"":" checked";
    $DBV['form']="<input type='radio' name='value' id='value_1' value='1' {$value_1}>\n
    <label for='value_1'>"._YES."</label>&nbsp;&nbsp;\n
    <input type='radio' name='value' id='value_0' value='0' {$value_0}>\n
    <label for='value_0'>"._NO."</label>";
  }

  $xoopsTpl->assign('DBV',$DBV);
}
###############################################################################
#  編輯資料
###############################################################################
function op_insert()
{
  global $xoopsDB,$xoopsUser,$tbl,$DIRNAME,$xoopsConfig;

  //---- 過濾資料 -----------------------------------------*/
  //替特殊符號加入脫逸符號，再存入資料庫
  $myts =& MyTextSanitizer::getInstance();

  $_POST['kind'] = $myts->addSlashes($_POST['kind']);//文字
  $_POST['sn']   = intval($_POST['sn']);//數字
  $_POST['value']= $myts->addSlashes($_POST['value']);//

  $DBV=get_ugm_module_tbl($_POST['sn'],$tbl);
  $DBV['title']=constant($DBV['title']);

  #防呆
  if(empty($DBV))redirect_header($_SESSION['return_url'],3, "錯誤！！");

  if($DBV['formtype']=="file"){
    #上傳單張圖片
    if($DBV['valuetype']=="single_img"){
      if(!$_FILES[$DBV['name']]["error"][0]){
        $safe_name=true;
        $multiple=false;
        $dir_name="/system/".$DBV['kind'];
        $col_name=$DBV['name'];
        $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
        $ugmUpFiles->set_col($col_name,$DBV['sn']);
        #上傳單檔圖片
        $ugmUpFiles->upload_single_img($col_name,$DBV['value'],120,NULL,$DBV['title'],$safe_name,false);
      }
    }elseif($DBV['valuetype']=="multiple_img"){

        $safe_name=true;
        $multiple=true;
        $dir_name="/system/".$DBV['kind'];
        $col_name=$DBV['name'];
        $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);

        $ugmUpFiles->set_col($col_name,$DBV['sn']);
        #上傳多檔圖片($col_name,主圖寬,縮圖寬,$file_sn,$desc,$safe_name,false)
        $ugmUpFiles->upload_file($col_name,$DBV['value'],120,NULL,"",$safe_name,false);
    }
    return $_POST['sn'];
  }
  //-------------------------------------------------------*/
  #更新系統變數值
  $sql="update ".$xoopsDB->prefix($tbl)."
        set
        `value`='{$_POST['value']}'
        where `sn`='{$_POST['sn']}'";//die($sql);
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3,$sql);

  return $_POST['sn'];
}


###############################################################################
#  自動更新排序
###############################################################################
function op_update_sort($tbl,$post_name="tr",$key="sn")
{
  global $xoopsDB;
  $sort=1;
  foreach ($_POST[$post_name] as $sn) {
    $sql="update ".$xoopsDB->prefix($tbl)." set `sort`='{$sort}' where `{$key}`='{$sn}'";
    $xoopsDB->queryF($sql) or die("Save Sort Fail! <br>".$sql);
    $sort++;
  }
  //die(print_r($_POST['tr']));
  return "Save Sort OK! (".date("Y-m-d H:i:s").")"._BP_F5;
}
###############################################################################
#  更新啟用
###############################################################################
function op_update_enable()
{
  global $xoopsDB,$xoopsUser,$tbl;
  #權限
  /***************************** 過瀘資料 *************************/
  $enable=intval($_GET['enable']);
  $sn=intval($_GET['sn']);
  /****************************************************************/
  //更新
  $sql = "update ".$xoopsDB->prefix($tbl)." set  `enable` = '{$enable}' where `sn`='{$sn}'";
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  return ;
}
###############################################################################
#  顯示單筆
###############################################################################
function showOne($sn="",$kind,$button=false)
{
  global $xoopsDB,$tbl;

  $sql = "select a.*
          from      ".$xoopsDB->prefix($tbl)."  as a
          where a.sn='{$sn}'
          ";//die($sql);
  $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  $DBV=$xoopsDB->fetchArray($result);
  $DBV['enable']=$DBV['enable']?"<img src='../images/on.png' />":"<img src='../images/off.png' />";
  $DBV['date']=date("Y-m-d" , xoops_getUserTimestamp($DBV['date']));
  if($kind=="system"){
    $DBV['form_title']=_MD_UGM_SHOW10_NEWS_PRE_SYS;
  }elseif($kind=="page"){
    $DBV['form_title']=_MD_UGM_SHOW10_NEWS_PRE_PAGE;
  }else{
    $DBV['form_title']=_MD_UGM_SHOW10_NEWS_PRE_NEWS;
  }
  $button=$button?"
    <button onclick=\"window.location.href='?op=op_form&kind={$DBV['kind']}&sn={$DBV['sn']}'\" class='btn  btn-success '>"._EDIT."</button>
    <button onclick=\"window.location.href='?op=op_form&kind={$DBV['kind']}'\" class='btn  btn-primary '>"._ADD."</button>
    <button type='button' class='btn btn-warning' onclick=\"location.href='{$_SESSION['return_url']}'\">"._BACK."</button>
  ":"";
  #--------------
  $main="
    <div class='container-fluid'>
      <div class='row'>
        <div class='panel panel-default'>
          <div class='panel-heading'>
            <h3 class='panel-title'>{$DBV['form_title']}</h3>
          </div>
          <div class='panel-body'>
            <div style='margin-bottom:10px;'>{$button}</div>
            <table id='form_table' class='table table-bordered table-condensed table-hover' >
              <tr>
                <th class='col-md-2 text-center'>"._MD_UGM_SHOW10_NEWS_TITLE."</th>
                <td class='col-md-10'>
                  {$DBV['title']}
                </td>
              </tr>
              <tr>
                <th class='col-md-2 text-center'>"._MD_UGM_SHOW10_NEWS_ENABLE."</th>
                <td class='col-md-10'>
                  {$DBV['enable']}
                </td>
              </tr>
              <tr>
                <th class='col-md-2 text-center'>"._MD_UGM_SHOW10_NEWS_DATE."</th>
                <td class='col-md-10'>
                  {$DBV['date']}
                </td>
              </tr>
              <!--內容-->
              <tr>
                <th class='text-center'>"._MD_UGM_SHOW10_NEWS_CONTENT."</th>
                <td>
                  {$DBV['content']}
                </td>
              </tr>
            </table>
          </div>
        </div>

  ";
  return $main;
}




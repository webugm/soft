<?php

//Nav Menu
define("THEME_HOME", "回首頁");
define("THEME_MODULE1", "關於");
define("THEME_MODULE2", "新聞");
define("THEME_MODULE3", "討論區");
define("THEME_MODULE4", "聯繫我們");
define("THEME_SEARCH_TEXT", "搜尋...");
define("THEME_SEARCH_BUTTON", "送出");

//Slider
define("THEME_READMORE", "更多");

//Home Message
define("THEME_ABOUTUS", "關於我們");
define("THEME_LEARNINGMORE", "更多...");

//NewBB
define("THEME_NEWBB_TOPIC", "更多");
define("THEME_FORUM_SPONSORBY", "贊助者：");
define("THEME_GOTOTHEFORUM", "到討論區");
define("THEME_FORUM_DESCRIPTION", "說明");
define("THEME_NEWBB_SEARCH_FORUM", "在討論區中搜尋...");
define("THEME_NEWBB_SEARCH_TOPIC", "在主題中搜尋...");
define("THEME_FORUM_DESC", "關於此討論區");

//Block login
define("THEME_LOGIN", "您的帳號");
define("THEME_PASS", "您的密碼");

document.write('<table id=\"footer\"><tr><td id=\"td_footer\">');
document.write('<div align=\"center\">Developed By <a href=\"http://www.uniformserver.com/\">The Uniform Server Development Team</a></div>');
document.write('</td></tr></table>');

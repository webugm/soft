<?php

// [default config]
// DO NOT rename/delete/modify this file which will be overwritten when upgrade
// See config.example.php instead

// $config['include_paths'] = array();
// $config['exclude_paths'] = array();
$config['syntax_higlight'] = true;
$config['use_cache'] = false;
// $config['datadir'] is default to ini_get("xcache.coveragedump_directory")


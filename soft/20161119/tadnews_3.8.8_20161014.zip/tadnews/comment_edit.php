<?php
include '../../mainfile.php';
include XOOPS_ROOT_PATH . '/include/comment_edit.php';

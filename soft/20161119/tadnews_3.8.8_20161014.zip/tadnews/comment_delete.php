<?php
include '../../mainfile.php';
include XOOPS_ROOT_PATH . '/include/comment_delete.php';

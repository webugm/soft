<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/


//引入TadTools的函式庫
if(!file_exists(XOOPS_ROOT_PATH."/modules/tadtools/tad_function.php")){
    redirect_header("http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50",3, _TAD_NEED_TADTOOLS);
}
include_once XOOPS_ROOT_PATH."/modules/tadtools/tad_function.php";

include_once "block_function.php";
include_once XOOPS_ROOT_PATH."/modules/ugm_tools/ugmTools.php";


/********************* 自訂函數 *********************/

#############################################
#  系統變數列表
#  只撈 enable=1
#############################################
function ugm_system_list($kind="system",$name="")
{
  global $xoopsDB,$xoopsTpl,$tbl,$kind_arr,$DIRNAME;
  #預設Foreign key=> system
  #---- 防呆
  if(!in_array($kind,array_keys($kind_arr))){
    $kind="system";
  }

  # ----得到Foreign key選單 ----------------------------
  $kind_option="";
  foreach($kind_arr as $key=>$value){
    $selected="";
    if($kind==$key){
      $selected=" selected";
    }
    $kind_option.="<option value='{$key}'{$selected}>{$value['title']}</option>";
  }
  $kind_form="
    <select name='kind' id='kind'class='form-control' onchange=\"location.href='?kind='+this.value\">
      $kind_option
    </select>
  ";
  $xoopsTpl->assign('kind_form',$kind_form);
  $xoopsTpl->assign('kind',$kind);
  #-------------------------------------------

  $sql = "select *
          from ".$xoopsDB->prefix($tbl)." as a
          where kind='{$kind}' and enable='1'
          order by a.sort";//die($sql);
  $result = $xoopsDB->query($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());

  $myts = MyTextSanitizer::getInstance();
  $i=1;
  while($DBV=$xoopsDB->fetchArray($result)){
    #---- 過濾讀出的變數值 ----
    #sn name  title value description formtype  valuetype sort  enable  kind
    $DBV['name'] = $myts->htmlSpecialChars($DBV['name']);
    $DBV['kind'] = $myts->htmlSpecialChars($DBV['kind']);
    /*
    「yesno」是否的單選框
    「select」下拉選單
    「select_multi」可複選的下拉選單
    「group」群組下拉選單
    「group_multi」可複選的群組下拉選單
    「textbox」文字框
    「textarea」大量文字框
    「user」已註冊使用者下拉選單
    「user_multi」可複選的已註冊使用者下拉選單
    「timezone」時區下拉選單
    「language」語系下拉選單

     */

    if($DBV['formtype']=="textbox" or $DBV['formtype']=="textarea"){
      #---- 文字框
      $html=0;$br=1;
      $DBV['value']       = $myts->displayTarea($DBV['value'], $html, 1, 0, 1, $br);
    }elseif($DBV['formtype']=="fck"){
      #---- fck編輯器
      $html=1;$br=0;
      $DBV['value']       = $myts->displayTarea($DBV['value'], $html, 1, 0, 1, $br);
    }elseif($DBV['formtype']=="file"){
      if($DBV['valuetype']=="single_img"){
        #---- 單圖
        $multiple=false;
      }elseif($DBV['valuetype']=="multiple_img"){
        #---- 多圖
        $multiple=true;
      }
      $dir_name="/system/".$DBV['kind'];
      $col_name=$DBV['name'];
      $show_del=false;
      $ugmUpFiles=new ugmUpFiles($DIRNAME,$dir_name,NULL,"","/thumbs",$multiple);
      $ugmUpFiles->set_col($col_name,$DBV['sn']);
      $DBV['value'] = $ugmUpFiles->list_show_file_b3($show_del);
    }elseif($DBV['formtype']=="yesno"){
      $DBV['value'] = ($DBV['value'])?_YES:"<span class='text-danger'>"._NO."</span>";
    }

    $DBV['title'] = $myts->htmlSpecialChars(constant($DBV['title']));
    $DBV['description'] = $myts->htmlSpecialChars(constant($DBV['description']));
    $DBV['sort']=$i;
    $i++;
    $list[]=$DBV;
  }
  # ------------------------------------------------------------
  $xoopsTpl->assign("list",$list);
}


###############################################################################
#  取得相關第1張圖片
#  如要寫進ugm_tools => $DIRNAME,$tbl
###############################################################################
function get_files_center_picUrl($col_sn,$col_name){
  global $xoopsDB,$DIRNAME;

  if(!$col_sn or !$col_name)redirect_header($_SESSION['return_url'],3,_BP_DATA_ERROR);

  $sql = "select sub_dir,file_name
          from  `".$xoopsDB->prefix("ugm_creative_files_center")."`
          where `col_sn` = '{$col_sn}' and col_name = '{$col_name}'
          order by sort
          limit 1";//die($sql);
  $result = $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  list($sub_dir,$file_name)=$xoopsDB->fetchRow($result);

  #檢查圖片是否存在
  if($file_name and file_exists(XOOPS_ROOT_PATH."/uploads/{$DIRNAME}{$sub_dir}/{$file_name}")){
    $file_name = XOOPS_URL."/uploads/{$DIRNAME}{$sub_dir}/{$file_name}";
  }else{
    $file_name = XOOPS_URL."/modules/ugm_tools/images/no_pic/pic_800_600.jpg";
  }
  return $file_name ;
}
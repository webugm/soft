<?php
/**
 * Ugm Show10 module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Show10
 * @since      2.5
 * @author     育將電腦工作室
 * @version    $Id $
 **/


/*-----------引入檔案區--------------*/
$isAdmin=true;
$xoopsOption['template_main'] = 'ugm_creative_adm_nav_b3.html';
include_once "header.php";
include_once "../function.php";

#取得kind資料庫
$tbl="ugm_creative_nav";
#取得模組名稱
$DIRNAME=$xoopsModule->getVar('dirname');
#引入類別物件---------------------------------
include_once XOOPS_ROOT_PATH."/modules/ugm_tools/ugmKind.php";
#引入上傳物件
include_once XOOPS_ROOT_PATH."/modules/ugm_tools/ugmUpFiles.php";


/*-----------執行動作判斷區----------*/
#system_CleanVars (&$global, $key, $default= '', $type= 'int')
include_once $GLOBALS['xoops']->path( '/modules/system/include/functions.php' );
$op = system_CleanVars($_REQUEST, 'op', '', 'string');
$sn = system_CleanVars($_REQUEST, 'sn', '', 'int');
$kind = system_CleanVars($_REQUEST, 'kind', '', 'string');
//$name = system_CleanVars($_REQUEST, 'name', '', 'string');


# kind--------------------------------------------------
$kind=empty($kind)?"nav_home":$kind;
#初始值
$kind_arr=array(
  "nav_home"=>array("title"=>"首頁選單","stop_level"=>1)
);
#stop_level
$stop_level=get_stop_level($kind,$kind_arr);
$ugmKind=new ugmKind($tbl,$kind,$stop_level);
#---------------------------------

switch($op){
  #---- 顯示「選單LOGO」變數
  case "list_nav_var":
    # ---- 目前網址 ----
    $_SESSION['return_url']=getCurrentUrl();

    $op="list_nav_var";
    #取得主要資料庫
    $tbl="ugm_creative_system";
    #Foreign key
    $kind_arr=array(
      "nav"=>array("title"=>"LOGO設定")
    );
    $kind = system_CleanVars($_REQUEST, 'kind', 'nav', 'string');
    $name = system_CleanVars($_REQUEST, 'name', '', 'string');
    ugm_system_list($kind,$name);
  break;

  case "op_update_sort":     //更新排序
    echo op_update_sort();
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
  exit;

  case "op_save_drag":       //移動類別儲存
    echo op_save_drag();
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
  exit;
  //更新狀態
  case "op_update_enable":
    op_update_enable();
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
    redirect_header($_SERVER['PHP_SELF']."?kind={$kind}",3,_BP_SUCCESS);
  break;

  //更新外連狀態
  case "op_update_target":
    op_update_target();
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
    redirect_header($_SERVER['PHP_SELF']."?kind={$kind}",3,_BP_SUCCESS);
  break;

  //新增資料
  case "op_insert":
    op_insert($sn);
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
    redirect_header($_SERVER['PHP_SELF']."?kind={$kind}",3,_BP_SUCCESS);
  break;

  //新增資料
  case "op_all_insert":
    op_all_insert();
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
    redirect_header($_SERVER['PHP_SELF']."?kind={$kind}",3,_BP_SUCCESS);
  break;
  //輸入表格
  case "op_form":
    op_form($sn);
  break;

  //刪除資料
  case "op_delete":
    op_delete($sn);
    #產生nav.html
    write_Nav_html();
    XoopsCache::clear();
    redirect_header($_SERVER['PHP_SELF']."?kind={$kind}",3,_BP_DEL_SUCCESS);
  break;

  //預設動作
  default:
  # ---- 目前網址 ----
  $_SESSION['return_url']=getCurrentUrl();
  $op="op_list";
  op_list();
  break;
  /*---判斷動作請貼在上方---*/
}

/*-----------秀出結果區--------------*/
#CSS
$xoTheme->addStylesheet(XOOPS_URL."/modules/ugm_tools/css/xoops_adm3.css");
$xoTheme->addStylesheet(XOOPS_URL."/modules/ugm_tools/css/forms.css");
$xoTheme->addStylesheet(XOOPS_URL."/modules/{$DIRNAME}/css/module_b3.css");
//$xoopsTpl->assign("isAdmin" , true);
$file_name=basename ($_SERVER['PHP_SELF']);
$moduele_admin = new ModuleAdmin();
$xoopsTpl->assign("Navigation",$moduele_admin->addNavigation($file_name));
$xoopsTpl->assign("op" , $op);
$xoopsTpl->assign("DIRNAME" , $DIRNAME);
$xoopsTpl->assign("action" ,$file_name );
include_once 'footer.php';
/*-----------功能函數區--------------*/
###############################################################################
#  產生 nav.html
###############################################################################
function write_Nav_html() {
  global $ugmKind, $DIRNAME;
 
  //---- 過濾資料 -------------------------*/
  $myts = &MyTextSanitizer::getInstance();
 
  # ----得到陣列 ----------------------------
  $ofsn = 0;
  $level = 1;
  $nav_arr = $ugmKind->get_use_theme_nav_html($ofsn, $level);
 
  $nav_body_html = "";
  #第1層
  foreach ($nav_arr as $nav) {
    $target = $nav['target'] ? " target='_blank'" : "";
    $url = $nav['url'] ? $myts->addSlashes($nav['url']) : "#";
    $title = $nav['title'] ? $myts->addSlashes($nav['title']) : "";
    $nav_body_html .= "       <li><a class='page-scroll' href='{$url}' {$target}>{$title}</a></li>\n";
  }
  /*
 
  */
  $nav_html .= "<nav id='mainNav' class='navbar navbar-default navbar-fixed-top <{if \$xoops_dirname != \"system\"}>affix<{/if}>'>\n";
  $nav_html .= "  <div class='container'>\n";
  $nav_html .= "    <!-- Brand and toggle get grouped for better mobile display -->\n";
  $nav_html .= "    <div class='navbar-header'>\n";
  $nav_html .= "      <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#bs-example-navbar-collapse-1'>\n";
  $nav_html .= "        <span class='sr-only'>Toggle navigation</span> Menu <i class='fa fa-bars'></i>\n";
  $nav_html .= "      </button>\n";
  $nav_html .= "      <a class='navbar-brand page-scroll' href='#page-top'><{\$xoops_sitename}></a>\n";
  $nav_html .= "    </div>\n";
  $nav_html .= "    <!-- Collect the nav links, forms, and other content for toggling -->\n";
  $nav_html .= "    <div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>\n";
  $nav_html .= "      <ul class='nav navbar-nav navbar-right'>\n";
  $nav_html .= $nav_body_html;
  $nav_html .= "      </ul>\n";
  $nav_html .= "    </div>\n";
  $nav_html .= "    <!-- /.navbar-collapse -->\n";
  $nav_html .= "  </div>\n";
  $nav_html .= "  <!-- /.container-fluid -->\n";
  $nav_html .= "</nav>\n";
 
  $file_name = "creative_nav.html";
 
  #---- 檢查資料夾
  mk_dir(XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/tpl");
 
  $file = XOOPS_ROOT_PATH . "/uploads/{$DIRNAME}/tpl/" . $file_name;
  $f = fopen($file, 'w'); //以寫入方式開啟文件
  fwrite($f, $nav_html); //將新的資料寫入到原始的文件中
  fclose($f);
}
#取得stop_level
function get_stop_level($kind,$kind_arr){
  foreach($kind_arr as $key=>$value){
    if($kind==$key){
      return $value['stop_level'];
    }
  }
}

###############################################################################
#  編輯表單
###############################################################################
function op_form($sn=""){
  global $xoopsDB,$xoopsTpl,$xoTheme,$ugmKind;
  //----------------------------------*/
  $_GET['ofsn']=!isset($_GET['ofsn'])?0:intval($_GET['ofsn']);
  //抓取預設值
  if(!empty($sn)){
    $DBV=$ugmKind->get_one_table_4_sn($sn);//get_ugm_module_tbl($sn,$ugmKind->get_tbl());//
  }else{
    $DBV=array();
  }
  //預設值設定
  //設定「kind_sn」欄位預設值
  $DBV['sn']=(!isset($DBV['sn']))?"":$DBV['sn'];

  //設定「kind_ofsn」欄位預設值
  $DBV['ofsn']=(!isset($DBV['ofsn']))?$_GET['ofsn']:$DBV['ofsn'];
  $DBV['ofsn_option']=$ugmKind->get_admin_form_ofsn_option($DBV['ofsn']);

  //設定「title」欄位預設值
  $DBV['title']=(!isset($DBV['title']))?"":$DBV['title'];

  //設定「enable」欄位預設值
  $DBV['enable']=(!isset($DBV['enable']))?"1":$DBV['enable'];

  //kind
  $DBV['kind']=(!isset($DBV['kind']))?$ugmKind->get_kind():$DBV['kind'];

  //設定「target」欄位預設值
  $DBV['target']=(!isset($DBV['target']))?"0":$DBV['target'];

  //設定「url」欄位預設值
  $DBV['url']=(!isset($DBV['url']))?"":$DBV['url'];

  //設定「col_sn」欄位預設值
  $DBV['col_sn']=(!isset($DBV['col_sn']))?"":$DBV['col_sn'];

  //設定「content」欄位預設值
  $DBV['content']=(!isset($DBV['content']))?"":$DBV['content'];

  $DBV['op']="op_insert";
  //----- 驗證碼 -----------------*/
  if(!file_exists(XOOPS_ROOT_PATH."/modules/tadtools/formValidator.php")){
   redirect_header("index.php",3, _TAD_NEED_TADTOOLS);
  }
  include_once XOOPS_ROOT_PATH."/modules/tadtools/formValidator.php";
  $formValidator= new formValidator("#myForm",true);
  $formValidator->render();
  //-------------------------------*/
  //$xoopsTpl->assign('javascript_code',$javascript_code);

  if($DBV['kind'] == "nav_icon"){
    #----fontawesome-iconpicker
    #CSS
    $xoTheme->addStylesheet(XOOPS_URL."/modules/tadtools/css/font-awesome/css/font-awesome.css");
    $xoTheme->addStylesheet(XOOPS_URL."/modules/ugm_tools/fontawesome/css/fontawesome-iconpicker.css");
    #JS
    $xoTheme->addScript(XOOPS_URL.'/modules/tadtools/bootstrap3/js/bootstrap.min.js');
    $xoTheme->addScript(XOOPS_URL.'/modules/ugm_tools/fontawesome/js/fontawesome-iconpicker.js');
    $DBV['js_code']="
      <script type='text/javascript'>
        $(document).ready(function(){
          $('.icp-auto').iconpicker(
          {
            icons: ['facebook', 'twitter', 'pinterest-square', 'dribbble','behance','rss','youtube','instagram','google-plus','linkedin','github'],
            selectedCustomClass: 'label label-success',
            placement: 'bottomRight'
          });
        });
      </script>
    ";
  }
  $xoopsTpl->assign('DBV',$DBV);
}


###############################################################################
#  列出所有類別的資料
###############################################################################
function op_list(){
  global $xoopsTpl,$xoTheme,$kind_arr,$ugmKind;
  # ----得到外鍵選單之選項 ----------------------------
  $kind_option="";
  foreach($kind_arr as $key=>$value){
    $selected="";
    if($ugmKind->get_kind()==$key){
      $selected=" selected";
    }
    $kind_option.="<option value='{$key}'{$selected}>{$value['title']}</option>";
  }
  $kind_form="
      <select name='kind' id='kind' onchange=\"location.href='?kind='+this.value\"  class='form-control' style='width:300px;'>
        $kind_option
      </select>
  ";
  #----------------------------------------------------
  $xoopsTpl->assign('kind_form',$kind_form);
  $xoopsTpl->assign('kind',$ugmKind->get_kind());
  # ----得到陣列 ----------------------------
  $ofsn=0;
  $level=1;
  $list=$ugmKind->get_admin_list_body($ofsn,$level);
  #-----驗證碼---------------------------------------------------------
  if(!file_exists(XOOPS_ROOT_PATH."/modules/tadtools/formValidator.php")){
   redirect_header("index.php",3, _TAD_NEED_TADTOOLS);
  }
  include_once XOOPS_ROOT_PATH."/modules/tadtools/formValidator.php";
  $formValidator= new formValidator("#myForm",true);
  $formValidator->render();
  //$formValidator_code=$formValidator->render();
  #-----驗證碼---------------------------------------------------------
  //$xoopsTpl->assign('js_code',$formValidator_code);

  if($ugmKind->get_kind() == "nav_icon"){
    #----fontawesome-iconpicker
    #CSS
    $xoTheme->addStylesheet(XOOPS_URL."/modules/tadtools/css/font-awesome/css/font-awesome.css");
    $xoTheme->addStylesheet(XOOPS_URL."/modules/ugm_tools/fontawesome/css/fontawesome-iconpicker.css");
    #JS
    $xoTheme->addScript(XOOPS_URL.'/modules/tadtools/bootstrap3/js/bootstrap.min.js');
    $xoTheme->addScript(XOOPS_URL.'/modules/ugm_tools/fontawesome/js/fontawesome-iconpicker.js');
    $DBV['js_code']="
      <script type='text/javascript'>
        $(document).ready(function(){
          $('.icp-auto').iconpicker(
          {
            icons: ['facebook', 'twitter', 'pinterest-square', 'dribbble','behance','rss','youtube','instagram','google-plus','linkedin','github'],
            selectedCustomClass: 'label label-success',
            placement: 'bottomRight'
          });
        });
      </script>
    ";

    $xoopsTpl->assign('DBV',$DBV);
  }

  $xoopsTpl->assign('list',$list);
}

###########################################################
#  新增、編輯資料
###########################################################
function op_insert(){
  global $xoopsDB,$ugmKind;
  //---- 過濾資料 -----------------------------------------*/
  $myts =& MyTextSanitizer::getInstance();
  #類別名稱
  $_POST['title']=$myts->addSlashes($_POST['title']);
  if(empty($_POST['title']))return false;
  #網址
  $_POST['url']=$myts->addSlashes($_POST['url']);
  #狀態
  $_POST['col_sn']=intval($_POST['col_sn']);
  #分類
  $_POST['kind']=$myts->addSlashes($_POST['kind']);
  #內容
  $_POST['content']=$myts->addSlashes($_POST['content']);
  #狀態
  $_POST['enable']=intval($_POST['enable']);
  #連結狀態
  $_POST['target']=intval($_POST['target']);
  #sn
  $_POST['sn']    =intval($_POST['sn']);
  #ofsn
  $_POST['ofsn']  =intval($_POST['ofsn']);
  //-------------------------------------------------------*/
  if($_POST['sn']){
    #編輯
    #--------檢查---------------------------
    $DBV=$ugmKind->get_one_table_4_sn($_POST['sn']);
    if($_POST['ofsn']!=$DBV['ofsn']){
      #類別有變動
      if($_POST['sn']==$_POST['ofsn']){
        redirect_header($_SERVER['PHP_SELF'],3,_MA_TREETABLE_MOVE_ERROR1);
      }elseif(($ugmKind->chk_kind_level_down($_POST['sn'])+$ugmKind->chk_kind_level($_POST['ofsn'])) > $ugmKind->get_stop_level()){
        redirect_header($_SERVER['PHP_SELF'],3,_MD_UGMMOUDEL_KIND_LEVEL_ERROR);
      }
    }
    #--------檢查結束---------------------------
    #
    $sql = "update ".$xoopsDB->prefix($ugmKind->get_tbl())." set
      `ofsn`   = '{$_POST['ofsn']}' ,
      `title`  = '{$_POST['title']}' ,
      `enable` = '{$_POST['enable']}',
      `target` = '{$_POST['target']}',
      `url` = '{$_POST['url']}',
      `col_sn` = '{$_POST['col_sn']}',
      `content` = '{$_POST['content']}'
      where sn='{$_POST['sn']}'";
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  }else{
    #---------新增------------------------
    #---------取得排序--------------------
    $sql="select max(sort)as max_sort
          from ".$xoopsDB->prefix($ugmKind->get_tbl())."
          where ofsn='{$_POST['ofsn']}' and kind='{$_POST['kind']}'";
    $sort=get_ugm_module_sql($sql);
    $sort['max_sort']++;
    #---------寫入-------------------------
    $sql = "insert into ".$xoopsDB->prefix($ugmKind->get_tbl())."
    (`ofsn` ,`title` , `enable` , `sort`,`kind`,`target`,`url`,`col_sn`,`content`)
    values('{$_POST['ofsn']}' , '{$_POST['title']}' ,'{$_POST['enable']}' , '{$sort['max_sort']}' , '{$_POST['kind']}', '{$_POST['target']}', '{$_POST['url']}', '{$_POST['col_sn']}', '{$_POST['content']}')";
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
    //取得最後新增資料的流水編號
    $_POST['sn'] = $xoopsDB->getInsertId();
  }
  return $_POST['sn'];
}

###############################################################################
#  更新啟用
###############################################################################
function op_update_enable(){
  global $xoopsDB,$ugmKind;
  #權限
  /***************************** 過瀘資料 *************************/
  $enable=intval($_GET['enable']);
  $sn=intval($_GET['sn']);
  /****************************************************************/
  //更新
  $sql = "update ".$xoopsDB->prefix($ugmKind->get_tbl())." set  `enable` = '{$enable}' where `sn`='{$sn}'";
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  return ;
}
###############################################################################
#  更新外連
###############################################################################
function op_update_target(){
  global $xoopsDB,$ugmKind;
  #權限
  /***************************** 過瀘資料 *************************/
  $target=intval($_GET['target']);
  $sn=intval($_GET['sn']);
  /****************************************************************/
  //更新
  $sql = "update ".$xoopsDB->prefix($ugmKind->get_tbl())." set  `target` = '{$target}' where `sn`='{$sn}'";
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  return ;
}
###############################################################################
#  移動類別儲存
###############################################################################
function op_save_drag(){
  global $xoopsDB,$ugmKind;
  //$ofsn=intval(str_replace("tr_","",$_POST['ofsn']));
  //$sn=intval(str_replace("tr_","",$_POST['sn']));
  $ofsn=intval($_POST['ofsn']);//目的
  $sn=intval($_POST['sn']);//來源
  if(!$sn){
    #根目錄不可移動
    die(_MD_UGMMOUDEL_KIND_ROOT_ERROR."(".date("Y-m-d H:i:s").")"._BP_F5);
  }elseif($ofsn==$sn){
    #自己移至自己
    die(_MA_TREETABLE_MOVE_ERROR1."(".date("Y-m-d H:i:s").")"._BP_F5);
  }elseif($ugmKind->chk_kind_level($ofsn) + $ugmKind->chk_kind_level_down($sn) > $ugmKind->get_stop_level()){
    #自己往底層移動或自己底下層數+目的所在層數 > 類別層數
    die(_MD_UGMMOUDEL_KIND_LEVEL_ERROR."(".date("Y-m-d H:i:s").")"._BP_F5);
  }

  $sql="update ".$xoopsDB->prefix($ugmKind->get_tbl())."
        set `ofsn`='{$ofsn}' where `sn`='{$sn}'";
  $xoopsDB->queryF($sql) or die("Reset Fail! (".date("Y-m-d H:i:s").")");

  return "Reset OK! (".date("Y-m-d H:i:s").")"._BP_F5;
}

###########################################################
#  批次編輯資料
###########################################################
function op_all_insert(){
  global $xoopsDB,$ugmKind;
  //---- 過濾資料 -----------------------------------------*/
  $myts =& MyTextSanitizer::getInstance();
  foreach($_POST['title'] as $sn=>$title){
    $title=$myts->addSlashes($title);
    $sn=intval($sn);#編輯
    $url=$myts->addSlashes($_POST['url'][$sn]);
    $col_sn=intval($_POST['col_sn'][$sn]);
    $sql = "update ".$xoopsDB->prefix($ugmKind->get_tbl())." set
           `title` = '{$title}',
           `url` = '{$url}',
           `col_sn` = '{$col_sn}'
           where sn='{$sn}'";
    $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
  }
}
###############################################################################
#  刪除資料
###############################################################################
function op_delete($sn=""){
  global $xoopsDB,$ugmKind;
  if(empty($sn))redirect_header($_SERVER['PHP_SELF'],3, _BP_DEL_ERROR);
  #檢查是否有子類別
  if ($ugmKind->check_sub_kind($sn)) redirect_header($_SERVER['PHP_SELF'],3, _MD_UGMMOUDEL_KIND_HAVE_SUB_NOT_DEL);
  $sql = "delete from ".$xoopsDB->prefix($ugmKind->get_tbl())."
          where sn='{$sn}'";//die($sql);
  $xoopsDB->queryF($sql) or redirect_header($_SERVER['PHP_SELF'],3, mysql_error());
}
###############################################################################
#  自動更新排序
###############################################################################
function op_update_sort(){
  global $xoopsDB,$ugmKind;
  $sort=1;
  foreach ($_POST['tr'] as $sn) {
    if(!$sn)continue;
    $sql="update ".$xoopsDB->prefix($ugmKind->get_tbl())." set `sort`='{$sort}' where `sn`='{$sn}'";
    $xoopsDB->queryF($sql) or die("Save Sort Fail! (".date("Y-m-d H:i:s").")");
    $sort++;
  }
  return "Save Sort OK! (".date("Y-m-d H:i:s").")"._BP_F5;
}



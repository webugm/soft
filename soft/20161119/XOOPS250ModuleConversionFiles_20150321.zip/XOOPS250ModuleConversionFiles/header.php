<?php
//載入XOOPS主設定檔（必要）
include_once "../../mainfile.php";
//載入自訂的共同函數檔
include_once "function.php";
//載入工具選單設定檔
include_once "interface_menu.php";
?>
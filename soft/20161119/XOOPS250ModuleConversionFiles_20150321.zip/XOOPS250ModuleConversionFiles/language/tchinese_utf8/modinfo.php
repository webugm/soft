<?php
include_once XOOPS_ROOT_PATH."/modules/tadtools/language/{$xoopsConfig['language']}/modinfo_common.php";

define("_MI_XXX_ADMENU1" , "主管理頁");
define("_MI_XXX_ADMENU1_DESC" , "後台主管理頁");
?>
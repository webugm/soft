<?php
include_once XOOPS_ROOT_PATH."/modules/tadtools/language/{$xoopsConfig['language']}/modinfo_common.php";

define("_MI_XXX_ADMENU1" , "Main");
define("_MI_XXX_ADMENU1_DESC" , "Admin main page");
?>
<?php
/* Smarty version 3.1.29, created on 2016-11-16 21:20:46
  from "D:\ugm\UniServerZ\www\smarty_02\templates\default\tpl\creative_slider.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_582c5d2e023f07_31488060',
  'file_dependency' => 
  array (
    'b58774d76ae044af10d06fa247b8b24e3d83827c' => 
    array (
      0 => 'D:\\ugm\\UniServerZ\\www\\smarty_02\\templates\\default\\tpl\\creative_slider.html',
      1 => 1479302184,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_582c5d2e023f07_31488060 ($_smarty_tpl) {
?>
<header>
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Your Favorite Source of Free Bootstrap Themes</h1>
            <hr>
            <p>Start Bootstrap can help you build better websites using the Bootstrap CSS framework! Just download your template and start going, no strings attached!</p>
            <a href="#about" class="btn btn-primary btn-xl page-scroll">Find Out More</a>
        </div>
    </div>
</header><?php }
}

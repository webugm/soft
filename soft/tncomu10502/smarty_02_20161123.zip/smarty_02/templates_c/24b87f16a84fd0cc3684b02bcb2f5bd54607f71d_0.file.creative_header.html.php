<?php
/* Smarty version 3.1.29, created on 2016-11-23 19:17:41
  from "D:\ugm\UniServerZ\www\smarty_02\templates\default\tpl\creative_header.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58357ad58ba606_75880116',
  'file_dependency' => 
  array (
    '24b87f16a84fd0cc3684b02bcb2f5bd54607f71d' => 
    array (
      0 => 'D:\\ugm\\UniServerZ\\www\\smarty_02\\templates\\default\\tpl\\creative_header.html',
      1 => 1479705214,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58357ad58ba606_75880116 ($_smarty_tpl) {
?>
<header>
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Your Favorite Source of Free Bootstrap Themes</h1>
            <hr>
            <p>Start Bootstrap can help you build better websites using the Bootstrap CSS framework! Just download your template and start going, no strings attached!</p>
            <a href="#about" class="btn btn-primary btn-xl page-scroll">Find Out More</a>
        </div>
    </div>
</header><?php }
}

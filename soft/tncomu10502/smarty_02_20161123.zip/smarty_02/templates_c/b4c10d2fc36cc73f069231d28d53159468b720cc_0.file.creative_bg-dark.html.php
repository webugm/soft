<?php
/* Smarty version 3.1.29, created on 2016-11-23 19:17:41
  from "D:\ugm\UniServerZ\www\smarty_02\templates\default\tpl\creative_bg-dark.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58357ad5a83681_38489189',
  'file_dependency' => 
  array (
    'b4c10d2fc36cc73f069231d28d53159468b720cc' => 
    array (
      0 => 'D:\\ugm\\UniServerZ\\www\\smarty_02\\templates\\default\\tpl\\creative_bg-dark.html',
      1 => 1479705290,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58357ad5a83681_38489189 ($_smarty_tpl) {
?>
<aside class="bg-dark">
    <div class="container text-center">
        <div class="call-to-action">
            <h2>Free Download at Start Bootstrap!</h2>
            <a href="http://startbootstrap.com/template-overviews/creative/" class="btn btn-default btn-xl sr-button">Download Now!</a>
        </div>
    </div>
</aside><?php }
}

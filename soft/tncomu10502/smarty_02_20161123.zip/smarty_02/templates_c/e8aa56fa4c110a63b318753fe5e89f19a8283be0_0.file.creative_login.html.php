<?php
/* Smarty version 3.1.29, created on 2016-11-23 20:57:14
  from "D:\ugm\UniServerZ\www\smarty_02\templates\default\tpl\creative_login.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5835922aeffd86_67014582',
  'file_dependency' => 
  array (
    'e8aa56fa4c110a63b318753fe5e89f19a8283be0' => 
    array (
      0 => 'D:\\ugm\\UniServerZ\\www\\smarty_02\\templates\\default\\tpl\\creative_login.html',
      1 => 1479905828,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5835922aeffd86_67014582 ($_smarty_tpl) {
?>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Please Sign In</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="POST" action="admin.php">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="帳號" name="uname" type="text" autofocus id="uname">
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="password" type="password" value="">
                            </div>
                            <div class="checkbox">
                                <label>
                                    <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                </label>
                            </div>
                            <input type="hidden" name="op" value="op_login">

                            <!-- Change this to a button or input when using this as a form -->
                            <button  class="btn btn-lg btn-success btn-block">Login</button>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php }
}

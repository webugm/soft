<?php
/* Smarty version 3.1.29, created on 2016-11-21 13:16:59
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_02\templates\default\tpl\creative_header.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5832834b12a488_33311777',
  'file_dependency' => 
  array (
    'b48d2c801a780176ecbbe63b77a48755c390129b' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_02\\templates\\default\\tpl\\creative_header.html',
      1 => 1479705213,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5832834b12a488_33311777 ($_smarty_tpl) {
?>
<header>
    <div class="header-content">
        <div class="header-content-inner">
            <h1 id="homeHeading">Your Favorite Source of Free Bootstrap Themes</h1>
            <hr>
            <p>Start Bootstrap can help you build better websites using the Bootstrap CSS framework! Just download your template and start going, no strings attached!</p>
            <a href="#about" class="btn btn-primary btn-xl page-scroll">Find Out More</a>
        </div>
    </div>
</header><?php }
}

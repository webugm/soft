<?php
/* Smarty version 3.1.29, created on 2016-11-23 19:17:41
  from "D:\ugm\UniServerZ\www\smarty_02\templates\default\tpl\creative_portfolio.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58357ad5a48d01_02331027',
  'file_dependency' => 
  array (
    '50a0e910e5d2eb926130e3c516e93bdd1fe9a9fa' => 
    array (
      0 => 'D:\\ugm\\UniServerZ\\www\\smarty_02\\templates\\default\\tpl\\creative_portfolio.html',
      1 => 1479705266,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58357ad5a48d01_02331027 ($_smarty_tpl) {
?>
<section class="no-padding" id="portfolio">
    <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/1.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/1.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/2.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/2.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/3.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/3.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/4.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/4.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/5.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/5.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/6.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/6.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section><?php }
}

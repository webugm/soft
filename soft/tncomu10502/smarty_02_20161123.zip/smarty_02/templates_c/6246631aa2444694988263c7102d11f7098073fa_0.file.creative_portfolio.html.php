<?php
/* Smarty version 3.1.29, created on 2016-11-21 13:16:59
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_02\templates\default\tpl\creative_portfolio.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5832834b387c86_89491681',
  'file_dependency' => 
  array (
    '6246631aa2444694988263c7102d11f7098073fa' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_02\\templates\\default\\tpl\\creative_portfolio.html',
      1 => 1479705264,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5832834b387c86_89491681 ($_smarty_tpl) {
?>
<section class="no-padding" id="portfolio">
    <div class="container-fluid">
        <div class="row no-gutter popup-gallery">
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/1.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/1.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/2.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/2.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/3.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/3.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/4.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/4.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/5.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/5.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/fullsize/6.jpg" class="portfolio-box">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/img/portfolio/thumbnails/6.jpg" class="img-responsive" alt="">
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content">
                            <div class="project-category text-faded">
                                Category
                            </div>
                            <div class="project-name">
                                Project Name
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section><?php }
}

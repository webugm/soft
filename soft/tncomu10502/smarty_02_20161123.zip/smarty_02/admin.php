<?php
/*---- 必須引入----*/
require_once 'head.php';
$WEB['title'] = "首頁";
#程式流程

#整理傳入變數
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
 

 
#程式流程
switch ($op) {
#登入
case "op_login":  
  #判斷帳密，若正確則轉至 admin/index.php,若不正確則繼續輸入密碼
  if (op_login()) {
    $_SESSION['admin'] = true;
    header("location:admin/index.php");
    exit;
  }
  break;
#登出
case "op_logout":
   
  break;
#----
 
//預設動作
default:
   
  break;
}





/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);

/*---- 程式結尾-----*/
$smarty->display('theme.html');
/*---- 函數區-----*/

#################################
# 使用者登入判斷
# 帳、密正確，返回 true 、不正確 返回 false
#################################
function op_login() {
  global $mysqli;
  #過濾傳入變數
  $_POST['uname'] = $mysqli->real_escape_string($_POST['uname']);
  $_POST['password'] = $mysqli->real_escape_string($_POST['password']);
  //print_r($_POST);die();
  if ($_POST['uname'] == "admin" and $_POST['password'] == "123456") {
    return true;
  }
  return false;
}



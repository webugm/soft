<?php
require_once 'head.php';
$WEB['title'] = "更新管理";
#程式流程
#
#整理傳入變數
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
$sn = isset($_REQUEST['sn']) ? intval($_REQUEST['sn']) : "";
 
#程式流程
switch ($op) {
#更新
default:
  $op = "op_list";
  $msg = op_list();
 
  if ($msg) {
    redirect_header("index.php", 3000, "更新系統成功！！");
  } else {
    redirect_header("index.php", 3000, "更新系統失敗！！");
  }
  exit;
  break;
}
 
/*---- 將變數送至樣版----*/
// $smarty->assign("WEB", $WEB);
// $smarty->assign("op", $op);
 
// /*---- 程式結尾-----*/
// $smarty->display('theme.html');
#函數
 
########################################
# 更新主程式
########################################
function op_list() {
  global $mysqli;
  #檢查資料夾
  mk_dir(WEB_PATH . "/uploads");
 
  //-------- 資料表 ------
  #檢查資料表(creative_nav)
  if (!chk_isTable("creative_nav")) {
    $sql = "
      CREATE TABLE creative_nav (
        `sn` smallint(5) unsigned NOT NULL auto_increment comment 'sn',
        `ofsn` smallint(5) unsigned NOT NULL default 0 comment '父類別',
        `kind` varchar(255) NOT NULL default 'nav_home' comment '分類',
        `title` varchar(255) NOT NULL default '' comment '標題',
        `sort` smallint(5) unsigned NOT NULL default 0 comment '排序',
        `enable` enum('1','0') NOT NULL default '1' comment '狀態',
        `url` varchar(255) NOT NULL default '' comment '網址',
        `target` enum('1','0') NOT NULL default '0' comment '外連',
        `col_sn` int(10) unsigned NOT NULL default 0 comment 'col_sn',
        `content` text NOT NULL comment '內容',
        PRIMARY KEY  (`sn`)
      ) ENGINE=MyISAM;
    ";
    createTable($sql);
  }
 
  #檢查資料表(creative_system)
  if (!chk_isTable("creative_system")) {
    $sql = "
      CREATE TABLE `creative_system` (
        `sn` smallint(5) unsigned NOT NULL AUTO_INCREMENT comment 'sn',
        `name` varchar(255) NOT NULL DEFAULT '' comment '表單名稱',
        `kind` varchar(255) NOT NULL default 'system' comment '類別',
        `title` varchar(255) NOT NULL DEFAULT '' comment '標題',
        `value` text  comment '值',
        `description` varchar(255) NOT NULL DEFAULT '' comment '描述',
        `formtype` varchar(255) NOT NULL DEFAULT '' comment '表單型態',
        `valuetype` varchar(255) NOT NULL DEFAULT '' comment '值的型態',
        `sort` smallint(5) unsigned NOT NULL DEFAULT '0' comment '排序',
        `enable` enum('1','0') NOT NULL default '1' comment '狀態',
        PRIMARY KEY (`sn`)
      ) ENGINE=MyISAM;";
    createTable($sql);
  }
 
  #檢查資料表(creative_files_center)
  if (!chk_isTable("creative_files_center")) {
    $sql = "
      CREATE TABLE `creative_files_center` (
      `files_sn` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '檔案流水號',
      `col_name` varchar(255) NOT NULL default '' COMMENT '欄位名稱',
      `col_sn` smallint(5) unsigned NOT NULL default 0 COMMENT '欄位編號',
      `sort` smallint(5) unsigned NOT NULL default 0 COMMENT '排序',
      `kind` enum('img','file') NOT NULL default 'img' COMMENT '檔案種類',
      `file_name` varchar(255) NOT NULL default '' COMMENT '檔案名稱',
      `file_type` varchar(255) NOT NULL default '' COMMENT '檔案類型',
      `file_size` int(10) unsigned NOT NULL default 0 COMMENT '檔案大小',
      `description` text NOT NULL COMMENT '檔案說明',
      `counter` mediumint(8) unsigned NOT NULL default 0 COMMENT '下載人次',
      `original_filename` varchar(255) NOT NULL default '' COMMENT '檔案名稱',
      `hash_filename` varchar(255) NOT NULL default '' COMMENT '加密檔案名稱',
      `sub_dir` varchar(255) NOT NULL default '' COMMENT '檔案子路徑',
      PRIMARY KEY (`files_sn`)
      ) ENGINE=MyISAM;";
    createTable($sql);
  }
  //-------- 資料表 end------
 
  //-------- 欄位 ------
  // if (!chk_isColumn("sn1", "creative_system")) {
  //  $sql = "ALTER TABLE `creative_system` ADD `sn1` smallint(5) unsigned NOT NULL default 0 comment 'sn1'"; //die($sql);
  //  addColumn($sql);
  // }
  //-------- 欄位 end------
 
  //-------- 系統變數 -----
  go_update();
  //-------- 系統變數 end--
  return true;
}
 
########################################
# 將預設系統項目寫入資料庫.
# formtype
#   textbox => 單行
#   textarea => 多行
#   file => 檔案  => valuetype
#                      single_img =>單圖
#                      multiple_img => 多圖
########################################
function go_update() {
  global $mysqli;
 
  $i = 0;
  #---- meta ----
  #關鍵字
  $configs['meta'][$i]['name'] = 'system_meta_keywords';
  $configs['meta'][$i]['title'] = '關鍵字';
  $configs['meta'][$i]['description'] = '請用半型逗點隔開';
  $configs['meta'][$i]['formtype'] = 'textbox';
  $configs['meta'][$i]['valuetype'] = 'text';
  $configs['meta'][$i]['default'] = "關鍵字,關鍵字"; //
  #關鍵字
  $i++;
  $configs['meta'][$i]['name'] = 'system_meta_description';
  $configs['meta'][$i]['title'] = '網頁描述';
  $configs['meta'][$i]['description'] = '網頁描述';
  $configs['meta'][$i]['formtype'] = 'textarea';
  $configs['meta'][$i]['valuetype'] = 'text';
  $configs['meta'][$i]['default'] = ""; //
  #作者名稱
  $i++;
  $configs['meta'][$i]['name'] = 'system_meta_author';
  $configs['meta'][$i]['title'] = '作者名稱';
  $configs['meta'][$i]['description'] = '作者名稱';
  $configs['meta'][$i]['formtype'] = 'textbox';
  $configs['meta'][$i]['valuetype'] = 'text';
  $configs['meta'][$i]['default'] = "郭俊良"; //
  #作者名稱
  $i++;
  $configs['meta'][$i]['name'] = 'system_meta_copyright';
  $configs['meta'][$i]['title'] = '版權所有人名稱';
  $configs['meta'][$i]['description'] = '版權所有人名稱';
  $configs['meta'][$i]['formtype'] = 'textbox';
  $configs['meta'][$i]['valuetype'] = 'text';
  $configs['meta'][$i]['default'] = "育將電腦工作室"; //
  #FB要顯示的縮圖
  $i++;
  $configs['meta'][$i]['name'] = 'system_meta_og_image';
  $configs['meta'][$i]['title'] = 'FB要顯示的縮圖';
  $configs['meta'][$i]['description'] = 'FB要顯示的縮圖';
  $configs['meta'][$i]['formtype'] = 'file';
  $configs['meta'][$i]['valuetype'] = 'single_img';
  $configs['meta'][$i]['default'] = ""; //
  #輪播圖
  $i++;
  $configs['slider'][$i]['name'] = 'system_slider_image';
  $configs['slider'][$i]['title'] = '輪播圖';
  $configs['slider'][$i]['description'] = '輪播圖';
  $configs['slider'][$i]['formtype'] = 'file';
  $configs['slider'][$i]['valuetype'] = 'multiple_img';
  $configs['slider'][$i]['default'] = "1920"; //
 
  #寫入
 
  //sn  ofsn  title sort  enable  kind  url target 
  foreach ($configs as $kind => $config_one) {
    foreach ($config_one as $sort => $config) {
      if (!check_system_nameKind($config['name'], $kind)) {
 
        $config['default'] = $mysqli->real_escape_string($config['default']);
 
        $sql = "insert into `creative_system`
              (`name`,`title`,`value`,`description`,`formtype`,`valuetype`,`sort`,`enable`,`kind`) values
              ('{$config['name']}','{$config['title']}','{$config['default']}','{$config['description']}','{$config['formtype']}','{$config['valuetype']}','{$sort}','1','{$kind}')"; //die($sql);
        $mysqli->query($sql) or redirect_header("index.php", 3000, "更新系統失敗！！");
 
      }
    }
  }
  #------------------------------
  return true;
}
 
########################################
# 檢查creative_system是否有變數
########################################
function check_system_nameKind($name, $kind) {
  global $mysqli;
  $sql = "select sn
          from `creative_system`
          where name='{$name}' and kind='{$kind}'"; //die($sql);
  $result = $mysqli->query($sql);
  
  list($sn) = $result->fetch_row();
  if (empty($sn)) {
    return false;
  }
 
  return true;
}
 
########################################
# 建立資料表
########################################
function createTable($sql) {
  global $mysqli;
  $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
  return true;
}
 
########################################
# 在資料表show_kind 增加一個 sn1 欄位
########################################
 
function addColumn($sql) {
  global $mysqli;
  $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
  return true;
}
 
########################################
# 檢查某欄位是否存在(欄名,資料表)
########################################
function chk_isColumn($col_name = "", $tbl_name = "") {
  global $mysqli;
  if (!$col_name and $tbl_name) {
    return;
  }
 
  //SHOW COLUMNS FROM `show_kind` LIKE 'sn1'
  $sql = "SHOW COLUMNS FROM `{$tbl_name}` LIKE '{$col_name}'";
  $result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
  if ($result->num_rows) {
    return true;
  }
  //欄位存在
  return false; //欄位不存在
}
 
########################################
# 檢查資料表是否存在(資料表)
########################################
function chk_isTable($tbl_name = "") {
  global $mysqli;
  if (!$tbl_name) {
    return;
  }
 
  $sql = "SHOW TABLES LIKE '{$tbl_name}'"; //die($sql);
 
  $result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
 
  if ($result->num_rows) {
    return true;
  }
  //欄位存在
  return false; //欄位不存在
}
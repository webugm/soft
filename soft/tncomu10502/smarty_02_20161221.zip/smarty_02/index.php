<?php
/*---- 必須引入----*/
require_once 'head.php';
$WEB['title'] = "首頁";
#程式流程

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);

/*---- 程式結尾-----*/
$smarty->display('theme.html');
/*---- 函數區-----*/


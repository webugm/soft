<?php
/*
1. head.php為前台每個程式都會引入的檔案
2. 所有檔案都必須執行的流程，請放到這裡
3. smarty_01
 */
session_start(); //啟用 $_SESSION,前面不可以有輸出
error_reporting(E_ALL);@ini_set('display_errors', true); //設定所有錯誤都顯示
$http = 'http://';
if (!empty($_SERVER['HTTPS'])) {
	$http = ($_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
}

$_SESSION['admin'] = isset($_SESSION['admin'])?$_SESSION['admin']:"";

#網站實體路徑
define('WEB_PATH', str_replace("\\", "/", dirname(__FILE__)));
#網站URL
define('WEB_URL', $http . $_SERVER["HTTP_HOST"] . str_replace($_SERVER["DOCUMENT_ROOT"], "", WEB_PATH));

#佈景目錄
$WEB['theme_name'] = "default";

#程式檔名(含副檔名)
$WEB['file_name'] = basename($_SERVER['PHP_SELF']); //index.php
//print_r($WEB['file_name']) ;die();
//basename(__FILE__)

/*---- 必須引入----*/
#引入樣板引擎
require_once 'smarty.php';
#引入資料庫設定
require_once 'sqlConfig.php';
#引入共用函數
require_once 'function.php';

$_SESSION['redirect']=isset($_SESSION['redirect'])?$_SESSION['redirect']:"";
$smarty->assign("redirect", $_SESSION['redirect']);
$_SESSION['redirect']="";

nav_home();

#################################
# 選單列表程式
#
#################################
function nav_home() {
  global $mysqli, $smarty;
 
  #取得所有記錄
  $sql = "select sn,title,url,target 
  		  from `creative_nav`
          where `kind`='nav_home' and `enable`='1' 
          order by `sort` "; //die($sql);
 
  $result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
 
  $rows = array();
  while ($row = $result->fetch_assoc()) {
    #過濾撈出資料
    
    //Array ( [sn] => 3 [ofsn] => 0 [kind] => nav_home [title] => asdfasdf [sort] => 0 [enable] => 1 [url] => asdfasdf [target] => 0 [col_sn] => 0 [content] => )
    $row['sn'] = intval($row['sn']);
    //http://www.w3school.com.cn/php/func_string_htmlspecialchars.asp
    $row['title'] = htmlspecialchars($row['title'], ENT_QUOTES); // 轉換雙引號和單引號
    $row['url'] = htmlspecialchars($row['url'], ENT_QUOTES); // 轉換雙引號和單引號
    $row['target'] = intval($row['target']);
 
    $rows[] = $row;
  }
  //print_r($rows);die();

  $smarty->assign("rows", $rows);
  return;
}
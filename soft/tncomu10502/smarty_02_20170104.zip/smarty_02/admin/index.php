<?php
/*---- 必須引入----*/
require_once 'head.php';
$WEB['title'] = "選單管理";
#程式流程
#
#整理傳入變數
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
$sn = isset($_REQUEST['sn']) ? intval($_REQUEST['sn']) : "";
 
#程式流程
switch ($op) {
#新增(Create)
case "op_insert":
  op_insert();
  redirect_header($_SESSION['op_list'], 3000, '新增資料成功！！');
  exit;
  break;
 
#更新(Update)
case "op_update":
  op_update($sn);
  redirect_header($_SESSION['op_list'], 3000, '編輯資料成功！！');
  exit;
  break;
 
#刪除(Delete)
case "op_delete":
  op_delete($sn);
  redirect_header($_SESSION['op_list'], 3000, '刪除資料成功！！');
  exit;
  break;
 
#顯示單筆(Read)
case "op_show":
  op_show($sn);
  break;
 
#表單
case "op_form":
  op_form($sn);
  break;
 
#讀取(Read)
default:
  $op = "op_list";
  $_SESSION['op_list'] = getCurrentUrl();
  op_list();
 
  break;
}
/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);
 
/*---- 程式結尾-----*/
$smarty->display('theme.html');
/*---- 函數區-----*/
#################################
# 新增資料
#
#################################
function op_insert() {
  global $mysqli;
 
  #資料過濾
  #http://php.net/manual/en/mysqli.real-escape-string.php
  $_POST['title'] = $mysqli->real_escape_string($_POST['title']);
  $_POST['target'] = intval($_POST['target']);
  $_POST['enable'] = intval($_POST['enable']);
  $_POST['sort'] = intval($_POST['sort']);
  $_POST['url'] = $mysqli->real_escape_string($_POST['url']);
  $_POST['kind'] = $mysqli->real_escape_string($_POST['kind']);
 
  $sql = "insert into `creative_nav`
          (`title`, `target`, `enable`, `sort`,`url`,`kind`)
          VALUES
          ('{$_POST['title']}', '{$_POST['target']}', '{$_POST['enable']}', '{$_POST['sort']}', '{$_POST['url']}', '{$_POST['kind']}')";//die($sql);
 
  $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
 
  $sn = $mysqli->insert_id; //傳回insert 指令所產生之流水號
 
  return $sn;
}
#################################
# 更新資料
#
#################################
function op_update($sn = "") {
  global $mysqli;
  if (!$sn) {
    redirect_header("index.php", 3000, "更新記錄錯誤！！");
  }
 
  #資料過濾
  $_POST['sn'] = intval($_POST['sn']);
  $_POST['title'] = $mysqli->real_escape_string($_POST['title']);
  $_POST['target'] = intval($_POST['target']);
  $_POST['enable'] = intval($_POST['enable']);
  $_POST['sort'] = intval($_POST['sort']);
  $_POST['url'] = $mysqli->real_escape_string($_POST['url']);
 
  $sql = "update `creative_nav` set
          `title`  = '{$_POST['title']}' ,
          `target` = '{$_POST['target']}',
          `enable` = '{$_POST['enable']}',
          `url` = '{$_POST['url']}',
          `sort` = '{$_POST['sort']}'
          where sn='{$_POST['sn']}'";
 
  $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
 
  return $sn;
}
#################################
# 刪除資料
#
#################################
function op_delete($sn = "") {
  global $mysqli;
  if (!$sn) {
    redirect_header("index.php", 3000, "刪除記錄錯誤！！");
  }
  #
  $sql = "delete
          from `creative_nav`
          where `sn`='{$sn}'"; //die($sql);
  $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
  return;
}
#################################
# 顯示單筆
#
#################################
function op_show($sn = "") {
 
}

#################################
# 表單
# 選單關鍵字 nav_home
#################################
function op_form($sn = "") {
  global $mysqli, $smarty;
 
  #取得預設值
  if ($sn) {
    #編輯
    $row = get_creative_nav($sn); //取得單筆記錄
    $row['op'] = "op_update";
    $row['form_title'] = "編輯選單";
  } else {
    #新增
    $row = array();
    $row['op'] = "op_insert";
    $row['form_title'] = "新增選單";
  }
 
  #預設值設定
  $row['sn'] = (isset($row['sn'])) ? $row['sn'] : "";
  $row['title'] = (isset($row['title'])) ? $row['title'] : "";
  $row['enable'] = (isset($row['enable'])) ? $row['enable'] : 1;
  $row['target'] = (isset($row['target'])) ? $row['target'] : 0;
  $row['url'] = (isset($row['url'])) ? $row['url'] : "";
  $row['sort'] = (isset($row['sort'])) ? $row['sort'] : 0;
  $row['kind'] = (isset($row['kind'])) ? $row['kind'] : "nav_home";
 
  #把變數送至樣板
  $smarty->assign("row", $row);
}
#################################
# 列表程式
#
#################################
function op_list() {
  global $mysqli, $smarty;
 
  #取得所有記錄
  $sql = "select *
          from `creative_nav`
          where `kind`='nav_home'
          order by `sort` "; //die($sql);
 
  $result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
 
  $rows = array();
  while ($row = $result->fetch_assoc()) {
    #過濾撈出資料
    
    //Array ( [sn] => 3 [ofsn] => 0 [kind] => nav_home [title] => asdfasdf [sort] => 0 [enable] => 1 [url] => asdfasdf [target] => 0 [col_sn] => 0 [content] => )
    $row['sn'] = intval($row['sn']);
    //http://www.w3school.com.cn/php/func_string_htmlspecialchars.asp
    $row['title'] = htmlspecialchars($row['title'], ENT_QUOTES); // 轉換雙引號和單引號
    $row['url'] = htmlspecialchars($row['url'], ENT_QUOTES); // 轉換雙引號和單引號
    $row['sort'] = intval($row['sort']);
    $row['enable'] = intval($row['enable']);
    $row['target'] = intval($row['target']);
 
    $rows[] = $row;
  }

  $smarty->assign("rows", $rows);
  return;
}

########################################
#取得單筆記錄
########################################
function get_creative_nav($sn = "") {
  global $mysqli;
  if (!$sn) {
    redirect_header("index.php", 3000, "查詢選單資料錯誤！！");
  }
 
  $sql = "select *
          from `creative_nav`
          where `sn`='{$sn}' and `kind`= 'nav_home'";
  $result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
  $row = $result->fetch_assoc();
 
  #過濾撈出資料
  $row['sn'] = intval($row['sn']);
  //http://www.w3school.com.cn/php/func_string_htmlspecialchars.asp
  $row['title'] = htmlspecialchars($row['title'], ENT_QUOTES); // 轉換雙引號和單引號
  $row['url'] = htmlspecialchars($row['url'], ENT_QUOTES); // 轉換雙引號和單引號
  $row['sort'] = intval($row['sort']);
  $row['enable'] = intval($row['enable']);
  $row['target'] = intval($row['target']);
 
  return $row;
}
<?php

###############################################################################
#  轉向函數
###############################################################################
function redirect_header($url = "", $time = 3000, $message = '已轉向！！') {
	$_SESSION['redirect'] = "\$.jGrowl('{$message}', {  life:{$time} , position: 'center', speed: 'slow' });";
	header("location:{$url}");
	exit;
}

###############################################################################
#  取得目前網址
###############################################################################
if (!function_exists("getCurrentUrl")) {
	function getCurrentUrl() {
		global $_SERVER;
		$protocol = strpos(strtolower($_SERVER['SERVER_PROTOCOL']), 'https') === FALSE ? 'http' : 'https';
		$host = $_SERVER['HTTP_HOST'];
		$script = $_SERVER['SCRIPT_NAME'];
		$params = $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : "";

		$currentUrl = $protocol . '://' . $host . $script . $params;
		return $currentUrl;
	}
}

###############################################################################
#  獲得填報者ip
###############################################################################
if (!function_exists("getVisitorsAddr")) {
	function getVisitorsAddr() {
		if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
			$ip = $_SERVER["HTTP_CLIENT_IP"];
		} elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
			$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		} else {
			$ip = $_SERVER["REMOTE_ADDR"];
		}
		return $ip;
	}
}

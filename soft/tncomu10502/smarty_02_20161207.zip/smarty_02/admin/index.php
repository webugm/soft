<?php
/*---- 必須引入----*/
require_once 'head.php';
$WEB['title'] = "選單管理";
#程式流程
#
#整理傳入變數
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
$sn = isset($_REQUEST['sn']) ? intval($_REQUEST['sn']) : "";
 
#程式流程
switch ($op) {
#新增(Create)
case "op_insert":
  op_insert();
  redirect_header($_SESSION['op_list'], 3000, '新增資料成功！！');
  exit;
  break;
 
#更新(Update)
case "op_update":
  op_update($sn);
  redirect_header($_SESSION['op_list'], 3000, '編輯資料成功！！');
  exit;
  break;
 
#刪除(Delete)
case "op_delete":
  op_delete($sn);
  redirect_header($_SESSION['op_list'], 3000, '刪除資料成功！！');
  exit;
  break;
 
#顯示單筆(Read)
case "op_show":
  op_show($sn);
  break;
 
#表單
case "op_form":
  op_form($sn);
  break;
 
#讀取(Read)
default:
  $op = "op_list";
  $_SESSION['op_list'] = getCurrentUrl();
  op_list();
 
  break;
}
/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);
 
/*---- 程式結尾-----*/
$smarty->display('theme.html');
/*---- 函數區-----*/
#################################
# 新增資料
#
#################################
function op_insert() {
 
}
#################################
# 更新資料
#
#################################
function op_update($sn = "") {
 
}
#################################
# 刪除資料
#
#################################
function op_delete($sn = "") {
 
}
#################################
# 顯示單筆
#
#################################
function op_show($sn = "") {
 
}

#################################
# 表單
# 選單關鍵字 nav_home
#################################
function op_form($sn = "") {
  global $mysqli, $smarty;
 
  #取得預設值
  if ($sn) {
    #編輯
    $row = get_creative_nav($sn); //取得單筆記錄
    $row['op'] = "op_update";
    $row['form_title'] = "編輯選單";
  } else {
    #新增
    $row = array();
    $row['op'] = "op_insert";
    $row['form_title'] = "新增選單";
  }
 
  #預設值設定
  $row['sn'] = (isset($row['sn'])) ? $row['sn'] : "";
  $row['title'] = (isset($row['title'])) ? $row['title'] : "";
  $row['enable'] = (isset($row['enable'])) ? $row['enable'] : 1;
  $row['target'] = (isset($row['target'])) ? $row['target'] : 0;
  $row['url'] = (isset($row['url'])) ? $row['url'] : "";
  $row['sort'] = (isset($row['sort'])) ? $row['sort'] : 0;
  $row['kind'] = (isset($row['kind'])) ? $row['kind'] : "nav_home";
 
  #把變數送至樣板
  $smarty->assign("row", $row);
}
#################################
# 列表程式
#
#################################
function op_list() {
 
}
########################################
#取得單筆記錄
########################################
function get_creative_nav($sn = "") {
  global $mysqli;
  if (!$sn) {
    redirect_header("index.php", 3000, "查詢選單資料錯誤！！");
  }
 
  $sql = "select *
          from `creative_nav`
          where `sn`='{$sn}' and `kind`= 'nav_home'";
  $result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
  $row = $result->fetch_assoc();
 
  #過濾撈出資料
  $row['sn'] = intval($row['sn']);
  //http://www.w3school.com.cn/php/func_string_htmlspecialchars.asp
  $row['title'] = htmlspecialchars($row['title'], ENT_QUOTES); // 轉換雙引號和單引號
  $row['url'] = htmlspecialchars($row['url'], ENT_QUOTES); // 轉換雙引號和單引號
  $row['sort'] = intval($row['sort']);
  $row['enable'] = intval($row['enable']);
  $row['target'] = intval($row['target']);
 
  return $row;
}
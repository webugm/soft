<?php

###############################################################################
#  轉向函數
###############################################################################
function redirect_header($url = "", $time = 3000, $message = '已轉向！！') {
	$_SESSION['redirect'] = "\$.jGrowl('{$message}', {  life:{$time} , position: 'center', speed: 'slow' });";
	header("location:{$url}");
	exit;
}
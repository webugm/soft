﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pagebreak', 'si', {
	alt: 'පිටු බිදුම',
	toolbar: 'මුද්‍රණය සඳහා පිටු බිදුමක් ඇතුලත් කරන්න'
} );

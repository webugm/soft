<?php
/*---- 必須引入----*/
require_once 'head.php';
$WEB['title'] = "系統變數管理";
#程式流程

#取得主要資料庫
$tbl = "creative_system";
#引入上傳物件
include_once WEB_PATH . "/class/ugmUpFiles.php";

#Foreign key
$kind_arr = array(
	"meta" => array("title" => "meta"),
	"slider" => array("title" => "輪播圖"),
);
#整理傳入變數
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
$sn = isset($_REQUEST['sn']) ? intval($_REQUEST['sn']) : "";
$kind = isset($_REQUEST['kind']) ? $_REQUEST['kind'] : "meta";
$name = isset($_REQUEST['name']) ? $_REQUEST['name'] : "";

#程式流程
switch ($op) {
#ajax拖曳排序
case "op_ajax_update_sort":
	echo op_ajax_update_sort();
	exit;
	break;

#新增(Create)
case "op_insert":
	op_insert();
	redirect_header($_SESSION['op_list'], 3000, '新增資料成功！！');
	exit;
	break;
#更新(Update)
case "op_update":
	op_update($sn);
	redirect_header($_SESSION['op_list'], 3000, '編輯資料成功！！');
	exit;
	break;

#顯示單筆(Read)
case "op_show":
	op_show($sn);
	break;

#表單
case "op_form":
	op_form($sn);
	break;

#讀取(Read)
default:
	$op = "op_list";
	$_SESSION['op_list'] = getCurrentUrl();
	op_list($kind, $name);
	break;
}
/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);
$smarty->assign("op", $op);

/*---- 程式結尾-----*/
$smarty->display('theme.html');
/*---- 函數區-----*/

###############################################################################
#  自動更新排序
###############################################################################
function op_ajax_update_sort() {
	global $mysqli;
	$tbl = $_POST['tbl'];
	$key = $_POST['key'];
	$name = $_POST['name'];
	$sort = 1;
	foreach ($_POST[$name] as $sn) {
		$sql = "update {$tbl} set `sort`='{$sort}' where `{$key}`='{$sn}'";
		$mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
		$sort++;
	}
	return "Save Sort OK! (" . date("Y-m-d H:i:s") . ")";
}
#################################
# 列表程式
#################################
function op_list($kind, $name) {
	global $mysqli, $smarty, $tbl, $kind_arr;
	# 預設Foreign key=> system
	#---- 防呆
	if (!in_array($kind, array_keys($kind_arr))) {
		$kind = "meta";
	}

	# ----得到Foreign key選單 ----------------------------
	$kind_option = "";
	foreach ($kind_arr as $key => $value) {
		$selected = "";
		if ($kind == $key) {
			$selected = " selected";
		}
		$kind_option .= "<option value='{$key}'{$selected}>{$value['title']}</option>";
	}
	$kind_form = "
    <select name='kind' id='kind'class='form-control' onchange=\"location.href='?kind='+this.value\">
      $kind_option
    </select>
  ";
	$smarty->assign('kind_form', $kind_form);
	$smarty->assign('kind', $kind);
	#-------------------------------------------

	$sql = "select *
          from `{$tbl}`
          where kind='{$kind}' and enable='1'
          order by sort"; //die($sql);
	$result = $mysqli->query($sql) or redirect_header($_SERVER['PHP_SELF'], 3, mysql_error());

	$i = 1;
	$rows = array();
	while ($row = $result->fetch_assoc()) {
		#sn name  title value description formtype  valuetype sort  enable  kind
		$row['sn'] = intval($row['sn']);
		$row['name'] = htmlspecialchars($row['name'], ENT_QUOTES); // 轉換雙引號和單引號
		$row['kind'] = htmlspecialchars($row['kind'], ENT_QUOTES); // 轉換雙引號和單引號

		/* formtype
			          「yesno」是否的單選框
			          「select」下拉選單
			          「textbox」文字框
			          「textarea」大量文字框

		*/
		if ($row['formtype'] == "textbox") {
			#---- 文字框
			$row['value'] = htmlspecialchars($row['value'], ENT_QUOTES); // 轉換雙引號和單引號
		} elseif ($row['formtype'] == "textarea") {
			#---- 大量文字框
			$row['value'] = nl2br(htmlspecialchars($row['value'], ENT_QUOTES)); // 轉換雙引號和單引號
		} elseif ($row['formtype'] == "fck") {
			#---- fck編輯器
			$html = 1;
			$br = 0;
			$row['value'] = htmlspecialchars($row['value']);
		} elseif ($row['formtype'] == "file") {
			$multiple = ($row['valuetype'] == "multiple_img") ? true : false; //圖檔數量
			$dirName = "creative"; //專案名稱
			$subdir = "/{$row['kind']}"; //子目錄
			$ugmUpFiles = new ugmUpFiles($dirName, $subdir, "/file", "/image", "/image/thumbs", $multiple);
			$ugmUpFiles->set_col($row['name'], $row['sn']); //指定sn
			$row['value'] = $ugmUpFiles->list_show_file();
		} elseif ($row['formtype'] == "yesno") {
			$row['value'] = ($row['value']) ? "是" : "<span class='text-danger'>否</span>";
		}

		$row['title'] = htmlSpecialChars($row['title']);
		$row['description'] = htmlSpecialChars($row['description']);
		$row['sort'] = $i;
		$i++;
		$rows[] = $row;
	}
	# ------------------------------------------------------------
	//print_r($rows);die();
	$smarty->assign("rows", $rows);

	return;
}

#################################
# 更新資料
#
#################################
function op_update($sn = "") {
	global $mysqli;
	if (!$sn) {
		redirect_header("index.php", 3000, "更新記錄錯誤！！");
	}

	$row = get_creative_system($sn); //取得單筆記錄

	if ($row) {

		if ($row['formtype'] == "file") {
			if ($row['valuetype'] == "single_img") {
				#單圖
				$dirName = "creative";
				$subdir = "/{$row['kind']}";
				$multiple = false;
				$ugmUpFiles = new ugmUpFiles($dirName, $subdir, "/file", "/image", "/image/thumbs", $multiple);
				$ugmUpFiles->set_col($row['name'], $row['sn']);
				//上傳
				//($upname = 'upfile', $main_width = "1280", $thumb_width = "120", $files_sn = "", $desc = NULL, $safe_name = false, $hash = false)

				$name = $row['name'];
				$main_width = "1280";
				$thumb_width = "120";
				$files_sn = "";
				$desc = NULL;
				$safe_name = true;
				$hash = false;
				$ugmUpFiles->upload_file($name, $main_width, $thumb_width, $files_sn, $desc, $safe_name, $hash);
			} elseif ($row['valuetype'] == "multiple_img") {
				#單圖
				$dirName = "creative";
				$subdir = "/{$row['kind']}";
				$multiple = true;
				$ugmUpFiles = new ugmUpFiles($dirName, $subdir, "/file", "/image", "/image/thumbs", $multiple);
				$ugmUpFiles->set_col($row['name'], $row['sn']);
				//上傳
				//($upname = 'upfile', $main_width = "1280", $thumb_width = "120", $files_sn = "", $desc = NULL, $safe_name = false, $hash = false)

				$name = $row['name'];
				$main_width = "1920";
				$thumb_width = "120";
				$files_sn = "";
				$desc = NULL;
				$safe_name = true;
				$hash = false;
				$ugmUpFiles->upload_file($name, $main_width, $thumb_width, $files_sn, $desc, $safe_name, $hash);

			}
			return;
		}
	}

	#資料過濾
	$_POST['sn'] = intval($_POST['sn']);
	$_POST['value'] = $mysqli->real_escape_string($_POST['value']);

	$sql = "update `creative_system` set
          `value`  = '{$_POST['value']}'
          where sn='{$_POST['sn']}'";

	$mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));

	return;
}
#################################
# 顯示單筆
#
#################################
function op_show($sn = "") {

}

#################################
# 表單
# 新聞關鍵字 icon_home
#################################
function op_form($sn = "") {
	global $mysqli, $smarty;

	if (!$sn) {
		redirect_header("index.php", 3000, "資料錯誤！！");
	}

	#編輯
	$row = get_creative_system($sn); //取得單筆記錄
	$row['op'] = "op_update";
	$row['form_title'] = "編輯系統變數";

	if ($row['formtype'] == "file") {

		if ($row['valuetype'] == "single_img") {

			$dirName = "creative"; //專案名稱
			$subdir = "/{$row['kind']}"; //子目錄
			$multiple = false;
			$ugmUpFiles = new ugmUpFiles($dirName, $subdir, "/file", "/image", "/image/thumbs", $multiple);
			$ugmUpFiles->set_col($row['name'], $row['sn']);
			$name = $row['name']; //欄名
			$accept = "image/*"; //可接受副檔名
			$show = "show"; //顯示縮圖
			$width = 3; //縮圖寬度
			$row['form'] = $ugmUpFiles->upform($name, $accept, $show, $width);

		} elseif ($row['valuetype'] == "multiple_img") {

			$dirName = "creative"; //專案名稱
			$subdir = "/{$row['kind']}"; //子目錄
			$multiple = true;
			$ugmUpFiles = new ugmUpFiles($dirName, $subdir, "/file", "/image", "/image/thumbs", $multiple);
			$ugmUpFiles->set_col($row['name'], $row['sn']);
			$name = $row['name']; //欄名
			$accept = "image/*"; //可接受副檔名
			$show = "show"; //顯示縮圖
			$width = 3; //縮圖寬度
			$row['form'] = $ugmUpFiles->upform($name, $accept, $show, $width);
		}
	} elseif ($row['formtype'] == "textbox") {
		$row['form'] = "<input type='text' class='form-control' name='value' id='value' value='{$row['value']}'>";
	} elseif ($row['formtype'] == "textarea") {
		$row['form'] = "<textarea class='form-control' rows='5' id='value' name='value'>{$row['value']}</textarea>";
	} elseif ($row['formtype'] == "fck") {
		$row['form'] = "";
	} elseif ($row['formtype'] == "yesno") {
		$value_1 = $row['value'] ? " checked" : "";
		$value_0 = $row['value'] ? "" : " checked";
		$row['form'] = "<input type='radio' name='value' id='value_1' value='1' {$value_1}>\n
    <label for='value_1'>是</label>&nbsp;&nbsp;\n
    <input type='radio' name='value' id='value_0' value='0' {$value_0}>\n
    <label for='value_0'>否</label>";
	}

	#把變數送至樣板
	$smarty->assign("row", $row);
}

########################################
#取得單筆記錄
########################################
function get_creative_system($sn = "") {
	global $mysqli;
	if (!$sn) {
		redirect_header("index.php", 3000, "查詢系統變數資料錯誤！！");
	}

	$sql = "select *
          from `creative_system`
          where `sn`='{$sn}'";
	$result = $mysqli->query($sql) or die(printf("Error: %s <br>" . $sql, $mysqli->sqlstate));
	$row = $result->fetch_assoc();

	#過濾撈出資料
	$row['sn'] = intval($row['sn']);
	//http://www.w3school.com.cn/php/func_string_htmlspecialchars.asp
	$row['name'] = htmlspecialchars($row['name'], ENT_QUOTES); // 轉換雙引號和單引號
	$row['kind'] = htmlspecialchars($row['kind'], ENT_QUOTES); // 轉換雙引號和單引號
	$row['title'] = htmlspecialchars($row['title'], ENT_QUOTES); // 轉換雙引號和單引號
	$row['value'] = htmlspecialchars($row['value'], ENT_QUOTES); // 轉換雙引號和單引號

	$row['description'] = htmlspecialchars($row['description'], ENT_QUOTES); // 轉換雙引號和單引號
	$row['formtype'] = htmlspecialchars($row['formtype'], ENT_QUOTES); // 轉換雙引號和單引號
	$row['valuetype'] = htmlspecialchars($row['valuetype'], ENT_QUOTES); // 轉換雙引號和單引號
	$row['enable'] = intval($row['enable']);
	$row['sort'] = intval($row['sort']);

	return $row;
}
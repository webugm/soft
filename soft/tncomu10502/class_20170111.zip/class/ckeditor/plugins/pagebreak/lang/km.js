﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pagebreak', 'km', {
	alt: 'បំបែក​ទំព័រ',
	toolbar: 'បន្ថែម​ការ​បំបែក​ទំព័រ​មុន​បោះពុម្ព'
} );

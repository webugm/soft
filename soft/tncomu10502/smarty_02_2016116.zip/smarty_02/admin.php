<?php
/*---- 必須引入----*/
require_once 'head.php';
$WEB['title'] = "育將電腦工作室";
#程式流程
#
#整理傳入變數
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : "";
#定義變數, $_SESSION['uname']用來判斷是否登入
$_SESSION['uname'] = isset($_SESSION['uname']) ? $_SESSION['uname'] : "";

//print_r($_POST); die();

#程式流程
switch ($op) {
#登入
case "check_uname":
	$msg = check_uname();
	if ($msg) {
		#如果帳號、密碼，驗證ok，則跳轉至，後台首頁
		$_SESSION['uname'] = true;
		//header("location:admin/index.php");
		redirect_header("admin/index.php", 3000, "您好：歡迎光臨！！<br>目前在後台首頁！！");
		exit;
	}
	redirect_header("index.php", 3000, "帳號密碼錯誤！！");
	break;
#登出
case "logout":

	$_SESSION['uname'] = "";
	//header("location:index.php");
	redirect_header("index.php", 3000, "您已經登出！！");
	exit;
	break;
#----

//預設動作
default:

	$op = "op_list";

	if ($_SESSION['uname']) {
		#如果已經登入，則跳轉至後台的首頁
		header("location:admin/index.php");
	}

	break;

}

/*---- 將變數送至樣版----*/
$smarty->assign("WEB", $WEB);

/*---- 程式結尾-----*/
$smarty->display('theme.html');
/*---- 函數區-----*/

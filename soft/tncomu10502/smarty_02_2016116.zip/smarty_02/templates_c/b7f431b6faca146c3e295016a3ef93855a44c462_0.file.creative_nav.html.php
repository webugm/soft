<?php
/* Smarty version 3.1.29, created on 2016-11-21 13:17:42
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_02\templates\default\tpl\creative_nav.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_583283767b7163_22622837',
  'file_dependency' => 
  array (
    'b7f431b6faca146c3e295016a3ef93855a44c462' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_02\\templates\\default\\tpl\\creative_nav.html',
      1 => 1479705458,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_583283767b7163_22622837 ($_smarty_tpl) {
?>
<nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand page-scroll" href="#page-top"><?php echo $_smarty_tpl->tpl_vars['WEB']->value['title'];?>
</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="page-scroll" href="#about">About</a>
                </li>
                <li>
                    <a class="page-scroll" href="#services">Services</a>
                </li>
                <li>
                    <a class="page-scroll" href="#portfolio">Portfolio</a>
                </li>
                <li>
                    <a class="page-scroll" href="#contact">Contact</a>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
</nav><?php }
}

<?php
/* Smarty version 3.1.29, created on 2016-11-21 13:16:59
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_02\templates\default\tpl\creative_about.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5832834b184210_03287046',
  'file_dependency' => 
  array (
    '02c51d6e146315e2c0290596239d4f2c6e4cdc74' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_02\\templates\\default\\tpl\\creative_about.html',
      1 => 1479705228,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5832834b184210_03287046 ($_smarty_tpl) {
?>
<section class="bg-primary" id="about">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 text-center">
                <h2 class="section-heading">We've got what you need!</h2>
                <hr class="light">
                <p class="text-faded">Start Bootstrap has everything you need to get your new website up and running in no time! All of the templates and themes on Start Bootstrap are open source, free to download, and easy to use. No strings attached!</p>
                <a href="#services" class="page-scroll btn btn-default btn-xl sr-button">Get Started!</a>
            </div>
        </div>
    </div>
</section><?php }
}

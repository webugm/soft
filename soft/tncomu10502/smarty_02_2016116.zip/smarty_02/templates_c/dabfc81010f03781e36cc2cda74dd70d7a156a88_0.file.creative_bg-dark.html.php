<?php
/* Smarty version 3.1.29, created on 2016-11-21 13:16:59
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_02\templates\default\tpl\creative_bg-dark.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5832834b41c3b0_26107034',
  'file_dependency' => 
  array (
    'dabfc81010f03781e36cc2cda74dd70d7a156a88' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_02\\templates\\default\\tpl\\creative_bg-dark.html',
      1 => 1479705288,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5832834b41c3b0_26107034 ($_smarty_tpl) {
?>
<aside class="bg-dark">
    <div class="container text-center">
        <div class="call-to-action">
            <h2>Free Download at Start Bootstrap!</h2>
            <a href="http://startbootstrap.com/template-overviews/creative/" class="btn btn-default btn-xl sr-button">Download Now!</a>
        </div>
    </div>
</aside><?php }
}

<?php
/* Smarty version 3.1.29, created on 2016-11-21 13:16:58
  from "C:\Dropbox\server\UniServerZ_1\www\tncomu10502\smarty_02\templates\default\theme.html" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5832834af3bd36_30568690',
  'file_dependency' => 
  array (
    '61144c28a674734e9cc6aa26b3745605ec6b68d8' => 
    array (
      0 => 'C:\\Dropbox\\server\\UniServerZ_1\\www\\tncomu10502\\smarty_02\\templates\\default\\theme.html',
      1 => 1479705312,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:tpl/creative_nav.html' => 1,
    'file:tpl/creative_header.html' => 1,
    'file:tpl/creative_about.html' => 1,
    'file:tpl/creative_services.html' => 1,
    'file:tpl/creative_portfolio.html' => 1,
    'file:tpl/creative_bg-dark.html' => 1,
    'file:tpl/creative_contact.html' => 1,
  ),
),false)) {
function content_5832834af3bd36_30568690 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $_smarty_tpl->tpl_vars['WEB']->value['title'];?>
</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/css/creative.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"><?php echo '</script'; ?>
>
    <![endif]-->

    <!-- jQuery -->
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/jquery/jquery.min.js"><?php echo '</script'; ?>
>

</head>

<body id="page-top">
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_nav.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_about.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_services.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_portfolio.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_bg-dark.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
 
    <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:tpl/creative_contact.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
 


    <!-- Bootstrap Core JavaScript -->
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/bootstrap/js/bootstrap.min.js"><?php echo '</script'; ?>
>

    <!-- Plugin JavaScript -->
    <?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/scrollreveal/scrollreveal.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/vendor/magnific-popup/jquery.magnific-popup.min.js"><?php echo '</script'; ?>
>

    <!-- Theme JavaScript -->
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['themeUrl']->value;?>
/js/creative.min.js"><?php echo '</script'; ?>
>

</body>

</html>
<?php }
}

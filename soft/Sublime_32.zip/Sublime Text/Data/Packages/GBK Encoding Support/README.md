### With this plugin you can:

1. Open a GBK File

1. Save file with GBK encoding

1. Change file encoding from utf8 to GBK or GBK to utf8
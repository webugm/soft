# This branch "master" is deprecated.

For the faster and better, Sublime Text 3, please see: https://github.com/titoBouzout/SideBarEnhancements/tree/st3


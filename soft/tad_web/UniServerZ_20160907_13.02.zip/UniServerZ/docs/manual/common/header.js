
document.write('<table id=\"banner_table\" ><tr><td>');
document.write(' <div id=\"banner_div\">');
document.write('   <img src=\"common/images/us_zero_logo.png\" alt=\"The Uniform Server\" />');
document.write('   <span id=\"banner_txt\">UniServer Zero XIII <small id=\"banner_txt_small\">Doc version 1.0.0</small></span>');
document.write(' </div>');
document.write('</td></tr></table>');
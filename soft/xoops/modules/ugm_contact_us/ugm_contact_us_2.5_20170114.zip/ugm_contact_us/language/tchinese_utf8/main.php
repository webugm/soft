<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2009-02-28
// $Id:$
// ------------------------------------------------------------------------- //

define("_MD_UGMCONTACUS_SUMMARY", "「聯絡我們」的填寫項目及欄位");
//------index.php-------------------------------------------------------------
define("_MD_SEND_MESSAGE","已收到您的訊息，我們將儘速處理及回覆");
define("_MD_UGMCONTACUS_CU_CONDITION","處理狀態");
define("_MD_UGMCONTACUS_CU_NAME","聯絡姓名");
define("_MD_UGMCONTACUS_CU_MAIL","電子郵件");
define("_MD_UGMCONTACUS_CU_TEL","聯絡電話");
define("_MD_UGMCONTACUS_CU_MOBILE","行動電話");
define("_MD_UGMCONTACUS_CU_TIME","適合聯絡時間");
define("_MD_UGMCONTACUS_CU_SERVICE","需要服務項目");
define("_MD_UGMCONTACUS_CU_CONTENT","詳細內容");
define("_MD_UGMCONTACUS_CU_COMPLETION_DATE","完成日期");
define("_MD_UGMCONTACUS_CU_POST_DATE","上傳日期");
define("_MD_VALCODE","驗證碼");
define("_MD_UGMCONTACUS_MANAGEMENT","管理聯絡我們");
define("_MD_UGMCONTACUS_ADMENU1", "聯絡我們");
define("_MD_UGMCONTACUS_ADMENU2", "服務項目");
define("_MD_UGMCONTACUS_ADMENU3", "聯絡單位");
?>

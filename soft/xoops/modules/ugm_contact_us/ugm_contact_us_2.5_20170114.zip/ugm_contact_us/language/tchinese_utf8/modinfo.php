<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2009-02-28
// $Id:$
// ------------------------------------------------------------------------- //
include_once XOOPS_ROOT_PATH."/modules/tadtools/language/{$xoopsConfig['language']}/modinfo_common.php";
define("_MI_UGMCONTACUS_NAME","聯絡我們");
define("_MI_UGMCONTACUS_AUTHOR","聯絡我們");
define("_MI_UGMCONTACUS_CREDITS","ugm");
define("_MI_UGMCONTACUS_DESC","聯絡我們");
define("_MI_UGMCONTACUS_ADMENU1", "聯絡我們");
define("_MI_UGMCONTACUS_ADMENU2", "服務項目");
define("_MI_UGMCONTACUS_ADMENU3", "聯絡單位");
define("_MI_UGMCONTACUS_TEMPLATE_DESC1", "index_tpl.html的樣板檔。");
define("_MI_UGMCONTACUS_TEMPLATE_DESC2", "ugm_contact_us_adm_main_tpl.html的樣板檔。");
define("_MI_UGMCONTACUS_TEMPLATE_DESC3", "ugm_contact_us_adm_service_tpl.html的樣板檔。");
define("_MI_UGMCONTACUS_TEMPLATE_DESC4", "ugm_contact_us_adm_unit_tpl.html的樣板檔。");
define("_MI_UGMCONTACUS_BNAME1","聯絡我們表單");
define("_MI_UGMCONTACUS_BDESC1","聯絡我們表單(ugm_contact_us_b1)");
define("_MI_MAILTO","收信信箱");
define("_MI_MAILTO_DESC","收信信箱，請用「;」隔開，如果有多個信箱。");
define("_MI_UGMCONTACTUS_INFO","我們的資訊");
define("_MI_UGMCONTACTUS_INFO_DESC","我們的資訊");
define("_MI_UGMCONTACTUS_SUBJECT","寄信主旨");
define("_MI_UGMCONTACTUS_SUBJECT_DESC","空值等於預設值");


?>

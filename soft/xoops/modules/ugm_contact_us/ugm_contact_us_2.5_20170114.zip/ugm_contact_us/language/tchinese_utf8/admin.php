<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2009-02-28
// $Id:$
// ------------------------------------------------------------------------- //
include_once "../../tadtools/language/{$xoopsConfig['language']}/admin_common.php";
define("_TAD_NEED_TADTOOLS"," 需要 tadtools 模組，可至<a href='http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50' target='_blank'>Tad教材網</a>下載。");

define("_MA_SEND","儲存");
define("_MA_COMPLETE","結案");
define("_MA_UGMCONTACUS_CU_CONDITION","處理狀態");
define("_MA_UGMCONTACUS_CU_NAME","姓名");
define("_MA_UGMCONTACUS_CU_MAIL","電子郵件");
define("_MA_UGMCONTACUS_CU_TEL","聯絡電話");
define("_MA_UGMCONTACUS_CU_MOBILE","行動電話");
define("_MA_UGMCONTACUS_CU_TIME","適合聯絡時間");
define("_MA_UGMCONTACUS_CU_SERVICE","需要服務項目");
define("_MA_UGMCONTACUS_CU_CONTENT","詳細內容");
define("_MA_UGMCONTACUS_CU_COMPLETION_DATE","預計完成日期");
define("_MA_UGMCONTACUS_CU_POST_DATE","上傳日期");
define("_MA_UGMCONTACUS_CU_IP","IP");
define("_MA_UGMCONTACUS_CU_CONDITION_0","新問題");
define("_MA_UGMCONTACUS_CU_CONDITION_1","解決中");
define("_MA_UGMCONTACUS_CU_CONDITION_2","已解決");
define("_MA_UGMCONTACUS_SOLUTION_TITLE","處理進度說明");
define("_MA_UGMCONTACUS_SOLUTION_DATE","處理日期");
//----------------unit.php --------------------------------------------------
define("_MA_UGMCONTACUS_UNIT_TITLE","單位");
define("_MA_UGMCONTACUS_UNIT_EMAIL","信箱(分隔「;」)");
define("_MA_UGMCONTACUS_TITLE_ADD","新增 「%s」 表單");
define("_MA_UGMCONTACUS_TITLE_EDIT","編輯 「%s」 表單");
define("_MA_UGMCONTACUS_SUCCESS","資料寫入成功");
define("_MA_UGMCONTACUS_DEL_SUCCESS","刪除成功");
define("_MA_UGMCONTACUS_RETURN","回上頁");
define("_MA_UGMCONTACUS_MANAGER","處理");

?>

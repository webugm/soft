<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2009-02-28
// $Id:$
// ------------------------------------------------------------------------- //
include_once "../../tadtools/language/{$xoopsConfig['language']}/admin_common.php";
define("_TAD_NEED_TADTOOLS","Need modules/tadtools. You can download tadtools from <a href='http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50' target='_blank'>Tad's web</a>.");


define("_MA_SEND","Save");
define("_MA_COMPLETE","All complete");
define("_MA_UGMCONTACUS_CU_CONDITION","Status");
define("_MA_UGMCONTACUS_CU_NAME","Name");
define("_MA_UGMCONTACUS_CU_MAIL","E-Mail");
define("_MA_UGMCONTACUS_CU_TEL","TEL");
define("_MA_UGMCONTACUS_CU_MOBILE","Cell Phone");
define("_MA_UGMCONTACUS_CU_TIME","Contact time");
define("_MA_UGMCONTACUS_CU_SERVICE","Need Services");
define("_MA_UGMCONTACUS_CU_CONTENT","Content");
define("_MA_UGMCONTACUS_CU_COMPLETION_DATE","Expected date");
define("_MA_UGMCONTACUS_CU_POST_DATE","Post date");
define("_MA_UGMCONTACUS_CU_IP","IP");
define("_MA_UGMCONTACUS_CU_CONDITION_0","New");
define("_MA_UGMCONTACUS_CU_CONDITION_1","processing");
define("_MA_UGMCONTACUS_CU_CONDITION_2","Complete");
define("_MA_UGMCONTACUS_SOLUTION_TITLE","Process item");
define("_MA_UGMCONTACUS_SOLUTION_DATE","Process date");
//----------------unit.php --------------------------------------------------
define("_MA_UGMCONTACUS_UNIT_TITLE","Unit title");
define("_MA_UGMCONTACUS_UNIT_EMAIL","Unit email");
define("_MA_UGMCONTACUS_TITLE_ADD","Add \"%s\" form");
define("_MA_UGMCONTACUS_TITLE_EDIT","Edit \"%s\" form");
define("_MA_UGMCONTACUS_SUCCESS","Updated!");
define("_MA_UGMCONTACUS_DEL_SUCCESS","Deleted!");
define("_MA_UGMCONTACUS_RETURN","Back");
define("_MA_UGMCONTACUS_MANAGER","Manager");

?>

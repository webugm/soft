<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2009-02-28
// $Id:$
// ------------------------------------------------------------------------- //

define("_MD_UGMCONTACUS_SUMMARY", "「Contact Us」fill out the fields");
//------index.php-------------------------------------------------------------
define("_MD_SEND_MESSAGE","Your message has been received, we will deal with and reply as soon as possible.");
define("_MD_UGMCONTACUS_CU_CONDITION","Status");
define("_MD_UGMCONTACUS_CU_NAME","Name");
define("_MD_UGMCONTACUS_CU_MAIL","E-Mail");
define("_MD_UGMCONTACUS_CU_TEL","Tel");
define("_MD_UGMCONTACUS_CU_MOBILE","Cell Phone");
define("_MD_UGMCONTACUS_CU_TIME","Contact Time");
define("_MD_UGMCONTACUS_CU_SERVICE","Need services");
define("_MD_UGMCONTACUS_CU_CONTENT","Content");
define("_MD_UGMCONTACUS_CU_COMPLETION_DATE","Expected date");
define("_MD_UGMCONTACUS_CU_POST_DATE","Post Date");
define("_MD_VALCODE","VALCODE");
define("_MD_UGMCONTACUS_MANAGEMENT","MANAGEMENT");
define("_MD_UGMCONTACUS_ADMENU1", "Contact Manage");
define("_MD_UGMCONTACUS_ADMENU2", "Service Manage");
define("_MD_UGMCONTACUS_ADMENU3", "Unit Manage");
?>

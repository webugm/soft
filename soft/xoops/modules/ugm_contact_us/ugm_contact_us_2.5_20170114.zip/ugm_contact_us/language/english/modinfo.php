<?php
//  ------------------------------------------------------------------------ //
// 本模組由 ugm 製作
// 製作日期：2009-02-28
// $Id:$
// ------------------------------------------------------------------------- //
include_once XOOPS_ROOT_PATH."/modules/tadtools/language/{$xoopsConfig['language']}/modinfo_common.php";
define("_MI_UGMCONTACUS_NAME","Contact Us");
define("_MI_UGMCONTACUS_AUTHOR","Contact Us");
define("_MI_UGMCONTACUS_CREDITS","ugm");
define("_MI_UGMCONTACUS_DESC","Contact Us");
define("_MI_UGMCONTACUS_ADMENU1", "Contact Manage");
define("_MI_UGMCONTACUS_ADMENU2", "Service Manage");
define("_MI_UGMCONTACUS_ADMENU3", "Unit Manage");
define("_MI_UGMCONTACUS_TEMPLATE_DESC1", "index_tpl.html template。");
define("_MI_UGMCONTACUS_TEMPLATE_DESC2", "ugm_contact_us_adm_main_tpl.html templates");
define("_MI_UGMCONTACUS_TEMPLATE_DESC3", "ugm_contact_us_adm_service_tpl.html templates");
define("_MI_UGMCONTACUS_TEMPLATE_DESC4", "ugm_contact_us_adm_unit_tpl.html templates");
define("_MI_UGMCONTACUS_BNAME1","Contact FORM");
define("_MI_UGMCONTACUS_BDESC1","Contact Form (ugm_contact_us_b1)");
define("_MI_MAILTO","E-Mail");
define("_MI_MAILTO_DESC","Input E-Mail Address. Please use the ';' separated, if there are multiple mailboxes.");
define("_MI_UGMCONTACTUS_INFO","Our Infomation");
define("_MI_UGMCONTACTUS_INFO_DESC","Our Infomation");
define("_MI_UGMCONTACTUS_SUBJECT","Subject");
define("_MI_UGMCONTACTUS_SUBJECT_DESC","Null as default");


?>

<?php
function xoops_module_install_ugm_contact_us(&$module) {
  global $xoopsDB;

  return true;
}
?>

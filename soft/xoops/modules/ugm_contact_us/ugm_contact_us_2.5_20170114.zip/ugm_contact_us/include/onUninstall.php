<?php
function xoops_module_uninstall_ugm_search(&$module) {
  GLOBAL $xoopsDB;
	return true;
}

?>

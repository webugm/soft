CREATE TABLE `ugm_wifi` (
  `sn` mediumint(9) unsigned NOT NULL auto_increment COMMENT 'sn',
  `uid` mediumint(9) unsigned NOT NULL default '0' COMMENT 'uid',
  `password` varchar(255) NOT NULL default '' COMMENT '密碼',
  `account` varchar(255) NOT NULL default '' COMMENT 'WIFI帳號',
  `enable` enum('1','0') NOT NULL default '1' COMMENT '啟用',
PRIMARY KEY  (`sn`)
) ENGINE=MyISAM;


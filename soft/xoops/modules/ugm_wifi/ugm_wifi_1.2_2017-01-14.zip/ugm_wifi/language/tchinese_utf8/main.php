<?php
/**
 * Ugm Wifi module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Wifi
 * @since      2.5
 * @author     郭俊良
 * @version    $Id $
 **/

define('_TAD_NEED_TADTOOLS', '需要 tadtools 模組，可至<a href="http://campus-xoops.tn.edu.tw/modules/tad_modules/index.php?module_sn=1" target="_blank">XOOPS輕鬆架</a>下載。');

define("_MD_UGMMOUDEL_KIND_ENABLE_1", "啟用");
define("_MD_UGMMOUDEL_KIND_ENABLE_0", "停用");
define("_BP_INSERT_SUCCESS", "新增成功！！");
define("_BP_UPDATE_SUCCESS", "更新成功！！");
define("_BP_DELETE_SUCCESS", "刪除成功！！");
define("_BP_INSERT_ERROR", "新增失敗！！");
define("_BP_UPDATE_ERROR", "更新失敗！！");
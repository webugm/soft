<?php
/**
 * Ugm Wifi module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Wifi
 * @since      2.5
 * @author     郭俊良
 * @version    $Id $
 **/

include_once XOOPS_ROOT_PATH . '/modules/tadtools/language/' . $xoopsConfig['language'] . '/modinfo_common.php';

define('_MI_UGMWIFI_NAME', 'WIFI查詢');
define('_MI_UGMWIFI_AUTHOR', 'WIFI查詢');
define('_MI_UGMWIFI_CREDITS', '育將電腦工作室');
define('_MI_UGMWIFI_DESC', '查詢使用者wifi密碼');
define('_MI_UGMWIFI_AUTHOR_WEB', '育將電腦工作室');
define('_MI_UGMWIFI_ADMENU1', 'WIFI管理');
define('_MI_UGMWIFI_ADMENU1_DESC', 'WIFI管理');

define('_MI_UGM_WIFI_SHOW1_BLOCK_NAME', 'WiFi密碼查詢');
define('_MI_UGM_WIFI_SHOW1_BLOCK_DESC', 'WiFi密碼查詢區塊 (ugm_wifi_show1)');

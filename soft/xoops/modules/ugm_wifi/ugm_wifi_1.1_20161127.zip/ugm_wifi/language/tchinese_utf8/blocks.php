<?php
/**
 * Ugm Wifi module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Wifi
 * @since      2.5
 * @author     郭俊良
 * @version    $Id $
 **/

define("_MB_UGMWIFI_BLOCK_1_1", "管理員尚未設定，WIFI密碼！！");

define("_MB_UGMWIFI_BLOCK_1_2", "請先登入會員！！");
define("_MB_UGMWIFI_ACCOUNT", "WIFI帳號：");
define("_MB_UGMWIFI_PASSWORD", "WIFI密碼：");
define("_MB_UGMWIFI_BLOCK_1_TITLE", "您的WIFI 帳密");

<?php

/**
 * U module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    U
 * @since      u
 * @author     u
 * @version    $Id $
 **/

//區塊主函式 (ugm_wifi_show1)
function ugm_wifi_show1($options) {
	global $xoopsDB, $xoopsUser;
	$myts = MyTextSanitizer::getInstance();

	if ($xoopsUser) {
		$uid = $xoopsUser->uid();
		$sql = "select a.uid,a.password,b.name,b.uname
            from `" . $xoopsDB->prefix("ugm_wifi") . "` as a
            left join " . $xoopsDB->prefix("users") . " as b on a.uid = b.uid
            where a.uid = '{$uid}'"; //die($sql);
		$result = $xoopsDB->query($sql) or web_error($sql);
		list($uid, $password, $name, $uname) = $xoopsDB->fetchRow($result);

		$block['name'] = $name ? $myts->addSlashes($name) : $myts->addSlashes($uname);
		$block['uid'] = intval($uid);

		if ($password) {
			$block['password'] = $myts->addSlashes($password);
		} else {
			$block['password'] = _MB_UGMWIFI_BLOCK_1_1;
		}

	} else {
		$block['password'] = _MB_UGMWIFI_BLOCK_1_2;
	}
	return $block;
}

//區塊編輯函式 (ugm_wifi_show1_edit)
function ugm_wifi_show1_edit($options) {

	$form = "
  <table>
  </table>
  ";
	return $form;
}

<?php
/**
 * Ugm Wifi module
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright  The XOOPS Project http://sourceforge.net/projects/xoops/
 * @license    http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package    Ugm Wifi
 * @since      2.5
 * @author     ���T�}
 * @version    $Id $
 **/

include_once "../../tadtools/language/{$xoopsConfig['language']}/admin_common.php";
define('_TAD_NEED_TADTOOLS','�ݭn tadtools �ҲաA�i��<a href="http://campus-xoops.tn.edu.tw/modules/tad_modules/index.php?module_sn=1" target="_blank">XOOPS���P�[</a>�U���C');


//ugm_wifi-list
define('_MA_UGMWIFI_SN', 'sn');
define('_MA_UGMWIFI_UID', 'uid');
define('_MA_UGMWIFI_PASSWORD', '�K�X');
define('_MA_UGMWIFI_ENABLE', '�ҥ�');
define('_MA_UGMWIFI_SHOW_SN_FILES', '');
